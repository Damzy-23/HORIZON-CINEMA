import json
import random
from datetime import date, timedelta

def update_cinemas():
    filename = "cinema_data.json"
    try:
        with open(filename, "r") as f:
            data = json.load(f)
    except FileNotFoundError:
        print(f"{filename} not found.")
        return

    films = [
        {"title": "The Great Adventure", "description": "An epic journey.", "genre": "Adventure", "rating": "PG-13", "actors": ["Actor A", "Actor B"]},
        {"title": "Romantic Escape", "description": "A love story.", "genre": "Romance", "rating": "PG", "actors": ["Actor C", "Actor D"]},
        {"title": "Mystery Manor", "description": "A thrilling mystery.", "genre": "Mystery", "rating": "PG-13", "actors": ["Actor E", "Actor F"]},
        {"title": "Sci-Fi Saga", "description": "A space odyssey.", "genre": "Sci-Fi", "rating": "PG-13", "actors": ["Actor G", "Actor H"]},
        {"title": "Comedy Nights", "description": "Laugh out loud.", "genre": "Comedy", "rating": "PG", "actors": ["Actor I", "Actor J"]},
        {"title": "Horror House", "description": "Spooky tales.", "genre": "Horror", "rating": "R", "actors": ["Actor K", "Actor L"]},
        {"title": "Animated Fun", "description": "Family animation.", "genre": "Animation", "rating": "G", "actors": ["Actor M", "Actor N"]},
    ]

    show_times = ["10:00", "15:00", "19:00"]

    # Add screens and showings to each cinema
    for cinema in data.get("cinemas", []):
        # Add 3 screens per cinema with seating capacity 100
        screens = []
        for screen_num in range(1, 4):
            screen = {
                "screen_number": screen_num,
                "seating_capacity": 100,
                "showings": []
            }
            # Add showings for next 7 days
            today = date.today()
            for day_offset in range(7):
                show_date = today + timedelta(days=day_offset)
                for show_time in show_times:
                    film = random.choice(films)
                    show_datetime = show_date.strftime("%Y-%m-%d") + " " + show_time
                    showing = {
                        "film": film,
                        "show_time": show_datetime
                    }
                    screen["showings"].append(showing)
            screens.append(screen)
        cinema["screens"] = screens

    # Save updated data back to file
    with open(filename, "w") as f:
        json.dump(data, f, indent=4)
    print(f"Updated {len(data.get('cinemas', []))} cinemas with screens and showings.")

if __name__ == "__main__":
    update_cinemas()
