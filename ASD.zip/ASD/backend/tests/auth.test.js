const request = require('supertest');
const app = require('../app');
const User = require('../models/User');
const jwt = require('jsonwebtoken');

describe('Authentication Tests', () => {
    describe('POST /api/auth/login', () => {
        beforeEach(async () => {
            // Create a test user
            await User.create({
                username: 'testuser',
                password: '$2a$10$TestHashedPassword',
                role: 'staff'
            });
        });

        it('should login with valid credentials', async () => {
            const res = await request(app)
                .post('/api/auth/login')
                .send({
                    username: 'testuser',
                    password: 'password123'
                });

            expect(res.statusCode).toBe(200);
            expect(res.body).toHaveProperty('token');
            expect(res.body.user).toHaveProperty('username', 'testuser');
        });

        it('should reject invalid credentials', async () => {
            const res = await request(app)
                .post('/api/auth/login')
                .send({
                    username: 'testuser',
                    password: 'wrongpassword'
                });

            expect(res.statusCode).toBe(401);
            expect(res.body).toHaveProperty('error');
        });
    });

    describe('Protected Routes', () => {
        let token;
        
        beforeEach(async () => {
            const user = await User.create({
                username: 'testuser',
                password: '$2a$10$TestHashedPassword',
                role: 'staff'
            });

            token = jwt.sign(
                { userId: user._id, role: user.role },
                process.env.JWT_SECRET,
                { expiresIn: '1h' }
            );
        });

        it('should access protected route with valid token', async () => {
            const res = await request(app)
                .get('/api/profile')
                .set('Authorization', `Bearer ${token}`);

            expect(res.statusCode).toBe(200);
        });

        it('should reject access without token', async () => {
            const res = await request(app)
                .get('/api/profile');

            expect(res.statusCode).toBe(401);
        });
    });
}); 