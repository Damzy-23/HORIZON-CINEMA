const mongoose = require('mongoose');

const screeningSchema = new mongoose.Schema({
    filmId: { type: mongoose.Schema.Types.ObjectId, ref: 'Film' },
    cinemaId: { type: mongoose.Schema.Types.ObjectId, ref: 'Cinema' },
    screenNumber: Number,
    showtime: Date,
    availableSeats: {
        lowerHall: [Number],
        upperGallery: [Number],
        vipSeats: [Number]
    },
    price: {
        lowerHall: Number,
        upperGallery: Number,
        vipSeats: Number
    }
});

module.exports = mongoose.model('Screening', screeningSchema); 