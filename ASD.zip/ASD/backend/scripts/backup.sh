#!/bin/bash

# Set variables
BACKUP_DIR="./backups"
TIMESTAMP=$(date +"%Y%m%d%H%M")
DB_NAME="cinema"
MONGO_URI="mongodb://$MONGO_ROOT_USERNAME:$MONGO_ROOT_PASSWORD@localhost:27017/$DB_NAME"

# Create backup directory if it doesn't exist
mkdir -p $BACKUP_DIR

# Perform the backup
mongodump --uri="$MONGO_URI" --out="$BACKUP_DIR/$TIMESTAMP"

# Optional: Remove backups older than 7 days
find $BACKUP_DIR -type d -mtime +7 -exec rm -rf {} \;

echo "Backup completed at $BACKUP_DIR/$TIMESTAMP" 