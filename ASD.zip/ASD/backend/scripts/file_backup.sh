#!/bin/bash

# Set variables
FILE_BACKUP_DIR="./file_backups"
TIMESTAMP=$(date +"%Y%m%d%H%M")
SOURCE_DIR="./uploads" # Change this to your source directory

# Create backup directory if it doesn't exist
mkdir -p $FILE_BACKUP_DIR

# Perform the backup
tar -czf "$FILE_BACKUP_DIR/file_backup_$TIMESTAMP.tar.gz" "$SOURCE_DIR"

# Optional: Remove backups older than 30 days
find $FILE_BACKUP_DIR -type f -mtime +30 -exec rm -f {} \;

echo "File backup completed at $FILE_BACKUP_DIR/file_backup_$TIMESTAMP.tar.gz"

mongorestore --uri="$MONGO_URI" "$BACKUP_DIR/$TIMESTAMP"

tar -xzf "$FILE_BACKUP_DIR/file_backup_$TIMESTAMP.tar.gz" -C /path/to/restore/location 