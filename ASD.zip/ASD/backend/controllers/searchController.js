const searchService = require('../services/searchService');

exports.searchFilms = async (req, res) => {
    try {
        const films = await searchService.searchFilms(req.query);
        res.json(films);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.searchScreenings = async (req, res) => {
    try {
        const screenings = await searchService.searchScreenings(req.query);
        res.json(screenings);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.getAvailableSeats = async (req, res) => {
    try {
        const availableSeats = await searchService.filterAvailableSeats(
            req.params.screeningId
        );
        res.json(availableSeats);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
}; 