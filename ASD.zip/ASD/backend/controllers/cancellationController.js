const Booking = require('../models/Booking');
const Screening = require('../models/Screening');
const { returnSeatsToPool } = require('../utils/helpers');

exports.cancelBooking = async (req, res) => {
    try {
        const { bookingReference } = req.params;
        const booking = await Booking.findOne({ 
            bookingReference,
            status: 'active'
        }).populate('screeningId');

        if (!booking) {
            return res.status(404).json({ error: 'Booking not found' });
        }

        // Check if cancellation is allowed (at least 1 day before show)
        const screening = booking.screeningId;
        const showDate = new Date(screening.showtime);
        const today = new Date();
        const timeDiff = showDate.getTime() - today.getTime();
        const daysDiff = Math.ceil(timeDiff / (1000 * 3600 * 24));

        if (daysDiff < 1) {
            return res.status(400).json({ 
                error: 'Cancellation not allowed within 24 hours of show time' 
            });
        }

        // Calculate refund amount (50% of total cost)
        const refundAmount = booking.totalCost * 0.5;

        // Update booking status
        booking.status = 'cancelled';
        booking.cancellationDate = new Date();
        booking.refundAmount = refundAmount;
        await booking.save();

        // Return seats to available pool
        await returnSeatsToPool(screening, booking.seats);

        res.json({
            message: 'Booking cancelled successfully',
            refundAmount,
            booking
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.getCancellationHistory = async (req, res) => {
    try {
        const query = { status: 'cancelled' };

        // If staff user, only show cancellations for their cinema
        if (req.user.role === 'staff') {
            query.cinemaId = req.user.cinemaId;
        }

        const cancellations = await Booking.find(query)
            .populate('screeningId')
            .sort({ cancellationDate: -1 });

        res.json(cancellations);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
}; 