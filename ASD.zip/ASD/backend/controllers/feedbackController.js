const Feedback = require('../models/Feedback');
const Film = require('../models/Film');

exports.submitFeedback = async (req, res) => {
    const { filmId, rating, comment } = req.body;

    try {
        const feedback = new Feedback({
            filmId,
            userId: req.user._id, // Assuming user is authenticated and user ID is available
            rating,
            comment
        });

        await feedback.save();

        // Update film's average rating
        await updateFilmRating(filmId);

        res.status(201).json({ message: 'Feedback submitted successfully', feedback });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

const updateFilmRating = async (filmId) => {
    const feedbacks = await Feedback.find({ filmId });
    const averageRating = feedbacks.reduce((acc, feedback) => acc + feedback.rating, 0) / feedbacks.length;

    await Film.findByIdAndUpdate(filmId, { averageRating });
};

exports.getFilmFeedback = async (req, res) => {
    const { filmId } = req.params;

    try {
        const feedbacks = await Feedback.find({ filmId }).populate('userId', 'username');
        res.json(feedbacks);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
}; 