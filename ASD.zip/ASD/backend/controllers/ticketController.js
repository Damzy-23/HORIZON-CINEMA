const ticketService = require('../services/ticketService');
const Booking = require('../models/Booking');

exports.downloadTicket = async (req, res) => {
    try {
        const { bookingReference } = req.params;
        
        const booking = await Booking.findOne({ bookingReference })
            .populate('screening')
            .populate('film')
            .populate('cinema');

        if (!booking) {
            return res.status(404).json({ error: 'Booking not found' });
        }

        // Generate PDF
        const doc = await ticketService.generateTicket(booking);

        // Set response headers
        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader(
            'Content-Disposition',
            `attachment; filename=ticket-${bookingReference}.pdf`
        );

        // Pipe the PDF to the response
        doc.pipe(res);
        doc.end();
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.downloadIndividualTickets = async (req, res) => {
    try {
        const { bookingReference } = req.params;
        
        const booking = await Booking.findOne({ bookingReference })
            .populate('screening')
            .populate('film')
            .populate('cinema');

        if (!booking) {
            return res.status(404).json({ error: 'Booking not found' });
        }

        // Generate PDF with individual tickets
        const doc = await ticketService.generateMultipleTickets(booking);

        // Set response headers
        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader(
            'Content-Disposition',
            `attachment; filename=tickets-${bookingReference}.pdf`
        );

        // Pipe the PDF to the response
        doc.pipe(res);
        doc.end();
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
}; 