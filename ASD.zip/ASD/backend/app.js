const express = require('express');
const app = express();
const authRoutes = require('./routes/authRoutes');
const errorHandler = require('./middleware/errorHandler');
const requestLogger = require('./middleware/requestLogger');
const validate = require('./middleware/validator');
const bookingController = require('./controllers/bookingController');
const screeningController = require('./controllers/screeningController');
const cinemaController = require('./controllers/cinemaController');
const filmController = require('./controllers/filmController');
const compression = require('./middleware/compression');
const { limiter, loginLimiter } = require('./middleware/rateLimiter');
const cache = require('./middleware/cache');
const monitorRequest = require('./middleware/monitoring');
const monitoringRoutes = require('./routes/monitoringRoutes');
const loggingService = require('./services/loggingService');
const http = require('http');
const socketIo = require('socket.io');
const helmet = require('helmet');
const cors = require('cors');
const { swaggerUi, swaggerDocs } = require('./swagger');

// Add the auth routes
app.use('/api', authRoutes);

// Request logging
app.use(requestLogger);

// Routes with validation
app.post('/api/bookings', validate('booking'), bookingController.createBooking);
app.post('/api/screenings', validate('screening'), screeningController.createScreening);
app.post('/api/cinemas', validate('cinema'), cinemaController.createCinema);
app.post('/api/films', validate('film'), filmController.createFilm);

// Apply compression
app.use(compression);

// Apply rate limiting
app.use(limiter);
app.use('/api/auth/login', loginLimiter);

// Cache routes
app.use('/api/films', cache(3600)); // Cache film data for 1 hour
app.use('/api/cinemas', cache(3600));
app.use('/api/screenings', cache(300)); // Cache screenings for 5 minutes

// Add monitoring middleware
app.use(monitorRequest);

// Add monitoring routes
app.use('/monitoring', monitoringRoutes);

// Use Helmet to set security-related HTTP headers
app.use(helmet());
app.use(helmet.contentSecurityPolicy({
    directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'", "https://trusted.cdn.com"],
        objectSrc: ["'none'"],
        upgradeInsecureRequests: []
    }
}));

// Configure CORS
const corsOptions = {
    origin: process.env.ALLOWED_ORIGIN, // Set this to your frontend URL
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    credentials: true
};

app.use(cors(corsOptions));

// Serve Swagger API documentation
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocs));

// Error handling - should be last
app.use(errorHandler);

// Error handling for rate limiting
app.use((err, req, res, next) => {
    if (err instanceof Error && err.code === 'RATE_LIMIT_EXCEEDED') {
        return res.status(429).json({
            error: 'Too many requests, please try again later'
        });
    }
    next(err);
});

// Log application startup
loggingService.info('Application started', {
    env: process.env.NODE_ENV,
    port: process.env.PORT
});

// Error logging
app.use((err, req, res, next) => {
    loggingService.error('Unhandled error', {
        error: err.message,
        stack: err.stack,
        path: req.path,
        method: req.method
    });
    next(err);
});

// Create HTTP server
const server = http.createServer(app);
const io = socketIo(server);

// Socket.IO connection
io.on('connection', (socket) => {
    console.log('New client connected');

    socket.on('disconnect', () => {
        console.log('Client disconnected');
    });
});

// Export the server for use in other modules
module.exports = { app, server, io };

// ... rest of your app configuration ... 