const Film = require('../models/Film');
const Cinema = require('../models/Cinema');
const Screening = require('../models/Screening');

class SearchService {
    async searchFilms(query) {
        const {
            title,
            genre,
            ageRating,
            dateFrom,
            dateTo,
            sortBy = 'title',
            order = 'asc'
        } = query;

        let filter = {};

        if (title) {
            filter.title = { $regex: title, $options: 'i' };
        }

        if (genre) {
            filter.genre = genre;
        }

        if (ageRating) {
            filter.ageRating = ageRating;
        }

        const sort = {};
        sort[sortBy] = order === 'asc' ? 1 : -1;

        return await Film.find(filter).sort(sort);
    }

    async searchScreenings(query) {
        const {
            filmId,
            cinemaId,
            dateFrom,
            dateTo,
            timeFrom,
            timeTo
        } = query;

        let filter = {};

        if (filmId) {
            filter.filmId = filmId;
        }

        if (cinemaId) {
            filter.cinemaId = cinemaId;
        }

        if (dateFrom || dateTo) {
            filter.showtime = {};
            if (dateFrom) {
                filter.showtime.$gte = new Date(dateFrom);
            }
            if (dateTo) {
                filter.showtime.$lte = new Date(dateTo);
            }
        }

        if (timeFrom || timeTo) {
            const timeFilter = {};
            if (timeFrom) {
                timeFilter.$gte = { $hour: parseInt(timeFrom.split(':')[0]) };
            }
            if (timeTo) {
                timeFilter.$lte = { $hour: parseInt(timeTo.split(':')[0]) };
            }
            filter = {
                ...filter,
                $expr: {
                    $and: [
                        { $gte: [{ $hour: '$showtime' }, timeFilter.$gte] },
                        { $lte: [{ $hour: '$showtime' }, timeFilter.$lte] }
                    ]
                }
            };
        }

        return await Screening.find(filter)
            .populate('filmId')
            .populate('cinemaId')
            .sort({ showtime: 1 });
    }

    async filterAvailableSeats(screeningId) {
        const screening = await Screening.findById(screeningId)
            .populate('cinemaId')
            .populate({
                path: 'bookings',
                match: { status: 'active' }
            });

        if (!screening) {
            throw new Error('Screening not found');
        }

        const cinema = screening.cinemaId;
        const bookedSeats = screening.bookings.reduce((acc, booking) => {
            return [...acc, ...booking.seats];
        }, []);

        // Calculate available seats
        const availableSeats = {
            lowerHall: [],
            upperGallery: [],
            vipSeats: []
        };

        Object.keys(cinema.screens[0].capacity).forEach(section => {
            for (let i = 1; i <= cinema.screens[0].capacity[section]; i++) {
                if (!bookedSeats.find(seat => 
                    seat.type === section && seat.seatNumber === i
                )) {
                    availableSeats[section].push(i);
                }
            }
        });

        return availableSeats;
    }
}

module.exports = new SearchService(); 