const { io } = require('../app');
const Booking = require('../models/Booking');
const Screening = require('../models/Screening');

class SeatService {
    async updateAvailableSeats(screeningId) {
        const screening = await Screening.findById(screeningId)
            .populate('cinemaId')
            .populate({
                path: 'bookings',
                match: { status: 'active' }
            });

        if (!screening) {
            throw new Error('Screening not found');
        }

        const bookedSeats = screening.bookings.reduce((acc, booking) => {
            return [...acc, ...booking.seats];
        }, []);

        const availableSeats = {
            lowerHall: [],
            upperGallery: [],
            vipSeats: []
        };

        Object.keys(screening.cinemaId.screens[0].capacity).forEach(section => {
            for (let i = 1; i <= screening.cinemaId.screens[0].capacity[section]; i++) {
                if (!bookedSeats.find(seat => 
                    seat.type === section && seat.seatNumber === i
                )) {
                    availableSeats[section].push(i);
                }
            }
        });

        // Emit updated seat availability to all connected clients
        io.emit(`seat-update:${screeningId}`, availableSeats);
    }
}

module.exports = new SeatService(); 