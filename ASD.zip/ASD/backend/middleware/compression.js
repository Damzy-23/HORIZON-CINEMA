const compression = require('compression');

const shouldCompress = (req, res) => {
    if (req.headers['x-no-compression']) {
        return false;
    }
    
    // Compress everything except images and PDFs
    const contentType = res.getHeader('Content-Type');
    if (contentType && (
        contentType.includes('image') ||
        contentType.includes('pdf')
    )) {
        return false;
    }
    
    return compression.filter(req, res);
};

module.exports = compression({
    filter: shouldCompress,
    level: 6, // compression level
    threshold: 1024 // only compress responses bigger than 1KB
}); 