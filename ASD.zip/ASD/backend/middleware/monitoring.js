const metricsService = require('../services/metricsService');
const loggingService = require('../services/loggingService');

const monitorRequest = (req, res, next) => {
    const start = Date.now();
    
    // Add response listener
    res.on('finish', () => {
        const duration = (Date.now() - start) / 1000; // Convert to seconds
        const route = req.route ? req.route.path : req.path;
        
        // Record metrics
        metricsService.recordHttpRequest(
            req.method,
            route,
            res.statusCode,
            duration
        );

        // Log request details
        loggingService.info('Request processed', {
            method: req.method,
            path: req.path,
            statusCode: res.statusCode,
            duration: `${duration}s`,
            ip: req.ip
        });
    });

    next();
};

module.exports = monitorRequest; 