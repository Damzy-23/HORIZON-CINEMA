const { body, validationResult } = require('express-validator');

const validateFilm = [
    body('title').notEmpty().withMessage('Title is required').trim().escape(),
    body('genre').notEmpty().withMessage('Genre is required').trim().escape(),
    body('ageRating').notEmpty().withMessage('Age rating is required').trim().escape(),
    body('description').notEmpty().withMessage('Description is required').trim().escape()
];

const validateScreening = [
    body('filmId').notEmpty().withMessage('Film ID is required').trim().escape(),
    body('showtime').isISO8601().withMessage('Showtime must be a valid date').toDate(),
    body('screenNumber').isInt({ min: 1 }).withMessage('Screen number must be a positive integer')
];

const validateBooking = [
    body('customerName').notEmpty().withMessage('Customer name is required').trim().escape(),
    body('customerEmail').isEmail().withMessage('Email must be valid').normalizeEmail(),
    body('seats').isArray().withMessage('Seats must be an array').notEmpty()
];

const handleValidationErrors = (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }
    next();
};

module.exports = {
    validateFilm,
    validateScreening,
    validateBooking,
    handleValidationErrors
}; 