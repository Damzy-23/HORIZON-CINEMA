const express = require('express');
const router = express.Router();
const searchController = require('../controllers/searchController');

// Search films
router.get('/search/films', searchController.searchFilms);

// Search screenings
router.get('/search/screenings', searchController.searchScreenings);

// Get available seats
router.get('/screenings/:screeningId/available-seats', 
    searchController.getAvailableSeats
);

module.exports = router; 