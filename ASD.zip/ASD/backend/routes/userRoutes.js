const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const { auth } = require('../middleware/auth');

// All routes require authentication
router.use(auth);

// Get user profile
router.get('/profile', userController.getUserProfile);

// Update profile
router.put('/profile', userController.updateProfile);

// Change password
router.post('/profile/change-password', userController.changePassword);

// Update preferences
router.put('/profile/preferences', userController.updatePreferences);

// Get activity log
router.get('/profile/activity', userController.getActivityLog);

module.exports = router; 