const express = require('express');
const router = express.Router();
const reportController = require('../controllers/reportController');
const { auth, checkRole } = require('../middleware/auth');

// All routes require authentication and admin/manager role
router.use(auth, checkRole(['admin', 'manager']));

// Revenue reports
router.get('/reports/revenue', reportController.getRevenueReport);

// Top performing films
router.get('/reports/films', reportController.getTopFilms);

// Staff performance report
router.get('/reports/staff', reportController.getStaffPerformance);

// Occupancy rates
router.get('/reports/occupancy', reportController.getOccupancyRates);

module.exports = router; 