const express = require('express');
const router = express.Router();
const cinemaController = require('../controllers/cinemaController');
const { auth, checkRole } = require('../middleware/auth');
const validate = require('../middleware/validator');

// Public routes
router.get('/cinemas', cinemaController.getAllCinemas);
router.get('/cinemas/:id', cinemaController.getCinemaById);
router.get('/cinemas/:id/screenings', cinemaController.getCinemaScreenings);

// Protected routes - require manager role
router.post('/cinemas', 
    auth, 
    checkRole(['manager']), 
    validate('cinema'),
    cinemaController.createCinema
);

router.put('/cinemas/:id', 
    auth, 
    checkRole(['manager']), 
    validate('cinema'),
    cinemaController.updateCinema
);

router.delete('/cinemas/:id', 
    auth, 
    checkRole(['manager']), 
    cinemaController.deleteCinema
);

// Stats route - requires admin or manager role
router.get('/cinemas/:id/stats', 
    auth, 
    checkRole(['admin', 'manager']), 
    cinemaController.getCinemaStats
);

module.exports = router; 