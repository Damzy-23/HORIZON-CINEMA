#!/bin/bash

# Exit on error
set -e

# Load environment variables
source .env

# Check if Docker is running
if ! docker info > /dev/null 2>&1; then
    echo "Docker is not running. Please start Docker and try again."
    exit 1
fi

# Build and deploy the application
echo "🚀 Deploying Cinema Booking System..."

# Pull latest changes
echo "📥 Pulling latest changes..."
git pull origin main

# Build and start containers
echo "🏗️ Building and starting containers..."
docker-compose up -d --build

# Wait for services to be ready
echo "⏳ Waiting for services to be ready..."
sleep 10

# Check if services are running
echo "🔍 Checking services..."
if docker-compose ps | grep -q "Exit"; then
    echo "❌ Some services failed to start. Check logs with 'docker-compose logs'"
    exit 1
fi

# Run database migrations if needed
echo "🔄 Running database migrations..."
docker-compose exec backend npm run migrate

# Clear cache
echo "🧹 Clearing cache..."
docker-compose exec frontend nginx -s reload

echo "✅ Deployment completed successfully!"
echo "🌐 Application is now available at http://localhost"

# Print logs
echo "📋 Recent logs:"
docker-compose logs --tail=50 