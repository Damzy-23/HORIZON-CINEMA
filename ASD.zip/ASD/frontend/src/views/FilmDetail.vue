<template>
    <div>
        <h2>{{ film.title }}</h2>
        <p>{{ film.description }}</p>
        <p>Average Rating: {{ film.averageRating }}</p>

        <FeedbackForm :filmId="film._id" @feedback-submitted="fetchFeedback" />
        <FeedbackList :filmId="film._id" />
    </div>
</template>

<script>
import FeedbackForm from '@/components/FeedbackForm.vue';
import FeedbackList from '@/components/FeedbackList.vue';

export default {
    data() {
        return {
            film: {}
        }
    },
    components: {
        FeedbackForm,
        FeedbackList
    },
    async mounted() {
        await this.fetchFilm();
    },
    methods: {
        async fetchFilm() {
            const response = await this.$axios.get(`/api/films/${this.$route.params.id}`);
            this.film = response.data;
        }
    }
}
</script> 