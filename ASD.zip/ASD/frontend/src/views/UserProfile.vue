<template>
    <div class="user-profile">
        <div class="container py-4">
            <div class="row">
                <!-- Profile Navigation -->
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body">
                            <div class="profile-nav">
                                <div class="nav flex-column nav-pills">
                                    <button class="nav-link"
                                            :class="{ active: currentTab === 'profile' }"
                                            @click="currentTab = 'profile'">
                                        Profile Details
                                    </button>
                                    <button class="nav-link"
                                            :class="{ active: currentTab === 'password' }"
                                            @click="currentTab = 'password'">
                                        Change Password
                                    </button>
                                    <button class="nav-link"
                                            :class="{ active: currentTab === 'preferences' }"
                                            @click="currentTab = 'preferences'">
                                        Preferences
                                    </button>
                                    <button class="nav-link"
                                            :class="{ active: currentTab === 'activity' }"
                                            @click="currentTab = 'activity'">
                                        Activity Log
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Profile Content -->
                <div class="col-md-9">
                    <div class="card">
                        <div class="card-body">
                            <!-- Profile Details -->
                            <div v-if="currentTab === 'profile'" class="profile-details">
                                <h4 class="mb-4">Profile Details</h4>
                                <form @submit.prevent="updateProfile">
                                    <div class="mb-3">
                                        <label class="form-label">Username</label>
                                        <input type="text" 
                                               class="form-control"
                                               v-model="profile.username"
                                               required>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Email</label>
                                        <input type="email" 
                                               class="form-control"
                                               v-model="profile.email"
                                               required>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Role</label>
                                        <input type="text" 
                                               class="form-control"
                                               :value="profile.role"
                                               disabled>
                                    </div>

                                    <button type="submit" 
                                            class="btn btn-primary"
                                            :disabled="isLoading">
                                        {{ isLoading ? 'Saving...' : 'Save Changes' }}
                                    </button>
                                </form>
                            </div>

                            <!-- Change Password -->
                            <div v-if="currentTab === 'password'" class="password-change">
                                <h4 class="mb-4">Change Password</h4>
                                <form @submit.prevent="changePassword">
                                    <div class="mb-3">
                                        <label class="form-label">Current Password</label>
                                        <input type="password" 
                                               class="form-control"
                                               v-model="passwordForm.currentPassword"
                                               required>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">New Password</label>
                                        <input type="password" 
                                               class="form-control"
                                               v-model="passwordForm.newPassword"
                                               required>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Confirm New Password</label>
                                        <input type="password" 
                                               class="form-control"
                                               v-model="passwordForm.confirmPassword"
                                               required>
                                    </div>

                                    <button type="submit" 
                                            class="btn btn-primary"
                                            :disabled="isLoading">
                                        {{ isLoading ? 'Changing...' : 'Change Password' }}
                                    </button>
                                </form>
                            </div>

                            <!-- Preferences -->
                            <div v-if="currentTab === 'preferences'" class="preferences">
                                <h4 class="mb-4">Preferences</h4>
                                <form @submit.prevent="updatePreferences">
                                    <div class="mb-3">
                                        <label class="form-label">Default Cinema</label>
                                        <select class="form-select"
                                                v-model="preferences.defaultCinema">
                                            <option value="">Select Cinema</option>
                                            <option v-for="cinema in cinemas" 
                                                    :key="cinema._id" 
                                                    :value="cinema._id">
                                                {{ cinema.name }}
                                            </option>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Email Notifications</label>
                                        <div class="form-check">
                                            <input class="form-check-input" 
                                                   type="checkbox"
                                                   v-model="preferences.emailNotifications">
                                            <label class="form-check-label">
                                                Receive email notifications
                                            </label>
                                        </div>
                                    </div>

                                    <button type="submit" 
                                            class="btn btn-primary"
                                            :disabled="isLoading">
                                        {{ isLoading ? 'Saving...' : 'Save Preferences' }}
                                    </button>
                                </form>
                            </div>

                            <!-- Activity Log -->
                            <div v-if="currentTab === 'activity'" class="activity-log">
                                <h4 class="mb-4">Activity Log</h4>
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>Date</th>
                                                <th>Action</th>
                                                <th>Details</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr v-for="log in activityLogs" 
                                                :key="log._id">
                                                <td>{{ formatDate(log.timestamp) }}</td>
                                                <td>{{ log.action }}</td>
                                                <td>{{ log.details }}</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            currentTab: 'profile',
            isLoading: false,
            profile: {
                username: '',
                email: '',
                role: ''
            },
            passwordForm: {
                currentPassword: '',
                newPassword: '',
                confirmPassword: ''
            },
            preferences: {
                defaultCinema: '',
                emailNotifications: true
            },
            activityLogs: [],
            cinemas: [],
            error: null
        }
    },
    methods: {
        async fetchProfile() {
            try {
                const response = await fetch('/api/profile', {
                    headers: {
                        'Authorization': `Bearer ${localStorage.getItem('token')}`
                    }
                });
                const data = await response.json();
                this.profile = data;
                this.preferences = data.preferences || this.preferences;
            } catch (error) {
                console.error('Error fetching profile:', error);
                this.$toast.error('Failed to load profile');
            }
        },
        async updateProfile() {
            this.isLoading = true;
            try {
                const response = await fetch('/api/profile', {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${localStorage.getItem('token')}`
                    },
                    body: JSON.stringify(this.profile)
                });

                if (!response.ok) throw new Error('Failed to update profile');
                
                this.$toast.success('Profile updated successfully');
            } catch (error) {
                console.error('Error updating profile:', error);
                this.$toast.error('Failed to update profile');
            } finally {
                this.isLoading = false;
            }
        },
        async changePassword() {
            if (this.passwordForm.newPassword !== this.passwordForm.confirmPassword) {
                this.$toast.error('Passwords do not match');
                return;
            }

            this.isLoading = true;
            try {
                const response = await fetch('/api/profile/change-password', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${localStorage.getItem('token')}`
                    },
                    body: JSON.stringify({
                        currentPassword: this.passwordForm.currentPassword,
                        newPassword: this.passwordForm.newPassword
                    })
                });

                if (!response.ok) throw new Error('Failed to change password');
                
                this.$toast.success('Password changed successfully');
                this.passwordForm = {
                    currentPassword: '',
                    newPassword: '',
                    confirmPassword: ''
                };
            } catch (error) {
                console.error('Error changing password:', error);
                this.$toast.error('Failed to change password');
            } finally {
                this.isLoading = false;
            }
        },
        async updatePreferences() {
            this.isLoading = true;
            try {
                const response = await fetch('/api/profile/preferences', {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${localStorage.getItem('token')}`
                    },
                    body: JSON.stringify({ preferences: this.preferences })
                });

                if (!response.ok) throw new Error('Failed to update preferences');
                
                this.$toast.success('Preferences updated successfully');
            } catch (error) {
                console.error('Error updating preferences:', error);
                this.$toast.error('Failed to update preferences');
            } finally {
                this.isLoading = false;
            }
        },
        async fetchActivityLog() {
            try {
                const response = await fetch('/api/profile/activity', {
                    headers: {
                        'Authorization': `Bearer ${localStorage.getItem('token')}`
                    }
                });
                this.activityLogs = await response.json();
            } catch (error) {
                console.error('Error fetching activity log:', error);
                this.$toast.error('Failed to load activity log');
            }
        },
        formatDate(date) {
            return new Date(date).toLocaleString();
        }
    },
    async mounted() {
        await this.fetchProfile();
        if (this.currentTab === 'activity') {
            await this.fetchActivityLog();
        }
    },
    watch: {
        currentTab(newTab) {
            if (newTab === 'activity') {
                this.fetchActivityLog();
            }
        }
    }
}
</script>

<style scoped>
.profile-nav {
    .nav-link {
        text-align: left;
        padding: 0.5rem 1rem;
        margin-bottom: 0.25rem;
        border-radius: 0.25rem;
        cursor: pointer;
        
        &:hover {
            background-color: #f8f9fa;
        }
        
        &.active {
            background-color: #0d6efd;
            color: white;
        }
    }
}

.card {
    box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
}

.activity-log {
    max-height: 500px;
    overflow-y: auto;
}
</style> 