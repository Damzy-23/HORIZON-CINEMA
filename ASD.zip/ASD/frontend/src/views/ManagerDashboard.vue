<template>
    <div class="manager-dashboard">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Cinema Management</h2>
            <button class="btn btn-primary" @click="showAddCinemaModal">
                Add New Cinema
            </button>
        </div>

        <!-- Cinemas List -->
        <div class="row">
            <div class="col-md-4 mb-4" v-for="cinema in cinemas" :key="cinema._id">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">{{ cinema.name }}</h5>
                        <h6 class="card-subtitle mb-2 text-muted">{{ cinema.city }}</h6>
                        <p class="card-text">{{ cinema.location }}</p>
                        
                        <div class="mb-3">
                            <strong>Screens:</strong> {{ cinema.screens.length }}
                        </div>
                        
                        <div class="mb-3">
                            <strong>Price Ranges:</strong>
                            <ul class="list-unstyled">
                                <li>Morning: £{{ cinema.priceRanges.morningShow }}</li>
                                <li>Afternoon: £{{ cinema.priceRanges.afternoonShow }}</li>
                                <li>Evening: £{{ cinema.priceRanges.eveningShow }}</li>
                            </ul>
                        </div>

                        <div class="btn-group">
                            <button class="btn btn-info btn-sm" 
                                    @click="editCinema(cinema)">
                                Edit
                            </button>
                            <button class="btn btn-danger btn-sm" 
                                    @click="deleteCinema(cinema._id)">
                                Delete
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Statistics Cards -->
        <div class="row mt-4">
            <div class="col-md-4">
                <div class="card bg-primary text-white">
                    <div class="card-body">
                        <h5 class="card-title">Total Cinemas</h5>
                        <h2>{{ cinemas.length }}</h2>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-success text-white">
                    <div class="card-body">
                        <h5 class="card-title">Total Screens</h5>
                        <h2>{{ totalScreens }}</h2>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-info text-white">
                    <div class="card-body">
                        <h5 class="card-title">Cities Covered</h5>
                        <h2>{{ uniqueCities.length }}</h2>
                    </div>
                </div>
            </div>
        </div>

        <!-- Cinema Modal -->
        <CinemaModal 
            ref="cinemaModal"
            :cinema="selectedCinema"
            @save="saveCinema" />
    </div>
</template>

<script>
import CinemaModal from '../components/CinemaModal.vue'

export default {
    components: {
        CinemaModal
    },
    data() {
        return {
            cinemas: [],
            selectedCinema: null
        }
    },
    computed: {
        totalScreens() {
            return this.cinemas.reduce((total, cinema) => 
                total + cinema.screens.length, 0)
        },
        uniqueCities() {
            return [...new Set(this.cinemas.map(cinema => cinema.city))]
        }
    },
    methods: {
        async fetchCinemas() {
            try {
                const response = await fetch('/api/cinemas')
                this.cinemas = await response.json()
            } catch (error) {
                console.error('Error fetching cinemas:', error)
                this.$toast.error('Failed to load cinemas')
            }
        },
        showAddCinemaModal() {
            this.selectedCinema = null
            this.$refs.cinemaModal.show()
        },
        editCinema(cinema) {
            this.selectedCinema = cinema
            this.$refs.cinemaModal.show()
        },
        async saveCinema(cinemaData) {
            try {
                const url = cinemaData._id ? 
                    `/api/cinemas/${cinemaData._id}` : 
                    '/api/cinemas'
                const method = cinemaData._id ? 'PUT' : 'POST'

                const response = await fetch(url, {
                    method,
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(cinemaData)
                })

                if (!response.ok) throw new Error('Failed to save cinema')

                await this.fetchCinemas()
                this.$toast.success('Cinema saved successfully')
            } catch (error) {
                console.error('Error saving cinema:', error)
                this.$toast.error('Failed to save cinema')
            }
        },
        async deleteCinema(cinemaId) {
            if (!confirm('Are you sure you want to delete this cinema?')) return

            try {
                const response = await fetch(`/api/cinemas/${cinemaId}`, {
                    method: 'DELETE'
                })

                if (!response.ok) throw new Error('Failed to delete cinema')

                await this.fetchCinemas()
                this.$toast.success('Cinema deleted successfully')
            } catch (error) {
                console.error('Error deleting cinema:', error)
                this.$toast.error('Failed to delete cinema')
            }
        }
    },
    mounted() {
        this.fetchCinemas()
    }
}
</script>

<style scoped>
.card {
    height: 100%;
}

.statistics-card {
    text-align: center;
    padding: 20px;
}

.btn-group {
    gap: 5px;
}
</style> 