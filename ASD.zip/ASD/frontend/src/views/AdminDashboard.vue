<template>
    <div class="admin-dashboard">
        <h2>Admin Dashboard</h2>
        <div class="nav nav-tabs">
            <button class="nav-link" :class="{ active: currentTab === 'films' }" @click="currentTab = 'films'">Manage Films</button>
            <button class="nav-link" :class="{ active: currentTab === 'screenings' }" @click="currentTab = 'screenings'">Manage Screenings</button>
            <button class="nav-link" :class="{ active: currentTab === 'bookings' }" @click="currentTab = 'bookings'">Manage Bookings</button>
        </div>

        <div class="tab-content">
            <div v-if="currentTab === 'films'">
                <ManageFilms @film-updated="fetchFilms" />
            </div>
            <div v-if="currentTab === 'screenings'">
                <ManageScreenings @screening-updated="fetchScreenings" />
            </div>
            <div v-if="currentTab === 'bookings'">
                <ManageBookings @booking-updated="fetchBookings" />
            </div>
        </div>
    </div>
</template>

<script>
import ManageFilms from '@/components/ManageFilms.vue';
import ManageScreenings from '@/components/ManageScreenings.vue';
import ManageBookings from '@/components/ManageBookings.vue';

export default {
    data() {
        return {
            currentTab: 'films'
        }
    },
    components: {
        ManageFilms,
        ManageScreenings,
        ManageBookings
    },
    methods: {
        fetchFilms() {
            // Logic to fetch films
        },
        fetchScreenings() {
            // Logic to fetch screenings
        },
        fetchBookings() {
            // Logic to fetch bookings
        }
    }
}
</script>

<style scoped>
.admin-dashboard {
    padding: 20px;
}

.nav-tabs {
    margin-bottom: 20px;
}

.tab-content {
    border: 1px solid #ddd;
    padding: 20px;
}
</style> 