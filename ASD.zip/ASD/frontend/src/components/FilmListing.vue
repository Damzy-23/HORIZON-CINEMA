<template>
    <div class="film-listing">
        <div class="filters mb-4">
            <div class="row">
                <div class="col-md-3">
                    <select v-model="selectedCity" class="form-select">
                        <option value="">Select City</option>
                        <option v-for="city in cities" :key="city" :value="city">
                            {{ city }}
                        </option>
                    </select>
                </div>
                <div class="col-md-3">
                    <select v-model="selectedCinema" class="form-select">
                        <option value="">Select Cinema</option>
                        <option v-for="cinema in filteredCinemas" 
                                :key="cinema._id" 
                                :value="cinema._id">
                            {{ cinema.name }}
                        </option>
                    </select>
                </div>
                <div class="col-md-3">
                    <input type="date" 
                           v-model="selectedDate" 
                           class="form-control"
                           :min="today">
                </div>
            </div>
        </div>

        <div class="films-grid">
            <div v-for="film in films" :key="film._id" class="film-card">
                <div class="card">
                    <img :src="film.posterUrl" class="card-img-top" :alt="film.title">
                    <div class="card-body">
                        <h5 class="card-title">{{ film.title }}</h5>
                        <p class="card-text">{{ film.description }}</p>
                        <div class="showtimes">
                            <button v-for="screening in film.screenings" 
                                    :key="screening._id"
                                    class="btn btn-outline-primary me-2"
                                    @click="selectScreening(screening)">
                                {{ formatTime(screening.showtime) }}
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Booking Modal -->
        <div class="modal fade" id="bookingModal" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Book Tickets</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <!-- Booking form will go here -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            cities: ['Birmingham', 'Bristol', 'Cardiff', 'London'],
            selectedCity: '',
            selectedCinema: '',
            selectedDate: '',
            cinemas: [],
            films: [],
            today: new Date().toISOString().split('T')[0]
        }
    },
    computed: {
        filteredCinemas() {
            return this.cinemas.filter(cinema => 
                cinema.city === this.selectedCity
            )
        }
    },
    methods: {
        async fetchCinemas() {
            try {
                const response = await fetch('/api/cinemas');
                this.cinemas = await response.json();
            } catch (error) {
                console.error('Error fetching cinemas:', error);
            }
        },
        async fetchFilms() {
            if (!this.selectedCinema || !this.selectedDate) return;
            
            try {
                const response = await fetch(
                    `/api/screenings?cinemaId=${this.selectedCinema}&date=${this.selectedDate}`
                );
                this.films = await response.json();
            } catch (error) {
                console.error('Error fetching films:', error);
            }
        },
        formatTime(datetime) {
            return new Date(datetime).toLocaleTimeString('en-US', {
                hour: '2-digit',
                minute: '2-digit'
            });
        },
        selectScreening(screening) {
            // Open booking modal
            const modal = new bootstrap.Modal(document.getElementById('bookingModal'));
            modal.show();
        }
    },
    watch: {
        selectedCity() {
            this.selectedCinema = '';
            this.films = [];
        },
        selectedCinema() {
            this.fetchFilms();
        },
        selectedDate() {
            this.fetchFilms();
        }
    },
    mounted() {
        this.fetchCinemas();
    }
}
</script>

<style scoped>
.film-card {
    margin-bottom: 20px;
}

.showtimes {
    margin-top: 10px;
}
</style> 