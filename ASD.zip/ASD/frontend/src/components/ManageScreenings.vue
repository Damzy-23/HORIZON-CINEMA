<template>
    <div class="manage-screenings">
        <h3>Manage Screenings</h3>
        <form @submit.prevent="handleSubmit">
            <div class="mb-3">
                <label class="form-label">Film</label>
                <select class="form-select" v-model="screening.filmId" required>
                    <option v-for="film in films" :key="film._id" :value="film._id">{{ film.title }}</option>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Showtime</label>
                <input type="datetime-local" class="form-control" v-model="screening.showtime" required />
            </div>
            <div class="mb-3">
                <label class="form-label">Screen Number</label>
                <input type="number" class="form-control" v-model="screening.screenNumber" required />
            </div>
            <button type="submit" class="btn btn-primary">Save Screening</button>
        </form>

        <h4 class="mt-4">Existing Screenings</h4>
        <ul class="list-group">
            <li v-for="screening in screenings" :key="screening._id" class="list-group-item">
                {{ screening.film.title }} - {{ new Date(screening.showtime).toLocaleString() }} 
                <button class="btn btn-danger btn-sm float-end" @click="deleteScreening(screening._id)">Delete</button>
            </li>
        </ul>
    </div>
</template>

<script>
export default {
    data() {
        return {
            screening: {
                filmId: '',
                showtime: '',
                screenNumber: ''
            },
            films: [],
            screenings: []
        }
    },
    methods: {
        async handleSubmit() {
            try {
                await this.$axios.post('/api/screenings', this.screening);
                this.fetchScreenings();
                this.resetForm();
            } catch (error) {
                console.error('Error saving screening:', error);
            }
        },
        async fetchFilms() {
            try {
                const response = await this.$axios.get('/api/films');
                this.films = response.data;
            } catch (error) {
                console.error('Error fetching films:', error);
            }
        },
        async fetchScreenings() {
            try {
                const response = await this.$axios.get('/api/screenings');
                this.screenings = response.data;
            } catch (error) {
                console.error('Error fetching screenings:', error);
            }
        },
        async deleteScreening(screeningId) {
            try {
                await this.$axios.delete(`/api/screenings/${screeningId}`);
                this.fetchScreenings();
            } catch (error) {
                console.error('Error deleting screening:', error);
            }
        },
        resetForm() {
            this.screening = {
                filmId: '',
                showtime: '',
                screenNumber: ''
            };
        }
    },
    mounted() {
        this.fetchFilms();
        this.fetchScreenings();
    }
}
</script>

<style scoped>
.manage-screenings {
    margin-top: 20px;
}

.list-group-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
}
</style> 