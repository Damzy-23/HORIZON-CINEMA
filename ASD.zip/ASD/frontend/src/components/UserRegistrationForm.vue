<template>
    <div class="modal fade" ref="modal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Create New User</h5>
                    <button type="button" 
                            class="btn-close" 
                            data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form @submit.prevent="handleSubmit">
                        <div class="mb-3">
                            <label class="form-label">Username</label>
                            <input type="text" 
                                   class="form-control"
                                   v-model="formData.username"
                                   required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Password</label>
                            <input type="password" 
                                   class="form-control"
                                   v-model="formData.password"
                                   required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Role</label>
                            <select class="form-select"
                                    v-model="formData.role"
                                    required>
                                <option value="">Select Role</option>
                                <option value="staff">Staff</option>
                                <option value="admin">Admin</option>
                            </select>
                        </div>

                        <div class="mb-3" v-if="formData.role === 'staff'">
                            <label class="form-label">Assigned Cinema</label>
                            <select class="form-select"
                                    v-model="formData.cinemaId"
                                    required>
                                <option value="">Select Cinema</option>
                                <option v-for="cinema in cinemas" 
                                        :key="cinema._id" 
                                        :value="cinema._id">
                                    {{ cinema.name }}
                                </option>
                            </select>
                        </div>

                        <div v-if="error" class="alert alert-danger">
                            {{ error }}
                        </div>

                        <div class="modal-footer">
                            <button type="button" 
                                    class="btn btn-secondary"
                                    data-bs-dismiss="modal">
                                Cancel
                            </button>
                            <button type="submit" 
                                    class="btn btn-primary"
                                    :disabled="isLoading">
                                {{ isLoading ? 'Creating...' : 'Create User' }}
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import { Modal } from 'bootstrap'

export default {
    props: {
        cinemas: {
            type: Array,
            required: true
        }
    },
    data() {
        return {
            modal: null,
            formData: {
                username: '',
                password: '',
                role: '',
                cinemaId: ''
            },
            error: null,
            isLoading: false
        }
    },
    methods: {
        show() {
            this.resetForm()
            this.modal.show()
        },
        hide() {
            this.modal.hide()
        },
        resetForm() {
            this.formData = {
                username: '',
                password: '',
                role: '',
                cinemaId: ''
            }
            this.error = null
        },
        async handleSubmit() {
            this.error = null
            this.isLoading = true

            try {
                const response = await fetch('/api/auth/register', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${localStorage.getItem('token')}`
                    },
                    body: JSON.stringify(this.formData)
                })

                const data = await response.json()

                if (!response.ok) {
                    throw new Error(data.error || 'Failed to create user')
                }

                this.$emit('user-created', data.user)
                this.hide()
                this.$toast.success('User created successfully')
            } catch (error) {
                this.error = error.message
            } finally {
                this.isLoading = false
            }
        }
    },
    mounted() {
        this.modal = new Modal(this.$refs.modal)
    }
}
</script> 