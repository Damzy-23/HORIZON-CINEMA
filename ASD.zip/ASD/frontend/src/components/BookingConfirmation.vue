<template>
    <div class="booking-confirmation">
        <!-- ... existing confirmation details ... -->
        
        <div class="ticket-downloads mt-4">
            <h4>Download Tickets</h4>
            <div class="btn-group">
                <button class="btn btn-primary"
                        @click="downloadTicket"
                        :disabled="isDownloading">
                    {{ isDownloading ? 'Downloading...' : 'Download Combined Ticket' }}
                </button>
                <button class="btn btn-outline-primary"
                        @click="downloadIndividualTickets"
                        :disabled="isDownloading">
                    Download Individual Tickets
                </button>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    props: {
        booking: {
            type: Object,
            required: true
        }
    },
    data() {
        return {
            isDownloading: false
        }
    },
    methods: {
        async downloadTicket() {
            this.isDownloading = true;
            try {
                const response = await fetch(
                    `/api/bookings/${this.booking.bookingReference}/ticket`,
                    {
                        headers: {
                            'Authorization': `Bearer ${localStorage.getItem('token')}`
                        }
                    }
                );

                if (!response.ok) throw new Error('Failed to download ticket');

                // Create blob from response
                const blob = await response.blob();
                const url = window.URL.createObjectURL(blob);
                
                // Create temporary link and trigger download
                const a = document.createElement('a');
                a.href = url;
                a.download = `ticket-${this.booking.bookingReference}.pdf`;
                document.body.appendChild(a);
                a.click();
                window.URL.revokeObjectURL(url);
                a.remove();
            } catch (error) {
                console.error('Error downloading ticket:', error);
                this.$toast.error('Failed to download ticket');
            } finally {
                this.isDownloading = false;
            }
        },
        async downloadIndividualTickets() {
            this.isDownloading = true;
            try {
                const response = await fetch(
                    `/api/bookings/${this.booking.bookingReference}/tickets/individual`,
                    {
                        headers: {
                            'Authorization': `Bearer ${localStorage.getItem('token')}`
                        }
                    }
                );

                if (!response.ok) throw new Error('Failed to download tickets');

                const blob = await response.blob();
                const url = window.URL.createObjectURL(blob);
                
                const a = document.createElement('a');
                a.href = url;
                a.download = `tickets-${this.booking.bookingReference}.pdf`;
                document.body.appendChild(a);
                a.click();
                window.URL.revokeObjectURL(url);
                a.remove();
            } catch (error) {
                console.error('Error downloading tickets:', error);
                this.$toast.error('Failed to download tickets');
            } finally {
                this.isDownloading = false;
            }
        }
    }
}
</script> 