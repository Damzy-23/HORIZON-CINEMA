<template>
    <div class="manage-films">
        <h3>Manage Films</h3>
        <form @submit.prevent="handleSubmit">
            <div class="mb-3">
                <label class="form-label">Film Title</label>
                <input type="text" class="form-control" v-model="film.title" required />
            </div>
            <div class="mb-3">
                <label class="form-label">Genre</label>
                <input type="text" class="form-control" v-model="film.genre" required />
            </div>
            <div class="mb-3">
                <label class="form-label">Age Rating</label>
                <input type="text" class="form-control" v-model="film.ageRating" required />
            </div>
            <div class="mb-3">
                <label class="form-label">Description</label>
                <textarea class="form-control" v-model="film.description" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Save Film</button>
        </form>

        <h4 class="mt-4">Existing Films</h4>
        <ul class="list-group">
            <li v-for="film in films" :key="film._id" class="list-group-item">
                {{ film.title }} 
                <button class="btn btn-danger btn-sm float-end" @click="deleteFilm(film._id)">Delete</button>
            </li>
        </ul>
    </div>
</template>

<script>
export default {
    data() {
        return {
            film: {
                title: '',
                genre: '',
                ageRating: '',
                description: ''
            },
            films: []
        }
    },
    methods: {
        async handleSubmit() {
            try {
                await this.$axios.post('/api/films', this.film);
                this.fetchFilms();
                this.resetForm();
            } catch (error) {
                console.error('Error saving film:', error);
            }
        },
        async fetchFilms() {
            try {
                const response = await this.$axios.get('/api/films');
                this.films = response.data;
            } catch (error) {
                console.error('Error fetching films:', error);
            }
        },
        async deleteFilm(filmId) {
            try {
                await this.$axios.delete(`/api/films/${filmId}`);
                this.fetchFilms();
            } catch (error) {
                console.error('Error deleting film:', error);
            }
        },
        resetForm() {
            this.film = {
                title: '',
                genre: '',
                ageRating: '',
                description: ''
            };
        }
    },
    mounted() {
        this.fetchFilms();
    }
}
</script>

<style scoped>
.manage-films {
    margin-top: 20px;
}

.list-group-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
}
</style> 