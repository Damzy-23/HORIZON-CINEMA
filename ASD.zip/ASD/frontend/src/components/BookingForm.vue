<template>
    <div class="booking-form">
        <form @submit.prevent="submitBooking">
            <!-- Customer Details -->
            <div class="customer-details mb-4">
                <h5>Customer Information</h5>
                <div class="mb-3">
                    <label class="form-label">Name</label>
                    <input type="text" 
                           v-model="customerName" 
                           class="form-control" 
                           required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" 
                           v-model="customerEmail" 
                           class="form-control" 
                           required>
                </div>
            </div>

            <!-- Film Details -->
            <div class="film-details mb-4">
                <h5>Screening Details</h5>
                <div class="card">
                    <div class="card-body">
                        <h6>{{ screening.film.title }}</h6>
                        <p class="mb-1">
                            <strong>Date:</strong> 
                            {{ formatDate(screening.showtime) }}
                        </p>
                        <p class="mb-1">
                            <strong>Time:</strong> 
                            {{ formatTime(screening.showtime) }}
                        </p>
                        <p class="mb-1">
                            <strong>Screen:</strong> 
                            {{ screening.screenNumber }}
                        </p>
                    </div>
                </div>
            </div>

            <!-- Seat Selection -->
            <div class="seat-selection mb-4">
                <h5>Select Seats</h5>
                <SeatSelection 
                    :screening="screening"
                    @seats-changed="updateSelectedSeats" />
            </div>

            <!-- Price Summary -->
            <div class="price-summary mb-4">
                <h5>Booking Summary</h5>
                <div class="card">
                    <div class="card-body">
                        <div v-if="selectedSeats.vip.length">
                            <p>VIP Seats ({{ selectedSeats.vip.length }}): 
                               £{{ (selectedSeats.vip.length * screening.price.vipSeats).toFixed(2) }}</p>
                        </div>
                        <div v-if="selectedSeats.upperGallery.length">
                            <p>Upper Gallery ({{ selectedSeats.upperGallery.length }}): 
                               £{{ (selectedSeats.upperGallery.length * screening.price.upperGallery).toFixed(2) }}</p>
                        </div>
                        <div v-if="selectedSeats.lowerHall.length">
                            <p>Lower Hall ({{ selectedSeats.lowerHall.length }}): 
                               £{{ (selectedSeats.lowerHall.length * screening.price.lowerHall).toFixed(2) }}</p>
                        </div>
                        <hr>
                        <h6>Total: £{{ totalPrice.toFixed(2) }}</h6>
                    </div>
                </div>
            </div>

            <!-- Submit Button -->
            <button type="submit" 
                    class="btn btn-primary w-100"
                    :disabled="!isValidBooking">
                Confirm Booking
            </button>
        </form>
    </div>
</template>

<script>
import SeatSelection from './SeatSelection.vue'

export default {
    components: {
        SeatSelection
    },
    props: {
        screening: {
            type: Object,
            required: true
        }
    },
    data() {
        return {
            customerName: '',
            customerEmail: '',
            selectedSeats: {
                vip: [],
                upperGallery: [],
                lowerHall: []
            }
        }
    },
    computed: {
        totalPrice() {
            return (
                this.selectedSeats.vip.length * this.screening.price.vipSeats +
                this.selectedSeats.upperGallery.length * this.screening.price.upperGallery +
                this.selectedSeats.lowerHall.length * this.screening.price.lowerHall
            )
        },
        isValidBooking() {
            return this.customerName && 
                   this.customerEmail && 
                   (this.selectedSeats.vip.length || 
                    this.selectedSeats.upperGallery.length || 
                    this.selectedSeats.lowerHall.length)
        }
    },
    methods: {
        formatDate(datetime) {
            return new Date(datetime).toLocaleDateString()
        },
        formatTime(datetime) {
            return new Date(datetime).toLocaleTimeString('en-US', {
                hour: '2-digit',
                minute: '2-digit'
            })
        },
        updateSelectedSeats(seats) {
            this.selectedSeats = seats
        },
        async submitBooking() {
            try {
                const response = await fetch('/api/bookings', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        screeningId: this.screening._id,
                        customerName: this.customerName,
                        customerEmail: this.customerEmail,
                        seats: this.selectedSeats,
                        totalCost: this.totalPrice
                    })
                })

                if (!response.ok) throw new Error('Booking failed')

                const booking = await response.json()
                this.$emit('booking-completed', booking)
                
                // Show success message
                this.$toast.success('Booking confirmed!')
            } catch (error) {
                console.error('Booking error:', error)
                this.$toast.error('Failed to complete booking')
            }
        }
    }
}
</script> 