<template>
    <div class="reports-dashboard">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Reports Dashboard</h2>
            
            <div class="filters d-flex gap-3">
                <select class="form-select" v-model="selectedCinema">
                    <option value="">All Cinemas</option>
                    <option v-for="cinema in cinemas" 
                            :key="cinema._id" 
                            :value="cinema._id">
                        {{ cinema.name }}
                    </option>
                </select>

                <select class="form-select" v-model="timeRange">
                    <option value="week">Last Week</option>
                    <option value="month">Last Month</option>
                    <option value="quarter">Last Quarter</option>
                    <option value="year">Last Year</option>
                </select>
            </div>
        </div>

        <!-- Revenue Overview -->
        <div class="row mb-4">
            <div class="col-md-8">
                <div class="card h-100">
                    <div class="card-body">
                        <h5 class="card-title">Revenue Trend</h5>
                        <BaseChart
                            chartId="revenueChart"
                            type="line"
                            :data="revenueChartData"
                            :options="revenueChartOptions"
                        />
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card h-100">
                    <div class="card-body">
                        <h5 class="card-title">Revenue Summary</h5>
                        <div class="stats-list">
                            <div class="stat-item">
                                <span class="label">Total Revenue</span>
                                <span class="value">£{{ totalRevenue.toFixed(2) }}</span>
                            </div>
                            <div class="stat-item">
                                <span class="label">Average Daily</span>
                                <span class="value">£{{ avgDailyRevenue.toFixed(2) }}</span>
                            </div>
                            <div class="stat-item">
                                <span class="label">Growth</span>
                                <span class="value" :class="growthClass">
                                    {{ revenueGrowth }}%
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Performance Metrics -->
        <div class="row mb-4">
            <div class="col-md-6">
                <div class="card h-100">
                    <div class="card-body">
                        <h5 class="card-title">Top Performing Films</h5>
                        <BaseChart
                            chartId="filmsChart"
                            type="bar"
                            :data="filmsChartData"
                            :options="filmsChartOptions"
                        />
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card h-100">
                    <div class="card-body">
                        <h5 class="card-title">Occupancy Rates</h5>
                        <BaseChart
                            chartId="occupancyChart"
                            type="doughnut"
                            :data="occupancyChartData"
                            :options="occupancyChartOptions"
                        />
                    </div>
                </div>
            </div>
        </div>

        <!-- Detailed Stats Table -->
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Detailed Statistics</h5>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Metric</th>
                                <th>Current Period</th>
                                <th>Previous Period</th>
                                <th>Change</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="stat in detailedStats" 
                                :key="stat.metric">
                                <td>{{ stat.metric }}</td>
                                <td>{{ stat.current }}</td>
                                <td>{{ stat.previous }}</td>
                                <td :class="stat.changeClass">
                                    {{ stat.change }}
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import BaseChart from '../components/charts/BaseChart.vue';

export default {
    components: {
        BaseChart
    },
    data() {
        return {
            selectedCinema: '',
            timeRange: 'month',
            cinemas: [],
            revenueData: [],
            filmsData: [],
            occupancyData: [],
            detailedStats: []
        }
    },
    computed: {
        revenueChartData() {
            return {
                labels: this.revenueData.map(d => d.date),
                datasets: [{
                    label: 'Revenue',
                    data: this.revenueData.map(d => d.amount),
                    borderColor: '#2196f3',
                    tension: 0.4
                }]
            }
        },
        revenueChartOptions() {
            return {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        },
        filmsChartData() {
            return {
                labels: this.filmsData.map(d => d.title),
                datasets: [{
                    label: 'Tickets Sold',
                    data: this.filmsData.map(d => d.tickets),
                    backgroundColor: '#4caf50'
                }]
            }
        },
        filmsChartOptions() {
            return {
                responsive: true,
                maintainAspectRatio: false,
                indexAxis: 'y'
            }
        },
        occupancyChartData() {
            return {
                labels: ['Occupied', 'Available'],
                datasets: [{
                    data: [
                        this.occupancyData.occupied || 0,
                        this.occupancyData.available || 0
                    ],
                    backgroundColor: ['#2196f3', '#e9ecef']
                }]
            }
        },
        occupancyChartOptions() {
            return {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '70%'
            }
        },
        totalRevenue() {
            return this.revenueData.reduce((sum, d) => sum + d.amount, 0);
        },
        avgDailyRevenue() {
            return this.totalRevenue / this.revenueData.length || 0;
        },
        revenueGrowth() {
            if (this.revenueData.length < 2) return 0;
            const current = this.revenueData[this.revenueData.length - 1].amount;
            const previous = this.revenueData[0].amount;
            return (((current - previous) / previous) * 100).toFixed(1);
        },
        growthClass() {
            return {
                'text-success': this.revenueGrowth > 0,
                'text-danger': this.revenueGrowth < 0
            }
        }
    },
    methods: {
        async fetchData() {
            try {
                const [revenue, films, occupancy, stats] = await Promise.all([
                    this.fetchRevenueData(),
                    this.fetchFilmsData(),
                    this.fetchOccupancyData(),
                    this.fetchDetailedStats()
                ]);

                this.revenueData = revenue;
                this.filmsData = films;
                this.occupancyData = occupancy;
                this.detailedStats = stats;
            } catch (error) {
                console.error('Error fetching report data:', error);
                this.$toast.error('Failed to load reports');
            }
        },
        async fetchRevenueData() {
            const response = await fetch(
                `/api/reports/revenue?cinema=${this.selectedCinema}&range=${this.timeRange}`,
                {
                    headers: {
                        'Authorization': `Bearer ${localStorage.getItem('token')}`
                    }
                }
            );
            return response.json();
        },
        async fetchFilmsData() {
            const response = await fetch(
                `/api/reports/films?cinema=${this.selectedCinema}&range=${this.timeRange}`,
                {
                    headers: {
                        'Authorization': `Bearer ${localStorage.getItem('token')}`
                    }
                }
            );
            return response.json();
        },
        async fetchOccupancyData() {
            const response = await fetch(
                `/api/reports/occupancy?cinema=${this.selectedCinema}&range=${this.timeRange}`,
                {
                    headers: {
                        'Authorization': `Bearer ${localStorage.getItem('token')}`
                    }
                }
            );
            return response.json();
        },
        async fetchDetailedStats() {
            const response = await fetch(
                `/api/reports/stats?cinema=${this.selectedCinema}&range=${this.timeRange}`,
                {
                    headers: {
                        'Authorization': `Bearer ${localStorage.getItem('token')}`
                    }
                }
            );
            return response.json();
        }
    },
    watch: {
        selectedCinema() {
            this.fetchData();
        },
        timeRange() {
            this.fetchData();
        }
    },
    async mounted() {
        // Fetch cinemas first
        const response = await fetch('/api/cinemas', {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
        });
        this.cinemas = await response.json();
        
        // Then fetch report data
        this.fetchData();
    }
}
</script>

<style scoped>
.stats-list {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.stat-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0.5rem 0;
    border-bottom: 1px solid #eee;
}

.stat-item:last-child {
    border-bottom: none;
}

.label {
    color: #666;
}

.value {
    font-weight: bold;
}

.card {
    height: 100%;
}

.chart-container {
    min-height: 300px;
}
</style> 