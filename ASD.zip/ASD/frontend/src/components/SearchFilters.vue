<template>
    <div class="search-filters">
        <div class="card">
            <div class="card-body">
                <form @submit.prevent="handleSearch">
                    <div class="row g-3">
                        <!-- Film Search -->
                        <div class="col-md-4">
                            <label class="form-label">Film Title</label>
                            <input type="text" 
                                   class="form-control" 
                                   v-model="filters.title"
                                   placeholder="Search films...">
                        </div>

                        <!-- Genre Filter -->
                        <div class="col-md-3">
                            <label class="form-label">Genre</label>
                            <select class="form-select" v-model="filters.genre">
                                <option value="">All Genres</option>
                                <option v-for="genre in genres" 
                                        :key="genre" 
                                        :value="genre">
                                    {{ genre }}
                                </option>
                            </select>
                        </div>

                        <!-- Cinema Filter -->
                        <div class="col-md-3">
                            <label class="form-label">Cinema</label>
                            <select class="form-select" v-model="filters.cinemaId">
                                <option value="">All Cinemas</option>
                                <option v-for="cinema in cinemas" 
                                        :key="cinema._id" 
                                        :value="cinema._id">
                                    {{ cinema.name }}
                                </option>
                            </select>
                        </div>

                        <!-- Date Range -->
                        <div class="col-md-4">
                            <label class="form-label">From Date</label>
                            <input type="date" 
                                   class="form-control"
                                   v-model="filters.dateFrom">
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">To Date</label>
                            <input type="date" 
                                   class="form-control"
                                   v-model="filters.dateTo">
                        </div>

                        <!-- Time Range -->
                        <div class="col-md-2">
                            <label class="form-label">From Time</label>
                            <input type="time" 
                                   class="form-control"
                                   v-model="filters.timeFrom">
                        </div>

                        <div class="col-md-2">
                            <label class="form-label">To Time</label>
                            <input type="time" 
                                   class="form-control"
                                   v-model="filters.timeTo">
                        </div>

                        <!-- Sort Options -->
                        <div class="col-md-6">
                            <label class="form-label">Sort By</label>
                            <div class="input-group">
                                <select class="form-select" v-model="filters.sortBy">
                                    <option value="title">Title</option>
                                    <option value="rating">Rating</option>
                                    <option value="releaseDate">Release Date</option>
                                </select>
                                <select class="form-select" v-model="filters.order">
                                    <option value="asc">Ascending</option>
                                    <option value="desc">Descending</option>
                                </select>
                            </div>
                        </div>

                        <!-- Action Buttons -->
                        <div class="col-12">
                            <div class="d-flex gap-2">
                                <button type="submit" 
                                        class="btn btn-primary"
                                        :disabled="isLoading">
                                    {{ isLoading ? 'Searching...' : 'Search' }}
                                </button>
                                <button type="button" 
                                        class="btn btn-outline-secondary"
                                        @click="resetFilters">
                                    Reset
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            filters: {
                title: '',
                genre: '',
                cinemaId: '',
                dateFrom: '',
                dateTo: '',
                timeFrom: '',
                timeTo: '',
                sortBy: 'title',
                order: 'asc'
            },
            genres: [
                'Action',
                'Comedy',
                'Drama',
                'Horror',
                'Sci-Fi',
                'Thriller',
                'Romance',
                'Documentary'
            ],
            cinemas: [],
            isLoading: false
        }
    },
    methods: {
        async handleSearch() {
            this.isLoading = true;
            try {
                // Build query string from filters
                const query = new URLSearchParams();
                Object.entries(this.filters).forEach(([key, value]) => {
                    if (value) query.append(key, value);
                });

                // Emit search event with query string
                this.$emit('search', query.toString());
            } catch (error) {
                console.error('Search error:', error);
                this.$toast.error('Search failed');
            } finally {
                this.isLoading = false;
            }
        },
        resetFilters() {
            this.filters = {
                title: '',
                genre: '',
                cinemaId: '',
                dateFrom: '',
                dateTo: '',
                timeFrom: '',
                timeTo: '',
                sortBy: 'title',
                order: 'asc'
            };
            this.handleSearch();
        },
        async fetchCinemas() {
            try {
                const response = await fetch('/api/cinemas');
                this.cinemas = await response.json();
            } catch (error) {
                console.error('Error fetching cinemas:', error);
                this.$toast.error('Failed to load cinemas');
            }
        }
    },
    mounted() {
        this.fetchCinemas();
    }
}
</script>

<style scoped>
.search-filters {
    margin-bottom: 2rem;
}

.card {
    box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
}
</style> 