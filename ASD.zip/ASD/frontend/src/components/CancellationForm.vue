<template>
    <div class="cancellation-form">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title mb-4">Cancel Booking</h4>
                
                <form @submit.prevent="handleSubmit">
                    <div class="mb-3">
                        <label class="form-label">Booking Reference</label>
                        <input type="text" 
                               class="form-control" 
                               v-model="bookingReference"
                               placeholder="Enter booking reference"
                               required>
                    </div>

                    <div v-if="booking" class="booking-details mb-4">
                        <h5>Booking Details</h5>
                        <div class="card bg-light">
                            <div class="card-body">
                                <p class="mb-2">
                                    <strong>Film:</strong> 
                                    {{ booking.screening.film.title }}
                                </p>
                                <p class="mb-2">
                                    <strong>Show Time:</strong> 
                                    {{ formatDateTime(booking.screening.showtime) }}
                                </p>
                                <p class="mb-2">
                                    <strong>Seats:</strong> 
                                    {{ formatSeats(booking.seats) }}
                                </p>
                                <p class="mb-2">
                                    <strong>Total Cost:</strong> 
                                    £{{ booking.totalCost.toFixed(2) }}
                                </p>
                                <p class="mb-0">
                                    <strong>Refund Amount:</strong> 
                                    £{{ (booking.totalCost * 0.5).toFixed(2) }}
                                </p>
                            </div>
                        </div>
                    </div>

                    <div v-if="error" class="alert alert-danger mb-3">
                        {{ error }}
                    </div>

                    <div v-if="success" class="alert alert-success mb-3">
                        {{ success }}
                    </div>

                    <div class="d-flex gap-2">
                        <button type="button" 
                                class="btn btn-secondary"
                                @click="resetForm">
                            Clear
                        </button>
                        <button type="submit" 
                                class="btn btn-danger"
                                :disabled="!booking || isLoading">
                            {{ isLoading ? 'Processing...' : 'Cancel Booking' }}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            bookingReference: '',
            booking: null,
            error: null,
            success: null,
            isLoading: false
        }
    },
    methods: {
        async fetchBooking() {
            try {
                const response = await fetch(`/api/bookings/${this.bookingReference}`);
                const data = await response.json();

                if (!response.ok) {
                    throw new Error(data.error);
                }

                this.booking = data;
                this.error = null;
            } catch (error) {
                this.error = error.message;
                this.booking = null;
            }
        },
        async handleSubmit() {
            if (!this.booking) return;

            this.isLoading = true;
            this.error = null;
            this.success = null;

            try {
                const response = await fetch(
                    `/api/bookings/${this.bookingReference}/cancel`,
                    {
                        method: 'POST',
                        headers: {
                            'Authorization': `Bearer ${localStorage.getItem('token')}`
                        }
                    }
                );

                const data = await response.json();

                if (!response.ok) {
                    throw new Error(data.error);
                }

                this.success = `Booking cancelled successfully. 
                               Refund amount: £${data.refundAmount.toFixed(2)}`;
                this.booking = null;
                this.bookingReference = '';
                
                this.$emit('booking-cancelled');
            } catch (error) {
                this.error = error.message;
            } finally {
                this.isLoading = false;
            }
        },
        resetForm() {
            this.bookingReference = '';
            this.booking = null;
            this.error = null;
            this.success = null;
        },
        formatDateTime(datetime) {
            return new Date(datetime).toLocaleString();
        },
        formatSeats(seats) {
            return seats.map(seat => 
                `${seat.type}: ${seat.seatNumber}`
            ).join(', ');
        }
    },
    watch: {
        bookingReference(newVal) {
            if (newVal.length >= 8) {
                this.fetchBooking();
            } else {
                this.booking = null;
            }
        }
    }
}
</script>

<style scoped>
.cancellation-form {
    max-width: 600px;
    margin: 0 auto;
}

.booking-details {
    border-left: 4px solid #dc3545;
    padding-left: 1rem;
}
</style> 