<template>
    <div class="login-form">
        <div class="card">
            <div class="card-body">
                <h3 class="card-title text-center mb-4">Login</h3>
                <form @submit.prevent="handleSubmit">
                    <div class="mb-3">
                        <label class="form-label">Username</label>
                        <input type="text" 
                               class="form-control" 
                               v-model="username"
                               required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Password</label>
                        <input type="password" 
                               class="form-control" 
                               v-model="password"
                               required>
                    </div>

                    <div v-if="error" class="alert alert-danger">
                        {{ error }}
                    </div>

                    <button type="submit" 
                            class="btn btn-primary w-100"
                            :disabled="isLoading">
                        {{ isLoading ? 'Logging in...' : 'Login' }}
                    </button>
                </form>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            username: '',
            password: '',
            error: null,
            isLoading: false
        }
    },
    methods: {
        async handleSubmit() {
            this.error = null;
            this.isLoading = true;

            try {
                const response = await fetch('/api/auth/login', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        username: this.username,
                        password: this.password
                    })
                });

                const data = await response.json();

                if (!response.ok) {
                    throw new Error(data.error || 'Login failed');
                }

                // Store token and user data
                localStorage.setItem('token', data.token);
                localStorage.setItem('user', JSON.stringify(data.user));

                // Emit login event
                this.$emit('login-success', data.user);

                // Redirect based on role
                switch (data.user.role) {
                    case 'manager':
                        this.$router.push('/manager');
                        break;
                    case 'admin':
                        this.$router.push('/admin');
                        break;
                    case 'staff':
                        this.$router.push('/booking');
                        break;
                }
            } catch (error) {
                this.error = error.message;
            } finally {
                this.isLoading = false;
            }
        }
    }
}
</script>

<style scoped>
.login-form {
    max-width: 400px;
    margin: 40px auto;
}

.card {
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}
</style> 