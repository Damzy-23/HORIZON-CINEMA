<template>
    <div class="modal fade" ref="modal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        {{ cinema ? 'Edit Cinema' : 'Add New Cinema' }}
                    </h5>
                    <button type="button" 
                            class="btn-close" 
                            data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form @submit.prevent="handleSubmit">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Cinema Name</label>
                                <input type="text" 
                                       class="form-control"
                                       v-model="formData.name"
                                       required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">City</label>
                                <select class="form-select"
                                        v-model="formData.city"
                                        required>
                                    <option value="">Select City</option>
                                    <option v-for="city in cities" 
                                            :key="city" 
                                            :value="city">
                                        {{ city }}
                                    </option>
                                </select>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Location</label>
                            <input type="text" 
                                   class="form-control"
                                   v-model="formData.location"
                                   required>
                        </div>

                        <!-- Screens Configuration -->
                        <div class="mb-3">
                            <label class="form-label">Screens</label>
                            <div v-for="(screen, index) in formData.screens" 
                                 :key="index"
                                 class="card mb-2">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <label class="form-label">Screen {{ index + 1 }}</label>
                                        </div>
                                        <div class="col-md-8">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label class="form-label">Lower Hall</label>
                                                    <input type="number" 
                                                           class="form-control"
                                                           v-model="screen.capacity.lowerHall"
                                                           min="1"
                                                           required>
                                                </div>
                                                <div class="col-md-4">
                                                    <label class="form-label">Upper Gallery</label>
                                                    <input type="number" 
                                                           class="form-control"
                                                           v-model="screen.capacity.upperGallery"
                                                           min="1"
                                                           required>
                                                </div>
                                                <div class="col-md-4">
                                                    <label class="form-label">VIP Seats</label>
                                                    <input type="number" 
                                                           class="form-control"
                                                           v-model="screen.capacity.vipSeats"
                                                           min="0"
                                                           required>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <button type="button" 
                                    class="btn btn-secondary"
                                    @click="addScreen"
                                    :disabled="formData.screens.length >= 6">
                                Add Screen
                            </button>
                        </div>

                        <!-- Price Ranges -->
                        <div class="mb-3">
                            <label class="form-label">Price Ranges</label>
                            <div class="row">
                                <div class="col-md-4">
                                    <label class="form-label">Morning Show</label>
                                    <input type="number" 
                                           class="form-control"
                                           v-model="formData.priceRanges.morningShow"
                                           min="0"
                                           step="0.01"
                                           required>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Afternoon Show</label>
                                    <input type="number" 
                                           class="form-control"
                                           v-model="formData.priceRanges.afternoonShow"
                                           min="0"
                                           step="0.01"
                                           required>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Evening Show</label>
                                    <input type="number" 
                                           class="form-control"
                                           v-model="formData.priceRanges.eveningShow"
                                           min="0"
                                           step="0.01"
                                           required>
                                </div>
                            </div>
                        </div>

                        <div class="modal-footer">
                            <button type="button" 
                                    class="btn btn-secondary"
                                    data-bs-dismiss="modal">
                                Cancel
                            </button>
                            <button type="submit" 
                                    class="btn btn-primary">
                                Save Cinema
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import { Modal } from 'bootstrap'

export default {
    props: {
        cinema: {
            type: Object,
            default: null
        }
    },
    data() {
        return {
            modal: null,
            cities: ['Birmingham', 'Bristol', 'Cardiff', 'London'],
            formData: {
                name: '',
                city: '',
                location: '',
                screens: [],
                priceRanges: {
                    morningShow: '',
                    afternoonShow: '',
                    eveningShow: ''
                }
            }
        }
    },
    methods: {
        show() {
            this.resetForm()
            this.modal.show()
        },
        hide() {
            this.modal.hide()
        },
        resetForm() {
            if (this.cinema) {
                this.formData = JSON.parse(JSON.stringify(this.cinema))
            } else {
                this.formData = {
                    name: '',
                    city: '',
                    location: '',
                    screens: [{
                        screenNumber: 1,
                        capacity: {
                            lowerHall: 35,
                            upperGallery: 35,
                            vipSeats: 10
                        }
                    }],
                    priceRanges: {
                        morningShow: '',
                        afternoonShow: '',
                        eveningShow: ''
                    }
                }
            }
        },
        addScreen() {
            if (this.formData.screens.length < 6) {
                this.formData.screens.push({
                    screenNumber: this.formData.screens.length + 1,
                    capacity: {
                        lowerHall: 35,
                        upperGallery: 35,
                        vipSeats: 10
                    }
                })
            }
        },
        handleSubmit() {
            this.$emit('save', { ...this.formData })
            this.hide()
        }
    },
    mounted() {
        this.modal = new Modal(this.$refs.modal)
    }
}
</script> 