<template>
    <div class="payment-form">
        <div class="card">
            <div class="card-body">
                <h3 class="card-title mb-4">Payment Details</h3>

                <div v-if="error" class="alert alert-danger">
                    {{ error }}
                </div>

                <div class="booking-summary mb-4">
                    <h4>Booking Summary</h4>
                    <div class="card bg-light">
                        <div class="card-body">
                            <p class="mb-2">
                                <strong>Film:</strong> 
                                {{ booking.film.title }}
                            </p>
                            <p class="mb-2">
                                <strong>Date:</strong>
                                {{ formatDate(booking.screening.showtime) }}
                            </p>
                            <p class="mb-2">
                                <strong>Seats:</strong>
                                {{ formatSeats(booking.seats) }}
                            </p>
                            <p class="mb-0">
                                <strong>Total:</strong>
                                £{{ booking.totalCost.toFixed(2) }}
                            </p>
                        </div>
                    </div>
                </div>

                <form @submit.prevent="handleSubmit">
                    <div class="mb-4">
                        <div id="card-element"></div>
                        <div id="card-errors" class="text-danger mt-2"></div>
                    </div>

                    <button type="submit" 
                            class="btn btn-primary w-100"
                            :disabled="isProcessing">
                        {{ isProcessing ? 'Processing...' : 
                           `Pay £${booking.totalCost.toFixed(2)}` }}
                    </button>
                </form>
            </div>
        </div>
    </div>
</template>

<script>
import { loadStripe } from '@stripe/stripe-js';

export default {
    props: {
        booking: {
            type: Object,
            required: true
        }
    },
    data() {
        return {
            stripe: null,
            card: null,
            error: null,
            isProcessing: false
        }
    },
    async mounted() {
        this.stripe = await loadStripe(process.env.VUE_APP_STRIPE_PUBLIC_KEY);
        const elements = this.stripe.elements();
        
        this.card = elements.create('card', {
            style: {
                base: {
                    fontSize: '16px',
                    color: '#32325d',
                    fontFamily: '"Helvetica Neue", Helvetica, sans-serif',
                    '::placeholder': {
                        color: '#aab7c4'
                    }
                },
                invalid: {
                    color: '#fa755a',
                    iconColor: '#fa755a'
                }
            }
        });

        this.card.mount('#card-element');

        this.card.on('change', (event) => {
            const displayError = document.getElementById('card-errors');
            if (event.error) {
                displayError.textContent = event.error.message;
            } else {
                displayError.textContent = '';
            }
        });
    },
    methods: {
        async handleSubmit() {
            this.isProcessing = true;
            this.error = null;

            try {
                // Create payment intent
                const { data: { clientSecret } } = await this.$axios.post(
                    '/api/payment-intent',
                    { bookingId: this.booking._id }
                );

                // Confirm payment
                const result = await this.stripe.confirmCardPayment(clientSecret, {
                    payment_method: {
                        card: this.card
                    }
                });

                if (result.error) {
                    this.error = result.error.message;
                } else {
                    // Payment successful
                    await this.$axios.post(
                        `/api/confirm/${this.booking._id}`
                    );
                    this.$emit('payment-success');
                }
            } catch (error) {
                this.error = error.response?.data?.error || 
                            'Payment processing failed';
            } finally {
                this.isProcessing = false;
            }
        },
        formatDate(date) {
            return new Date(date).toLocaleString();
        },
        formatSeats(seats) {
            return seats.map(seat => 
                `${seat.type}: ${seat.seatNumber}`
            ).join(', ');
        }
    },
    beforeDestroy() {
        if (this.card) {
            this.card.destroy();
        }
    }
}
</script>

<style scoped>
.payment-form {
    max-width: 600px;
    margin: 0 auto;
}

#card-element {
    padding: 12px;
    border: 1px solid #ced4da;
    border-radius: 4px;
    background-color: white;
}
</style> 