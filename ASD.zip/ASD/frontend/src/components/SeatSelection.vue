<template>
    <div class="seat-selection">
        <div class="screen mb-4">
            <div class="screen-label">SCREEN</div>
        </div>
        
        <div class="seating-area">
            <!-- VIP Section -->
            <div class="section vip-section mb-4">
                <h6>VIP Seats</h6>
                <div class="seat-grid">
                    <button v-for="seat in vipSeats" 
                            :key="`vip-${seat}`"
                            :class="['seat', getSeatClass('vip', seat)]"
                            @click="toggleSeat('vip', seat)"
                            :disabled="isSeatTaken('vip', seat)">
                        {{ seat }}
                    </button>
                </div>
            </div>

            <!-- Upper Gallery -->
            <div class="section upper-gallery mb-4">
                <h6>Upper Gallery</h6>
                <div class="seat-grid">
                    <button v-for="seat in upperGallerySeats" 
                            :key="`upper-${seat}`"
                            :class="['seat', getSeatClass('upperGallery', seat)]"
                            @click="toggleSeat('upperGallery', seat)"
                            :disabled="isSeatTaken('upperGallery', seat)">
                        {{ seat }}
                    </button>
                </div>
            </div>

            <!-- Lower Hall -->
            <div class="section lower-hall">
                <h6>Lower Hall</h6>
                <div class="seat-grid">
                    <button v-for="seat in lowerHallSeats" 
                            :key="`lower-${seat}`"
                            :class="['seat', getSeatClass('lowerHall', seat)]"
                            @click="toggleSeat('lowerHall', seat)"
                            :disabled="isSeatTaken('lowerHall', seat)">
                        {{ seat }}
                    </button>
                </div>
            </div>
        </div>

        <div class="seat-legend mt-4">
            <div class="legend-item">
                <div class="seat-sample available"></div>
                <span>Available</span>
            </div>
            <div class="legend-item">
                <div class="seat-sample selected"></div>
                <span>Selected</span>
            </div>
            <div class="legend-item">
                <div class="seat-sample taken"></div>
                <span>Taken</span>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    props: {
        screening: {
            type: Object,
            required: true
        }
    },
    data() {
        return {
            selectedSeats: {
                vip: [],
                upperGallery: [],
                lowerHall: []
            }
        }
    },
    computed: {
        vipSeats() {
            return Array.from({ length: this.screening.availableSeats.vipSeats.length }, (_, i) => i + 1)
        },
        upperGallerySeats() {
            return Array.from({ length: this.screening.availableSeats.upperGallery.length }, (_, i) => i + 1)
        },
        lowerHallSeats() {
            return Array.from({ length: this.screening.availableSeats.lowerHall.length }, (_, i) => i + 1)
        }
    },
    methods: {
        toggleSeat(section, seatNumber) {
            const index = this.selectedSeats[section].indexOf(seatNumber)
            if (index === -1) {
                this.selectedSeats[section].push(seatNumber)
            } else {
                this.selectedSeats[section].splice(index, 1)
            }
            this.$emit('seats-changed', this.selectedSeats)
        },
        isSeatTaken(section, seatNumber) {
            return !this.screening.availableSeats[section].includes(seatNumber)
        },
        getSeatClass(section, seatNumber) {
            if (this.isSeatTaken(section, seatNumber)) return 'taken'
            if (this.selectedSeats[section].includes(seatNumber)) return 'selected'
            return 'available'
        }
    }
}
</script>

<style scoped>
.seat-selection {
    padding: 20px;
}

.screen {
    background: #ccc;
    height: 10px;
    position: relative;
    margin: 0 auto;
    width: 80%;
}

.screen-label {
    text-align: center;
    margin-bottom: 5px;
    color: #666;
}

.seat-grid {
    display: grid;
    grid-template-columns: repeat(10, 1fr);
    gap: 5px;
    margin: 10px 0;
}

.seat {
    width: 30px;
    height: 30px;
    border: 1px solid #ccc;
    border-radius: 5px;
    background: #fff;
    cursor: pointer;
}

.seat.available:hover {
    background: #e3f2fd;
}

.seat.selected {
    background: #2196f3;
    color: white;
}

.seat.taken {
    background: #f5f5f5;
    cursor: not-allowed;
}

.seat-legend {
    display: flex;
    justify-content: center;
    gap: 20px;
}

.legend-item {
    display: flex;
    align-items: center;
    gap: 5px;
}

.seat-sample {
    width: 20px;
    height: 20px;
    border: 1px solid #ccc;
    border-radius: 3px;
}

.seat-sample.available {
    background: #fff;
}

.seat-sample.selected {
    background: #2196f3;
}

.seat-sample.taken {
    background: #f5f5f5;
}
</style> 