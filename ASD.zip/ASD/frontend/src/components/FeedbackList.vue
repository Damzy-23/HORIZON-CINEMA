<template>
    <div class="feedback-list">
        <h4>User Feedback</h4>
        <ul class="list-group">
            <li v-for="feedback in feedbacks" :key="feedback._id" class="list-group-item">
                <strong>{{ feedback.userId.username }}:</strong> {{ feedback.comment }} (Rating: {{ feedback.rating }})
            </li>
        </ul>
    </div>
</template>

<script>
export default {
    props: {
        filmId: {
            type: String,
            required: true
        }
    },
    data() {
        return {
            feedbacks: []
        }
    },
    async mounted() {
        await this.fetchFeedback();
    },
    methods: {
        async fetchFeedback() {
            try {
                const response = await this.$axios.get(`/api/feedback/${this.filmId}`);
                this.feedbacks = response.data;
            } catch (error) {
                console.error('Error fetching feedback:', error);
            }
        }
    }
}
</script>

<style scoped>
.feedback-list {
    margin-top: 20px;
}
</style> 