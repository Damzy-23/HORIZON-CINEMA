<template>
    <div class="seat-availability">
        <h4>Available Seats</h4>
        <div v-if="loading">Loading...</div>
        <div v-else>
            <h5>Lower Hall</h5>
            <p v-if="availableSeats.lowerHall.length === 0">No available seats</p>
            <ul v-else>
                <li v-for="seat in availableSeats.lowerHall" :key="seat">
                    Seat {{ seat }}
                </li>
            </ul>

            <h5>Upper Gallery</h5>
            <p v-if="availableSeats.upperGallery.length === 0">No available seats</p>
            <ul v-else>
                <li v-for="seat in availableSeats.upperGallery" :key="seat">
                    Seat {{ seat }}
                </li>
            </ul>

            <h5>VIP Seats</h5>
            <p v-if="availableSeats.vipSeats.length === 0">No available seats</p>
            <ul v-else>
                <li v-for="seat in availableSeats.vipSeats" :key="seat">
                    Seat {{ seat }}
                </li>
            </ul>
        </div>
    </div>
</template>

<script>
import { io } from 'socket.io-client';

export default {
    props: {
        screeningId: {
            type: String,
            required: true
        }
    },
    data() {
        return {
            availableSeats: {
                lowerHall: [],
                upperGallery: [],
                vipSeats: []
            },
            loading: true
        }
    },
    mounted() {
        this.fetchAvailableSeats();
        this.setupSocket();
    },
    methods: {
        async fetchAvailableSeats() {
            try {
                const response = await fetch(`/api/screenings/${this.screeningId}/available-seats`);
                this.availableSeats = await response.json();
            } catch (error) {
                console.error('Error fetching available seats:', error);
            } finally {
                this.loading = false;
            }
        },
        setupSocket() {
            const socket = io();

            socket.on(`seat-update:${this.screeningId}`, (availableSeats) => {
                this.availableSeats = availableSeats;
            });
        }
    }
}
</script>

<style scoped>
.seat-availability {
    margin-top: 20px;
}

h4 {
    margin-bottom: 10px;
}
</style> 