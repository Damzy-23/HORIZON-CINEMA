import { config } from '@vue/test-utils'
import { createToast } from 'vue-toastification'

// Global mocks
config.global.mocks = {
    $toast: createToast({
        timeout: 2000,
        position: 'top-right'
    })
}

// Mock localStorage
const localStorageMock = {
    getItem: jest.fn(),
    setItem: jest.fn(),
    removeItem: jest.fn(),
    clear: jest.fn()
};
global.localStorage = localStorageMock;

// Mock fetch
global.fetch = jest.fn(() =>
    Promise.resolve({
        ok: true,
        json: () => Promise.resolve({}),
    })
); 