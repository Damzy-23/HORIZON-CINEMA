import json
from User import User
from Film import Film
from Screen import Screen
from Cinema import Cinema
from Booking import Booking

class CinemaManager:
    def __init__(self, filename='cinema_data.json'):
        self.filename = filename
        self.cinemas = []
        self.users = []
        self.bookings = []
        self.load_data()
        self.load_default_users()
        self.preload_movies_and_showings()

    def preload_movies_and_showings(self):
        import datetime
        import random
        from Film import Film
        from Screen import Screen

        # Create 7 films
        films = [
            Film("The Great Adventure", "An epic journey.", "Adventure", "PG-13", ["Actor A", "Actor B"]),
            Film("Romantic Escape", "A love story.", "Romance", "PG", ["Actor C", "Actor D"]),
            Film("Mystery Manor", "A thrilling mystery.", "Mystery", "PG-13", ["Actor E", "Actor F"]),
            Film("Sci-Fi Saga", "A space odyssey.", "Sci-Fi", "PG-13", ["Actor G", "Actor H"]),
            Film("Comedy Nights", "Laugh out loud.", "Comedy", "PG", ["Actor I", "Actor J"]),
            Film("Horror House", "Spooky tales.", "Horror", "R", ["Actor K", "Actor L"]),
            Film("Animated Fun", "Family animation.", "Animation", "G", ["Actor M", "Actor N"]),
        ]

        # Add multiple cinemas with UK cities if none exist
        if not self.cinemas:
            uk_cities = [
                "London", "Manchester", "Birmingham", "Leeds", "Glasgow", "Sheffield",
                "Bradford", "Liverpool", "Edinburgh", "Bristol", "Cardiff", "Coventry"
            ]
            for i, city in enumerate(uk_cities[:12], start=1):
                cinema = Cinema(f"Horizon Cinema {i}", city)
                screen1 = Screen(1, 100)
                cinema.add_screen(screen1)
                self.cinemas.append(cinema)
        else:
            cinema = self.cinemas[0]
            if not cinema.screens:
                screen1 = Screen(1, 100)
                cinema.add_screen(screen1)
            else:
                screen1 = cinema.screens[0]

        # Define show times for morning, afternoon, and night
        show_times = ["10:00", "15:00", "19:00"]

        # Add films with show times from today to end of May for each cinema and screen
        today = datetime.date.today()
        end_date = datetime.date(today.year, 5, 31)
        delta = datetime.timedelta(days=1)

        current_date = today
        while current_date <= end_date:
            for show_time in show_times:
                film = random.choice(films)
                full_show_time = current_date.strftime("%Y-%m-%d") + " " + show_time
                for cinema in self.cinemas:
                    for screen in cinema.screens:
                        screen.add_showing(film, full_show_time)
            current_date += delta
        self.save_data()

    def load_data(self):
        try:
            with open(self.filename, 'r') as file:
                data = json.load(file)
                for cinema_data in data.get('cinemas', []):
                    cinema = Cinema(cinema_data['name'], cinema_data['city'])
                    for screen_data in cinema_data.get('screens', []):
                        screen = Screen(screen_data['screen_number'], screen_data['seating_capacity'])
                        cinema.add_screen(screen)
                    self.cinemas.append(cinema)

                # Load users from data
                self.users = []
                for user_data in data.get('users', []):
                    user = User.from_dict(user_data)
                    self.users.append(user)
        except FileNotFoundError:
            self.cinemas = []
            self.users = []

    def save_data(self):
        data = {'cinemas': [], 'users': []}
        for cinema in self.cinemas:
            cinema_data = {
                'name': cinema.name,
                'city': cinema.city,
                'screens': [{'screen_number': screen.screen_number, 'seating_capacity': screen.seating_capacity} for screen in cinema.screens]
            }
            data['cinemas'].append(cinema_data)

        # Save users to data
        for user in self.users:
            data['users'].append(user.to_dict())

        with open(self.filename, 'w') as file:
            json.dump(data, file, indent=4)

    def load_default_users(self):
        self.users.append(User("admin", "adminpass", "Admin"))
        self.users.append(User("manager", "managerpass", "Manager"))
        self.users.append(User("staff", "staffpass", "Booking Staff"))

    def authenticate_user(self, username, password):
        for user in self.users:
            if user.username == username and user.check_password(password):
                return user
        return None

    def add_user(self, username, password, role="User"):
        # Check if username already exists
        if any(user.username == username for user in self.users):
            return False
        new_user = User(username, password, role)
        self.users.append(new_user)
        self.save_data()
        return True

    def remove_user(self, username):
        for i, user in enumerate(self.users):
            if user.username == username:
                del self.users[i]
                self.save_data()
                return True
        return False

    def update_user_role(self, username, new_role):
        for user in self.users:
            if user.username == username:
                user.role = new_role
                self.save_data()
                return True
        return False

    def add_cinema(self, cinema_name, city):
        new_cinema = Cinema(cinema_name, city)
        self.cinemas.append(new_cinema)
        self.save_data()

    def remove_cinema(self, cinema_name):
        self.cinemas = [cinema for cinema in self.cinemas if cinema.name != cinema_name]
        self.save_data()

    def update_cinema(self, old_name, new_name, new_city):
        for cinema in self.cinemas:
            if cinema.name == old_name:
                cinema.name = new_name
                cinema.city = new_city
                self.save_data()
                return True
        return False

    def add_film(self, cinema_name, film):
        for cinema in self.cinemas:
            if cinema.name == cinema_name:
                for screen in cinema.screens:
                    screen.add_showing(film, None)
                self.save_data()
                return True
        return False

    def remove_film(self, cinema_name, film_title):
        for cinema in self.cinemas:
            if cinema.name == cinema_name:
                for screen in cinema.screens:
                    screen.remove_showing(film_title, None)
                self.save_data()
                return True
        return False

    def update_film(self, cinema_name, old_title, new_title, new_description, new_genre, new_rating, new_cast):
        for cinema in self.cinemas:
            if cinema.name == cinema_name:
                for screen in cinema.screens:
                    for i, (film, show_time) in enumerate(screen.showings):
                        if film.title == old_title:
                            screen.showings[i] = (Film(new_title, new_description, new_genre, new_rating, new_cast), show_time)
                self.save_data()
                return True
        return False

    def add_showing_to_screen(self, cinema_name, screen_number, film_title, show_time):
        for cinema in self.cinemas:
            if cinema.name == cinema_name:
                for screen in cinema.screens:
                    if screen.screen_number == int(screen_number):
                        film_to_show = None
                        for showing_film, _ in screen.showings:
                            if showing_film.title == film_title:
                                film_to_show = showing_film
                                break
                        if not film_to_show:
                            film_to_show = Film(film_title, "Description needed", "Genre needed", "Rating needed", [])
                        screen.add_showing(film_to_show, show_time)
                        self.save_data()
                        return True
                return False
        return False

    def remove_showing_from_screen(self, cinema_name, screen_number, film_title, show_time):
        for cinema in self.cinemas:
            if cinema.name == cinema_name:
                for screen in cinema.screens:
                    if screen.screen_number == int(screen_number):
                        screen.remove_showing(film_title, show_time)
                        self.save_data()
                        return True
                return False
        return False

    def add_booking(self, booking):
        self.bookings.append(booking)

    def process_payment(self, film_title, card_number, expiry_date, cvv):
        """
        Simulate payment processing.
        For simplicity, accept any card details and return True.
        """
        # In real scenario, integrate with payment gateway here
        print(f"Processing payment for film {film_title} with card {card_number}")
        return True

    def refund_booking(self, booking_reference):
        """
        Refund a booking by booking_reference.
        Remove the booking from bookings list if found.
        """
        for i, booking in enumerate(self.bookings):
            if booking.booking_reference == booking_reference:
                del self.bookings[i]
                print(f"Booking {booking_reference} refunded and removed.")
                return True
        print(f"Booking {booking_reference} not found for refund.")
        return False

    def generate_film_booking_report(self):
        film_booking_counts = {}
        for booking in self.bookings:
            film_title = booking.film.title
            film_booking_counts[film_title] = film_booking_counts.get(film_title, 0) + 1
        return film_booking_counts

    def generate_revenue_report(self, booking_reference):
        """
        Generate a revenue report (receipt) for a given booking reference.
        Returns a formatted string receipt or None if booking not found.
        """
        booking = next((b for b in self.bookings if b.booking_reference == booking_reference), None)
        if not booking:
            return None

        receipt = f"--- Horizon Cinema Receipt ---\n"
        receipt += f"Booking Reference: {booking.booking_reference}\n"
        receipt += f"Film: {booking.film.title}\n"
        receipt += f"Screen: {booking.screen.screen_number}\n"
        receipt += f"Show Time: {booking.show_time}\n"
        receipt += f"Number of Tickets: {booking.num_tickets}\n"
        receipt += f"Seat Numbers: {', '.join(booking.seat_numbers)}\n"
        receipt += f"Price per Ticket: ${booking.price_per_ticket:.2f}\n"
        receipt += f"Total Price: ${booking.total_price:.2f}\n"
        receipt += f"Purchase Time: {booking.timestamp.strftime('%Y-%m-%d %H:%M:%S')}\n"
        receipt += f"------------------------------\n"
        receipt += f"Thank you for your purchase!\n"
        return receipt
