import http from 'k6/http';
import { check, sleep } from 'k6';

export const options = {
    stages: [
        { duration: '30s', target: 50 }, // Ramp up to 50 users over 30 seconds
        { duration: '1m', target: 50 },   // Stay at 50 users for 1 minute
        { duration: '30s', target: 0 },    // Ramp down to 0 users
    ],
};

export default function () {
    const res = http.get('http://localhost:3000/api/films'); // Replace with your API endpoint
    check(res, {
        'is status 200': (r) => r.status === 200,
    });
    sleep(1); // Wait for 1 second between requests
} 