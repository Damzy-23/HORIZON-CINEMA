import sys
import os
import tkinter as tk
from tkinter import messagebox, simpledialog, font
# Fix import path for backend classes
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../../backend/classes')))

from CinemaManager import CinemaManager
from Film import Film
from Screen import Screen
from Cinema import Cinema
from Booking import Booking

class HorizonCinemaApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Horizon Cinema Booking System")
        self.root.geometry("700x600")
        self.root.configure(bg="#121212")
        self.manager = CinemaManager()
        self.current_user = None

        self.custom_font = font.Font(family="Segoe UI", size=12, weight="bold")
        self.button_style = {"bg": "#ff4500", "fg": "white", "font": self.custom_font, "activebackground": "#ff6347", "activeforeground": "white", "bd": 0, "relief": "flat", "padx": 15, "pady": 8}

        self.login_screen()

    def add_hover_effect(self, button, normal_bg, hover_bg):
        def on_enter(e):
            button['background'] = hover_bg
        def on_leave(e):
            button['background'] = normal_bg
        button.bind("<Enter>", on_enter)
        button.bind("<Leave>", on_leave)
    
    def create_button(self, parent, text, command):
        btn = tk.Button(parent, text=text, command=command, **self.button_style)
        self.add_hover_effect(btn, self.button_style['bg'], self.button_style['activebackground'])
        return btn

    def login_screen(self):
        self.clear_window()

        title = tk.Label(self.root, text="Horizon Cinema Login", bg="#121212", fg="white", font=("Segoe UI", 24, "bold"))
        title.pack(pady=30)

        frame = tk.Frame(self.root, bg="#121212")
        frame.pack(pady=15)

        tk.Label(frame, text="Username:", bg="#121212", fg="white", font=self.custom_font).grid(row=0, column=0, sticky="e", pady=8)
        self.username_entry = tk.Entry(frame, font=self.custom_font, bg="#1e1e2f", fg="white", insertbackground="white", relief="flat")
        self.username_entry.grid(row=0, column=1, pady=8, padx=15)

        tk.Label(frame, text="Password:", bg="#121212", fg="white", font=self.custom_font).grid(row=1, column=0, sticky="e", pady=8)
        self.password_entry = tk.Entry(frame, show="*", font=self.custom_font, bg="#1e1e2f", fg="white", insertbackground="white", relief="flat")
        self.password_entry.grid(row=1, column=1, pady=8, padx=15)

        btn_frame = tk.Frame(self.root, bg="#121212")
        btn_frame.pack(pady=25)

        login_btn = self.create_button(btn_frame, "Login", self.login)
        login_btn.grid(row=0, column=0, padx=15)

        signup_btn = self.create_button(btn_frame, "Sign Up", self.signup_screen)
        signup_btn.grid(row=0, column=1, padx=15)

    def signup_screen(self):
        self.clear_window()

        title = tk.Label(self.root, text="Create New Account", bg="#121212", fg="white", font=("Segoe UI", 24, "bold"))
        title.pack(pady=30)

        frame = tk.Frame(self.root, bg="#121212")
        frame.pack(pady=15)

        tk.Label(frame, text="Username:", bg="#121212", fg="white", font=self.custom_font).grid(row=0, column=0, sticky="e", pady=8)
        self.new_username_entry = tk.Entry(frame, font=self.custom_font, bg="#1e1e2f", fg="white", insertbackground="white", relief="flat")
        self.new_username_entry.grid(row=0, column=1, pady=8, padx=15)

        tk.Label(frame, text="Password:", bg="#121212", fg="white", font=self.custom_font).grid(row=1, column=0, sticky="e", pady=8)
        self.new_password_entry = tk.Entry(frame, show="*", font=self.custom_font, bg="#1e1e2f", fg="white", insertbackground="white", relief="flat")
        self.new_password_entry.grid(row=1, column=1, pady=8, padx=15)

        btn_frame = tk.Frame(self.root, bg="#121212")
        btn_frame.pack(pady=25)

        register_btn = self.create_button(btn_frame, "Register", self.register_user)
        register_btn.grid(row=0, column=0, padx=15)

        back_btn = self.create_button(btn_frame, "Back to Login", self.login_screen)
        back_btn.grid(row=0, column=1, padx=15)

    def login_screen(self):
        self.clear_window()

        title = tk.Label(self.root, text="Horizon Cinema Login", bg="#1e1e2f", fg="white", font=("Helvetica", 20, "bold"))
        title.pack(pady=20)

        frame = tk.Frame(self.root, bg="#1e1e2f")
        frame.pack(pady=10)

        tk.Label(frame, text="Username:", bg="#1e1e2f", fg="white", font=self.custom_font).grid(row=0, column=0, sticky="e", pady=5)
        self.username_entry = tk.Entry(frame, font=self.custom_font)
        self.username_entry.grid(row=0, column=1, pady=5, padx=10)

        tk.Label(frame, text="Password:", bg="#1e1e2f", fg="white", font=self.custom_font).grid(row=1, column=0, sticky="e", pady=5)
        self.password_entry = tk.Entry(frame, show="*", font=self.custom_font)
        self.password_entry.grid(row=1, column=1, pady=5, padx=10)

        btn_frame = tk.Frame(self.root, bg="#1e1e2f")
        btn_frame.pack(pady=20)

        login_btn = tk.Button(btn_frame, text="Login", command=self.login, **self.button_style)
        login_btn.grid(row=0, column=0, padx=10)

        signup_btn = tk.Button(btn_frame, text="Sign Up", command=self.signup_screen, **self.button_style)
        signup_btn.grid(row=0, column=1, padx=10)

    def signup_screen(self):
        self.clear_window()

        title = tk.Label(self.root, text="Create New Account", bg="#1e1e2f", fg="white", font=("Helvetica", 20, "bold"))
        title.pack(pady=20)

        frame = tk.Frame(self.root, bg="#1e1e2f")
        frame.pack(pady=10)

        tk.Label(frame, text="Username:", bg="#1e1e2f", fg="white", font=self.custom_font).grid(row=0, column=0, sticky="e", pady=5)
        self.new_username_entry = tk.Entry(frame, font=self.custom_font)
        self.new_username_entry.grid(row=0, column=1, pady=5, padx=10)

        tk.Label(frame, text="Password:", bg="#1e1e2f", fg="white", font=self.custom_font).grid(row=1, column=0, sticky="e", pady=5)
        self.new_password_entry = tk.Entry(frame, show="*", font=self.custom_font)
        self.new_password_entry.grid(row=1, column=1, pady=5, padx=10)

        btn_frame = tk.Frame(self.root, bg="#1e1e2f")
        btn_frame.pack(pady=20)

        register_btn = tk.Button(btn_frame, text="Register", command=self.register_user, **self.button_style)
        register_btn.grid(row=0, column=0, padx=10)

        back_btn = tk.Button(btn_frame, text="Back to Login", command=self.login_screen, **self.button_style)
        back_btn.grid(row=0, column=1, padx=10)

    def register_user(self):
        username = self.new_username_entry.get()
        password = self.new_password_entry.get()
        if not username or not password:
            messagebox.showerror("Error", "Username and password cannot be empty.")
            return
        success = self.manager.add_user(username, password)
        if success:
            messagebox.showinfo("Success", "User registered successfully. Please login.")
            self.login_screen()
        else:
            messagebox.showerror("Error", "Username already exists. Please choose another.")

    def login(self):
        username = self.username_entry.get()
        password = self.password_entry.get()
        user = self.manager.authenticate_user(username, password)
        if user:
            self.current_user = user
            messagebox.showinfo("Login Success", f"Welcome {user.username}!")
            self.main_menu()
        else:
            messagebox.showerror("Login Failed", "Invalid username or password")

    def main_menu(self):
        self.clear_window()

        welcome_label = tk.Label(self.root, text=f"Welcome {self.current_user.username} ({self.current_user.role})", bg="#1e1e2f", fg="white", font=("Helvetica", 16, "bold"))
        welcome_label.pack(pady=20)

        btn_frame = tk.Frame(self.root, bg="#1e1e2f")
        btn_frame.pack(pady=10)

        view_cinemas_btn = tk.Button(btn_frame, text="View Cinemas", command=self.view_cinemas, **self.button_style)
        view_cinemas_btn.grid(row=0, column=0, padx=10, pady=5)

        # Only show Add Cinema button for Admin and Manager roles
        if self.current_user.role in ["Admin", "Manager"]:
            add_cinema_btn = tk.Button(btn_frame, text="Add Cinema", command=self.add_cinema, **self.button_style)
            add_cinema_btn.grid(row=0, column=1, padx=10, pady=5)

            manage_cinemas_btn = tk.Button(btn_frame, text="Manage Cinemas & Movies", command=self.manage_cinemas_and_movies, **self.button_style)
            manage_cinemas_btn.grid(row=0, column=2, padx=10, pady=5)

            if self.current_user.role == "Admin":
                manage_users_btn = tk.Button(btn_frame, text="Manage Users", command=self.manage_users_screen, **self.button_style)
                manage_users_btn.grid(row=0, column=3, padx=10, pady=5)
                admin_reports_btn = tk.Button(btn_frame, text="Admin Reports", command=self.admin_reports_view, **self.button_style)
                admin_reports_btn.grid(row=0, column=4, padx=10, pady=5)
                book_tickets_col = 5
            else:
                book_tickets_col = 3

            book_tickets_btn = tk.Button(btn_frame, text="Book Tickets", command=self.book_tickets, **self.button_style)
            book_tickets_btn.grid(row=0, column=book_tickets_col, padx=10, pady=5)

            cancel_booking_btn = tk.Button(btn_frame, text="Cancel Booking", command=self.cancel_booking_screen, **self.button_style)
            cancel_booking_btn.grid(row=0, column=book_tickets_col + 1, padx=10, pady=5)

            logout_btn = tk.Button(btn_frame, text="Logout", command=self.logout, **self.button_style)
            logout_btn.grid(row=0, column=book_tickets_col + 2, padx=10, pady=5)
        else:
            # For regular users, no Add Cinema button, only View Cinemas and Book Tickets
            book_tickets_btn = tk.Button(btn_frame, text="Book Tickets", command=self.book_tickets, **self.button_style)
            book_tickets_btn.grid(row=0, column=1, padx=10, pady=5)

            cancel_booking_btn = tk.Button(btn_frame, text="Cancel Booking", command=self.cancel_booking_screen, **self.button_style)
            cancel_booking_btn.grid(row=0, column=2, padx=10, pady=5)

            logout_btn = tk.Button(btn_frame, text="Logout", command=self.logout, **self.button_style)
            logout_btn.grid(row=0, column=3, padx=10, pady=5)

    def view_cinemas(self):
        self.clear_window()
        title = tk.Label(self.root, text="Cinemas", bg="#1e1e2f", fg="white", font=("Helvetica", 18, "bold"))
        title.pack(pady=20)

        # Place back button at the top for manager and admin
        if self.current_user.role in ["Admin", "Manager"]:
            back_btn_top = tk.Button(self.root, text="Back to Main Menu", command=self.main_menu, **self.button_style)
            back_btn_top.pack(pady=10)

        for cinema in self.manager.cinemas:
            frame = tk.Frame(self.root, bg="#1e1e2f")
            frame.pack(pady=5, fill="x", padx=20)

            cinema_label = tk.Label(frame, text=f"{cinema.name} - {cinema.city}", bg="#1e1e2f", fg="white", font=self.custom_font)
            cinema_label.pack(side="left")

            if self.current_user.role in ["Admin", "Manager"]:
                edit_btn = tk.Button(frame, text="Edit", command=lambda c=cinema: self.edit_cinema_screen(c), **self.button_style)
                edit_btn.pack(side="left", padx=5)

                delete_btn = tk.Button(frame, text="Delete", command=lambda c=cinema: self.delete_cinema(c), **self.button_style)
                delete_btn.pack(side="left", padx=5)

        back_btn = tk.Button(self.root, text="Back", command=self.main_menu, **self.button_style)
        back_btn.pack(pady=20)

    def add_cinema(self):
        cinema_name = simpledialog.askstring("Add Cinema", "Enter cinema name:")
        city = simpledialog.askstring("Add Cinema", "Enter city:")
        if cinema_name and city:
            self.manager.add_cinema(cinema_name, city)
            messagebox.showinfo("Success", "Cinema added successfully")
        self.main_menu()

    def edit_cinema_screen(self, cinema):
        self.clear_window()
        title = tk.Label(self.root, text=f"Edit Cinema: {cinema.name}", bg="#1e1e2f", fg="white", font=("Helvetica", 16, "bold"))
        title.pack(pady=20)

        tk.Label(self.root, text="Cinema Name:", bg="#1e1e2f", fg="white", font=self.custom_font).pack()
        name_entry = tk.Entry(self.root, font=self.custom_font)
        name_entry.pack(pady=5)
        name_entry.insert(0, cinema.name)

        tk.Label(self.root, text="City:", bg="#1e1e2f", fg="white", font=self.custom_font).pack()
        city_entry = tk.Entry(self.root, font=self.custom_font)
        city_entry.pack(pady=5)
        city_entry.insert(0, cinema.city)

        def save_changes():
            new_name = name_entry.get()
            new_city = city_entry.get()
            if not new_name or not new_city:
                messagebox.showerror("Error", "Name and city cannot be empty.")
                return
            success = self.manager.update_cinema(cinema.name, new_name, new_city)
            if success:
                messagebox.showinfo("Success", "Cinema updated successfully.")
                self.view_cinemas()
            else:
                messagebox.showerror("Error", "Failed to update cinema.")

        save_btn = tk.Button(self.root, text="Save", command=save_changes, **self.button_style)
        save_btn.pack(pady=10)

        back_btn = tk.Button(self.root, text="Back", command=self.view_cinemas, **self.button_style)
        back_btn.pack(pady=10)

    def delete_cinema(self, cinema):
        confirm = messagebox.askyesno("Confirm Delete", f"Are you sure you want to delete cinema '{cinema.name}'?")
        if confirm:
            self.manager.remove_cinema(cinema.name)
            messagebox.showinfo("Deleted", "Cinema deleted successfully.")
            self.view_cinemas()

    def book_tickets(self):
        self.clear_window()
        title = tk.Label(self.root, text="Select Cinema", bg="#1e1e2f", fg="white", font=("Helvetica", 18, "bold"))
        title.pack(pady=20)

        self.cinema_var = tk.StringVar(self.root)
        cinema_names = [cinema.name for cinema in self.manager.cinemas]
        if not cinema_names:
            messagebox.showinfo("No Cinemas", "No cinemas available to book.")
            self.main_menu()
            return
        self.cinema_var.set(cinema_names[0])
        cinema_menu = tk.OptionMenu(self.root, self.cinema_var, *cinema_names)
        cinema_menu.config(bg="#4a90e2", fg="white", font=self.custom_font)
        cinema_menu.pack(pady=10)

        next_btn = tk.Button(self.root, text="Next", command=self.select_film, **self.button_style)
        next_btn.pack(pady=10)

        back_btn = tk.Button(self.root, text="Back", command=self.main_menu, **self.button_style)
        back_btn.pack(pady=10)

    def select_film(self):
        selected_cinema_name = self.cinema_var.get()
        self.selected_cinema = next((c for c in self.manager.cinemas if c.name == selected_cinema_name), None)
        if not self.selected_cinema:
            messagebox.showerror("Error", "Selected cinema not found.")
            self.book_tickets()
            return

        self.clear_window()
        title = tk.Label(self.root, text="Select Film and Show Time", bg="#1e1e2f", fg="white", font=("Helvetica", 18, "bold"))
        title.pack(pady=20)

        self.film_showings = []
        for screen in self.selected_cinema.screens:
            for film, show_time in screen.showings:
                self.film_showings.append((film, show_time, screen))

        if not self.film_showings:
            messagebox.showinfo("No Showings", "No films available for booking in this cinema.")
            self.book_tickets()
            return

        # Sort film showings by show_time ascending
        self.film_showings.sort(key=lambda x: x[1])

        # Use a Listbox for vertical arrangement with bigger font
        self.film_listbox = tk.Listbox(self.root, font=("Helvetica", 14), bg="#2e2e3f", fg="white", selectbackground="#4a90e2", activestyle="none", width=40, height=10)
        for film, show_time, _ in self.film_showings:
            self.film_listbox.insert(tk.END, f"{show_time} - {film.title}")
        self.film_listbox.pack(pady=10)

        if self.current_user.role in ["Admin", "Manager"]:
            edit_film_btn = tk.Button(self.root, text="Edit Selected Film", command=self.edit_selected_film, **self.button_style)
            edit_film_btn.pack(pady=5)

            delete_film_btn = tk.Button(self.root, text="Delete Selected Film", command=self.delete_selected_film, **self.button_style)
            delete_film_btn.pack(pady=5)

        next_btn = tk.Button(self.root, text="Next", command=self.select_seats_from_listbox, **self.button_style)
        next_btn.pack(pady=10)

        back_btn = tk.Button(self.root, text="Back", command=self.book_tickets, **self.button_style)
        back_btn.pack(pady=10)

    def select_seats_from_listbox(self):
        try:
            index = self.film_listbox.curselection()
            if not index:
                messagebox.showerror("Error", "Please select a film showing.")
                return
            index = index[0]
            self.selected_film, self.selected_show_time, self.selected_screen = self.film_showings[index]

            self.selected_seats = set()
            self.num_tickets_var = tk.IntVar(value=1)

            self.render_seat_selection_screen()

        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")

    def render_seat_selection_screen(self):
        self.clear_window()
        title = tk.Label(self.root, text=f"Selected: {self.selected_film.title} at {self.selected_show_time}", bg="#1e1e2f", fg="white", font=("Helvetica", 16, "bold"))
        title.pack(pady=20)

        tk.Label(self.root, text="Number of Tickets:", bg="#1e1e2f", fg="white", font=self.custom_font).pack()
        tickets_spinbox = tk.Spinbox(self.root, from_=1, to=10, textvariable=self.num_tickets_var, font=self.custom_font, width=5)
        tickets_spinbox.pack(pady=5)

        tk.Label(self.root, text="Select Your Seats:", bg="#1e1e2f", fg="white", font=self.custom_font).pack(pady=(10,0))

        self.seat_buttons = []
        self.seat_categories = {}  # seat_num -> category

        seat_frame = tk.Frame(self.root, bg="#121212")
        seat_frame.pack(pady=10)

        seats_per_row = 10
        total_seats = self.selected_screen.seating_capacity
        rows = total_seats // seats_per_row
        if total_seats % seats_per_row != 0:
            rows += 1

        row_labels = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

        # Determine seat category boundaries
        lower_hall_limit = self.selected_screen.lower_hall_seats
        upper_gallery_limit = lower_hall_limit + self.selected_screen.upper_gallery_seats
        vip_limit = lower_hall_limit + self.selected_screen.vip_seats

        pay_btn = tk.Button(seat_frame, text="Proceed to Payment", command=self.store_seat_info_and_payment_screen, **self.button_style)
        pay_btn.grid(row=0, column=0, columnspan=seats_per_row + 1, pady=10)

        for r in range(rows):
            # Add row label on the left
            row_label = tk.Label(seat_frame, text=row_labels[r], bg="#121212", fg="#bbbbbb", font=("Helvetica", 14, "bold"))
            row_label.grid(row=r+1, column=0, padx=(0,10), pady=5, sticky="e")

            for c in range(seats_per_row):
                seat_num = r * seats_per_row + c + 1
                if seat_num > total_seats:
                    break

                # Determine seat category
                if seat_num <= lower_hall_limit:
                    category = "lower_hall"
                    color = "#2c3e50"  # base color
                elif seat_num <= vip_limit:
                    category = "vip"
                    color = "#d4af37"  # gold for VIP
                else:
                    category = "upper_gallery"
                    color = "#34495e"  # darker blue for upper gallery

                self.seat_categories[seat_num] = category

                btn = tk.Button(seat_frame, text="💺", width=4, height=2, bg=color, fg="#ecf0f1",
                                font=("Helvetica", 14), relief="raised", bd=3,
                                activebackground="#2980b9", activeforeground="#ecf0f1",
                                command=lambda sn=seat_num: self.toggle_seat(sn))
                btn.grid(row=r+1, column=c+1, padx=6, pady=6)
                self.seat_buttons.append(btn)

        self.update_seat_buttons()

        next_btn = tk.Button(self.root, text="Next", command=self.store_seat_info_and_payment_screen, **self.button_style)
        next_btn.pack(pady=10)

        back_btn = tk.Button(self.root, text="Back", command=self.select_film, **self.button_style)
        back_btn.pack(pady=10)

    def manage_cinemas_and_movies(self):
        self.clear_window()
        title = tk.Label(self.root, text="Manage Cinemas and Movies", bg="#1e1e2f", fg="white", font=("Helvetica", 18, "bold"))
        title.pack(pady=20)

        self.cinema_listbox = tk.Listbox(self.root, font=("Helvetica", 14), bg="#2e2e3f", fg="white", selectbackground="#4a90e2", activestyle="none", width=40, height=10)
        for cinema in self.manager.cinemas:
            self.cinema_listbox.insert(tk.END, f"{cinema.name} - {cinema.city}")
        self.cinema_listbox.pack(pady=10)

        select_btn = tk.Button(self.root, text="Select Cinema", command=self.manage_movies_for_selected_cinema, **self.button_style)
        select_btn.pack(pady=10)

        back_btn = tk.Button(self.root, text="Back", command=self.main_menu, **self.button_style)
        back_btn.pack(pady=10)

    def film_listing_view(self):
        self.clear_window()
        title = tk.Label(self.root, text="Film Listings", bg="#1e1e2f", fg="white", font=("Helvetica", 18, "bold"))
        title.pack(pady=20)

        self.film_listbox = tk.Listbox(self.root, font=("Helvetica", 14), bg="#2e2e3f", fg="white", selectbackground="#4a90e2", activestyle="none", width=60, height=15)
        self.films = []
        for cinema in self.manager.cinemas:
            for screen in cinema.screens:
                for film, show_time in screen.showings:
                    self.films.append((film, show_time, cinema.name, screen.screen_number))
        # Remove duplicates by film title and show_time
        unique_films = {}
        for film, show_time, cinema_name, screen_number in self.films:
            key = (film.title, show_time, cinema_name, screen_number)
            unique_films[key] = (film, show_time, cinema_name, screen_number)
        self.films = list(unique_films.values())

        for film, show_time, cinema_name, screen_number in self.films:
            display_text = f"{film.title} ({film.genre}, {film.rating}) - {show_time} at {cinema_name} Screen {screen_number}"
            self.film_listbox.insert(tk.END, display_text)
        self.film_listbox.pack(pady=10)

        view_details_btn = tk.Button(self.root, text="View Film Details", command=self.view_film_details, **self.button_style)
        view_details_btn.pack(pady=5)

        book_btn = tk.Button(self.root, text="Book Selected Film", command=self.book_selected_film, **self.button_style)
        book_btn.pack(pady=5)

        back_btn = tk.Button(self.root, text="Back", command=self.main_menu, **self.button_style)
        back_btn.pack(pady=10)

    def view_film_details(self):
        try:
            index = self.film_listbox.curselection()
            if not index:
                messagebox.showerror("Error", "Please select a film to view details.")
                return
            index = index[0]
            film, show_time, cinema_name, screen_number = self.films[index]

            self.clear_window()
            title = tk.Label(self.root, text=f"Film Details: {film.title}", bg="#1e2e2f", fg="white", font=("Helvetica", 18, "bold"))
            title.pack(pady=20)

            tk.Label(self.root, text=f"Description: {film.description}", bg="#1e2e2f", fg="white", font=self.custom_font, wraplength=600, justify="left").pack(pady=5)
            tk.Label(self.root, text=f"Genre: {film.genre}", bg="#1e2e2f", fg="white", font=self.custom_font).pack(pady=5)
            tk.Label(self.root, text=f"Rating: {film.rating}", bg="#1e2e2f", fg="white", font=self.custom_font).pack(pady=5)
            tk.Label(self.root, text=f"Cast: {', '.join(film.cast)}", bg="#1e2e2f", fg="white", font=self.custom_font).pack(pady=5)
            tk.Label(self.root, text=f"Show Time: {show_time}", bg="#1e2e2f", fg="white", font=self.custom_font).pack(pady=5)
            tk.Label(self.root, text=f"Cinema: {cinema_name}", bg="#1e2e2f", fg="white", font=self.custom_font).pack(pady=5)
            tk.Label(self.root, text=f"Screen: {screen_number}", bg="#1e2e2f", fg="white", font=self.custom_font).pack(pady=5)

            back_btn = tk.Button(self.root, text="Back to Listings", command=self.film_listing_view, **self.button_style)
            back_btn.pack(pady=10)
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")

    def book_selected_film(self):
        try:
            index = self.film_listbox.curselection()
            if not index:
                messagebox.showerror("Error", "Please select a film to book.")
                return
            index = index[0]
            film, show_time, cinema_name, screen_number = self.films[index]

            # Only admins can book on behalf of customers for other cinemas
            if self.current_user.role != "Admin" and cinema_name != self.current_user.username:
                messagebox.showerror("Permission Denied", "Only admins can book for other cinemas.")
                return

            self.selected_film = film
            self.selected_show_time = show_time
            self.selected_cinema_name = cinema_name
            self.selected_screen_number = screen_number

            # Proceed to seat selection for booking
            self.select_seats_for_booking()
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")

    def select_seats_for_booking(self):
        # Find the selected cinema and screen objects
        self.selected_cinema = next((c for c in self.manager.cinemas if c.name == self.selected_cinema_name), None)
        if not self.selected_cinema:
            messagebox.showerror("Error", "Selected cinema not found.")
            self.film_listing_view()
            return

        self.selected_screen = next((s for s in self.selected_cinema.screens if s.screen_number == self.selected_screen_number), None)
        if not self.selected_screen:
            messagebox.showerror("Error", "Selected screen not found.")
            self.film_listing_view()
            return

        # Set up seat selection UI
        self.selected_seats = set()
        self.num_tickets_var = tk.IntVar(value=1)
        self.render_seat_selection_screen()

    def show_booking_receipt(self, booking):
        self.clear_window()
        title = tk.Label(self.root, text="Booking Receipt", bg="#1e2e2f", fg="white", font=("Helvetica", 18, "bold"))
        title.pack(pady=20)

        receipt_text = (
            f"Booking Reference: {booking.booking_reference}\n"
            f"Film: {booking.film.title}\n"
            f"Date: {booking.show_time.split(' ')[0]}\n"
            f"Time: {booking.show_time.split(' ')[1]}\n"
            f"Screen #: {booking.screen.screen_number}\n"
            f"Number of Tickets: {booking.num_tickets}\n"
            f"Seat Numbers: {', '.join(map(str, booking.seat_numbers))}\n"
            f"Total Cost: £{booking.total_price:.2f}\n"
            f"Booking Date: {booking.timestamp.strftime('%Y-%m-%d %H:%M:%S')}\n"
        )

        receipt_label = tk.Label(self.root, text=receipt_text, bg="#1e2e2f", fg="white", font=self.custom_font, justify="left")
        receipt_label.pack(pady=10)

        back_btn = tk.Button(self.root, text="Back to Main Menu", command=self.main_menu, **self.button_style)
        back_btn.pack(pady=10)

    def admin_reports_view(self):
        self.clear_window()
        title = tk.Label(self.root, text="Admin Reports", bg="#1e2e2f", fg="white", font=("Helvetica", 18, "bold"))
        title.pack(pady=20)

        reports = self.manager.generate_admin_report()

        bookings_by_film = reports.get('bookings_by_film', {})
        monthly_revenue = reports.get('monthly_revenue_by_cinema', {})
        top_revenue_film = reports.get('top_revenue_film', {})
        staff_stats = reports.get('staff_booking_stats', {})

        # Display bookings by film
        tk.Label(self.root, text="Bookings by Film:", bg="#1e2e2f", fg="white", font=self.custom_font).pack(pady=5)
        for film, count in bookings_by_film.items():
            tk.Label(self.root, text=f"{film}: {count}", bg="#1e2e2f", fg="white", font=self.custom_font).pack()

        # Display monthly revenue by cinema
        tk.Label(self.root, text="Monthly Revenue by Cinema:", bg="#1e2e2f", fg="white", font=self.custom_font).pack(pady=5)
        for cinema, revenue in monthly_revenue.items():
            tk.Label(self.root, text=f"{cinema}: £{revenue:.2f}", bg="#1e2e2f", fg="white", font=self.custom_font).pack()

        # Display top revenue generating film
        tk.Label(self.root, text="Top Revenue Generating Film:", bg="#1e2e2f", fg="white", font=self.custom_font).pack(pady=5)
        if top_revenue_film:
            tk.Label(self.root, text=f"{top_revenue_film.get('film', 'N/A')}: £{top_revenue_film.get('revenue', 0):.2f}", bg="#1e2e2f", fg="white", font=self.custom_font).pack()
        else:
            tk.Label(self.root, text="No data available", bg="#1e2e2f", fg="white", font=self.custom_font).pack()

        # Display staff booking stats
        tk.Label(self.root, text="Staff Booking Stats:", bg="#1e2e2f", fg="white", font=self.custom_font).pack(pady=5)
        for staff, count in staff_stats.items():
            tk.Label(self.root, text=f"{staff}: {count}", bg="#1e2e2f", fg="white", font=self.custom_font).pack()

        back_btn = tk.Button(self.root, text="Back to Main Menu", command=self.main_menu, **self.button_style)
        back_btn.pack(pady=10)

    def manage_movies_for_selected_cinema(self):
        try:
            index = self.cinema_listbox.curselection()
            if not index:
                messagebox.showerror("Error", "Please select a cinema.")
                return
            index = index[0]
            self.selected_cinema = self.manager.cinemas[index]

            self.clear_window()
            title = tk.Label(self.root, text=f"Manage Movies for {self.selected_cinema.name}", bg="#1e1e2f", fg="white", font=("Helvetica", 18, "bold"))
            title.pack(pady=20)

            self.movie_listbox = tk.Listbox(self.root, font=("Helvetica", 14), bg="#2e2e3f", fg="white", selectbackground="#4a90e2", activestyle="none", width=40, height=10)
            self.movies = []
            for screen in self.selected_cinema.screens:
                for film, _ in screen.showings:
                    self.movies.append(film)
            # Remove duplicates by title
            unique_movies = {}
            for movie in self.movies:
                unique_movies[movie.title] = movie
            self.movies = list(unique_movies.values())

            for movie in self.movies:
                self.movie_listbox.insert(tk.END, movie.title)
            self.movie_listbox.pack(pady=10)

            edit_btn = tk.Button(self.root, text="Edit Selected Movie", command=self.edit_selected_film, **self.button_style)
            edit_btn.pack(pady=5)

            delete_btn = tk.Button(self.root, text="Delete Selected Movie", command=self.delete_selected_film, **self.button_style)
            delete_btn.pack(pady=5)

            back_btn = tk.Button(self.root, text="Back", command=self.manage_cinemas_and_movies, **self.button_style)
            back_btn.pack(pady=10)
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")

    def edit_selected_film(self):
        try:
            index = self.movie_listbox.curselection()
            if not index:
                messagebox.showerror("Error", "Please select a movie to edit.")
                return
            index = index[0]
            film = self.movies[index]

            self.clear_window()
            title = tk.Label(self.root, text=f"Edit Movie: {film.title}", bg="#1e1e2f", fg="white", font=("Helvetica", 16, "bold"))
            title.pack(pady=20)

            tk.Label(self.root, text="Title:", bg="#1e1e2f", fg="white", font=self.custom_font).pack()
            title_entry = tk.Entry(self.root, font=self.custom_font)
            title_entry.pack(pady=5)
            title_entry.insert(0, film.title)

            tk.Label(self.root, text="Description:", bg="#1e1e2f", fg="white", font=self.custom_font).pack()
            description_entry = tk.Entry(self.root, font=self.custom_font)
            description_entry.pack(pady=5)
            description_entry.insert(0, film.description)

            tk.Label(self.root, text="Genre:", bg="#1e1e2f", fg="white", font=self.custom_font).pack()
            genre_entry = tk.Entry(self.root, font=self.custom_font)
            genre_entry.pack(pady=5)
            genre_entry.insert(0, film.genre)

            tk.Label(self.root, text="Rating:", bg="#1e1e2f", fg="white", font=self.custom_font).pack()
            rating_entry = tk.Entry(self.root, font=self.custom_font)
            rating_entry.pack(pady=5)
            rating_entry.insert(0, film.rating)

            tk.Label(self.root, text="Cast (comma separated):", bg="#1e1e2f", fg="white", font=self.custom_font).pack()
            cast_entry = tk.Entry(self.root, font=self.custom_font)
            cast_entry.pack(pady=5)
            cast_entry.insert(0, ', '.join(film.cast))

            def save_changes():
                new_title = title_entry.get()
                new_description = description_entry.get()
                new_genre = genre_entry.get()
                new_rating = rating_entry.get()
                new_cast = [c.strip() for c in cast_entry.get().split(',') if c.strip()]
                if not new_title:
                    messagebox.showerror("Error", "Title cannot be empty.")
                    return
                success = self.manager.update_film(self.selected_cinema.name, film.title, new_title, new_description, new_genre, new_rating, new_cast)
                if success:
                    messagebox.showinfo("Success", "Movie updated successfully.")
                    self.manage_movies_for_selected_cinema()
                else:
                    messagebox.showerror("Error", "Failed to update movie.")

            save_btn = tk.Button(self.root, text="Save", command=save_changes, **self.button_style)
            save_btn.pack(pady=10)

            back_btn = tk.Button(self.root, text="Back", command=self.manage_movies_for_selected_cinema, **self.button_style)
            back_btn.pack(pady=10)
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")

    def delete_selected_film(self):
        try:
            index = self.movie_listbox.curselection()
            if not index:
                messagebox.showerror("Error", "Please select a movie to delete.")
                return
            index = index[0]
            film = self.movies[index]

            confirm = messagebox.askyesno("Confirm Delete", f"Are you sure you want to delete movie '{film.title}'?")
            if confirm:
                success = self.manager.remove_film(self.selected_cinema.name, film.title)
                if success:
                    messagebox.showinfo("Deleted", "Movie deleted successfully.")
                    self.manage_movies_for_selected_cinema()
                else:
                    messagebox.showerror("Error", "Failed to delete movie.")
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")

    def payment_screen_back(self):
        # Go back to seat selection screen with previous values restored
        self.clear_window()
        title = tk.Label(self.root, text=f"Selected: {self.selected_film.title} at {self.selected_show_time}", bg="#1e1e2f", fg="white", font=("Helvetica", 16, "bold"))
        title.pack(pady=20)

        tk.Label(self.root, text="Number of Tickets:", bg="#1e1e2f", fg="white", font=self.custom_font).pack()
        self.tickets_entry = tk.Entry(self.root, font=self.custom_font)
        self.tickets_entry.pack(pady=5)
        self.tickets_entry.insert(0, str(self.num_tickets))

        tk.Label(self.root, text="Seat Numbers (comma separated):", bg="#1e1e2f", fg="white", font=self.custom_font).pack()
        self.seats_entry = tk.Entry(self.root, font=self.custom_font)
        self.seats_entry.pack(pady=5)
        self.seats_entry.insert(0, ', '.join(self.seat_numbers))

        pay_btn = tk.Button(self.root, text="Proceed to Payment", command=self.store_seat_info_and_payment_screen, **self.button_style)
        pay_btn.pack(pady=10)

        back_btn = tk.Button(self.root, text="Back", command=self.select_film, **self.button_style)
        back_btn.pack(pady=10)

    def process_payment(self):
        card_number = self.card_number_entry.get()
        expiry_date = self.expiry_entry.get()
        cvv = self.cvv_entry.get()

        if not card_number or not expiry_date or not cvv:
            messagebox.showerror("Error", "Please fill in all payment details.")
            return

        # Simulate payment processing
        success = self.manager.process_payment(self.selected_film.title, card_number, expiry_date, cvv)
        if success:
            try:
                num_tickets = self.num_tickets
                seat_numbers = self.seat_numbers
                seat_categories = self.seat_categories_list
                booking = Booking(self.selected_film, self.selected_screen, self.selected_show_time, num_tickets, seat_numbers, seat_categories)
                self.manager.add_booking(booking)
                messagebox.showinfo("Success", f"Payment successful! Booking confirmed. Reference: {booking.booking_reference}")
                self.show_booking_receipt(booking)
            except ValueError:
                messagebox.showerror("Error", "Invalid number of tickets.")
        else:
            messagebox.showerror("Payment Failed", "Payment was not successful. Please try again.")

    def store_seat_info_and_payment_screen(self):
        # Store selected seats and number of tickets, then show payment screen
        self.num_tickets = self.num_tickets_var.get()
        self.seat_numbers = sorted(list(self.selected_seats))
        self.seat_categories_list = [self.seat_categories[sn] for sn in self.seat_numbers]

        self.clear_window()
        title = tk.Label(self.root, text="Payment Information", bg="#1e1e2f", fg="white", font=("Helvetica", 18, "bold"))
        title.pack(pady=20)

        tk.Label(self.root, text=f"Film: {self.selected_film.title}", bg="#1e1e2f", fg="white", font=self.custom_font).pack()
        tk.Label(self.root, text=f"Show Time: {self.selected_show_time}", bg="#1e1e2f", fg="white", font=self.custom_font).pack()
        tk.Label(self.root, text=f"Number of Tickets: {self.num_tickets}", bg="#1e1e2f", fg="white", font=self.custom_font).pack()
        tk.Label(self.root, text=f"Seats: {', '.join(map(str, self.seat_numbers))}", bg="#1e1e2f", fg="white", font=self.custom_font).pack(pady=(0, 20))

        # Calculate total price based on seat categories and film prices
        total_price = 0
        category_counts = {"lower_hall": 0, "upper_gallery": 0, "vip": 0}
        for category in self.seat_categories_list:
            category_counts[category] += 1
            if category == "lower_hall":
                total_price += self.selected_film.lower_hall_price
            elif category == "upper_gallery":
                total_price += self.selected_film.upper_gallery_price
            elif category == "vip":
                total_price += self.selected_film.vip_price
        tk.Label(self.root, text=f"Total Price: £{total_price:.2f}", bg="#1e1e2f", fg="white", font=self.custom_font).pack(pady=(0, 20))

        # Show breakdown of ticket counts and prices by category
        breakdown_text = "Ticket Breakdown:\n"
        if category_counts["lower_hall"] > 0:
            breakdown_text += f"Lower Hall ({category_counts['lower_hall']} x £{self.selected_film.lower_hall_price:.2f})\n"
        if category_counts["upper_gallery"] > 0:
            breakdown_text += f"Upper Gallery ({category_counts['upper_gallery']} x £{self.selected_film.upper_gallery_price:.2f})\n"
        if category_counts["vip"] > 0:
            breakdown_text += f"VIP ({category_counts['vip']} x £{self.selected_film.vip_price:.2f})\n"
        tk.Label(self.root, text=breakdown_text, bg="#1e1e2f", fg="white", font=self.custom_font, justify="left").pack(pady=(0, 20))

        # Additional user info inputs
        tk.Label(self.root, text="Name:", bg="#1e2e2f", fg="white", font=self.custom_font).pack()
        self.name_entry = tk.Entry(self.root, font=self.custom_font)
        self.name_entry.pack(pady=5)

        tk.Label(self.root, text="Email:", bg="#1e2e2f", fg="white", font=self.custom_font).pack()
        self.email_entry = tk.Entry(self.root, font=self.custom_font)
        self.email_entry.pack(pady=5)

        tk.Label(self.root, text="Phone Number:", bg="#1e2e2f", fg="white", font=self.custom_font).pack()
        self.phone_entry = tk.Entry(self.root, font=self.custom_font)
        self.phone_entry.pack(pady=5)

        tk.Label(self.root, text="Card Number:", bg="#1e2e2f", fg="white", font=self.custom_font).pack()
        self.card_number_entry = tk.Entry(self.root, font=self.custom_font)
        self.card_number_entry.pack(pady=5)

        tk.Label(self.root, text="Expiry Date (MM/YY):", bg="#1e2e2f", fg="white", font=self.custom_font).pack()
        self.expiry_entry = tk.Entry(self.root, font=self.custom_font)
        self.expiry_entry.pack(pady=5)

        tk.Label(self.root, text="CVV:", bg="#1e2e2f", fg="white", font=self.custom_font).pack()
        self.cvv_entry = tk.Entry(self.root, font=self.custom_font, show="*")
        self.cvv_entry.pack(pady=5)

        pay_btn = tk.Button(self.root, text="Pay", command=self.process_payment, **self.button_style)
        pay_btn.pack(pady=10)

        back_btn = tk.Button(self.root, text="Back", command=self.render_seat_selection_screen, **self.button_style)
        back_btn.pack(pady=10)

    def toggle_seat(self, seat_num):
        if seat_num in self.selected_seats:
            self.selected_seats.remove(seat_num)
        else:
            if len(self.selected_seats) < self.num_tickets_var.get():
                self.selected_seats.add(seat_num)
            else:
                messagebox.showwarning("Warning", "You have already selected the maximum number of seats.")
        self.update_seat_buttons()

    def update_seat_buttons(self):
        # Update the seat buttons' appearance based on selection
        for idx, btn in enumerate(self.seat_buttons):
            seat_num = idx + 1
            if seat_num in self.selected_seats:
                btn.config(bg="#2980b9", relief="sunken")
            else:
                btn.config(bg="#2c3e50", relief="raised")

    def logout(self):
        self.current_user = None
        self.login_screen()

    def clear_window(self):
        for widget in self.root.winfo_children():
            widget.destroy()

    def cancel_booking_screen(self):
        self.clear_window()
        title = tk.Label(self.root, text="Cancel Booking", bg="#1e1e2f", fg="white", font=("Helvetica", 16, "bold"))
        title.pack(pady=20)

        tk.Label(self.root, text="Enter Booking Reference:", bg="#1e1e2f", fg="white", font=self.custom_font).pack()
        self.cancel_ref_entry = tk.Entry(self.root, font=self.custom_font)
        self.cancel_ref_entry.pack(pady=5)

        cancel_btn = tk.Button(self.root, text="Request Refund", command=self.process_refund, **self.button_style)
        cancel_btn.pack(pady=10)

        back_btn = tk.Button(self.root, text="Back", command=self.main_menu, **self.button_style)
        back_btn.pack(pady=10)

    def manage_users_screen(self):
        self.clear_window()
        title = tk.Label(self.root, text="Manage Users", bg="#1e1e2f", fg="white", font=("Helvetica", 18, "bold"))
        title.pack(pady=20)

        self.user_listbox = tk.Listbox(self.root, font=("Helvetica", 14), bg="#2e2e3f", fg="white", selectbackground="#4a90e2", activestyle="none", width=40, height=15)
        for user in self.manager.users:
            self.user_listbox.insert(tk.END, f"{user.username} ({user.role})")
        self.user_listbox.pack(pady=10)

        add_user_btn = tk.Button(self.root, text="Add User", command=self.add_user_screen, **self.button_style)
        add_user_btn.pack(pady=5)

        edit_role_btn = tk.Button(self.root, text="Edit User Role", command=self.edit_user_role_screen, **self.button_style)
        edit_role_btn.pack(pady=5)

        delete_user_btn = tk.Button(self.root, text="Delete User", command=self.delete_user, **self.button_style)
        delete_user_btn.pack(pady=5)

        back_btn = tk.Button(self.root, text="Back", command=self.main_menu, **self.button_style)
        back_btn.pack(pady=10)

    def add_user_screen(self):
        self.clear_window()
        title = tk.Label(self.root, text="Add New User", bg="#1e1e2f", fg="white", font=("Helvetica", 18, "bold"))
        title.pack(pady=20)

        tk.Label(self.root, text="Username:", bg="#1e1e2f", fg="white", font=self.custom_font).pack()
        username_entry = tk.Entry(self.root, font=self.custom_font)
        username_entry.pack(pady=5)

        tk.Label(self.root, text="Password:", bg="#1e1e2f", fg="white", font=self.custom_font).pack()
        password_entry = tk.Entry(self.root, show="*", font=self.custom_font)
        password_entry.pack(pady=5)

        tk.Label(self.root, text="Role:", bg="#1e1e2f", fg="white", font=self.custom_font).pack()
        role_var = tk.StringVar(self.root)
        role_var.set("User")
        role_menu = tk.OptionMenu(self.root, role_var, "Admin", "Manager", "Booking Staff", "User")
        role_menu.config(bg="#4a90e2", fg="white", font=self.custom_font)
        role_menu.pack(pady=5)

        def add_user():
            username = username_entry.get()
            password = password_entry.get()
            role = role_var.get()
            if not username or not password:
                messagebox.showerror("Error", "Username and password cannot be empty.")
                return
            success = self.manager.add_user(username, password, role)
            if success:
                messagebox.showinfo("Success", "User added successfully.")
                self.manage_users_screen()
            else:
                messagebox.showerror("Error", "Username already exists.")

        add_btn = tk.Button(self.root, text="Add User", command=add_user, **self.button_style)
        add_btn.pack(pady=10)

        back_btn = tk.Button(self.root, text="Back", command=self.manage_users_screen, **self.button_style)
        back_btn.pack(pady=10)

    def edit_user_role_screen(self):
        try:
            index = self.user_listbox.curselection()
            if not index:
                messagebox.showerror("Error", "Please select a user to edit.")
                return
            index = index[0]
            user = self.manager.users[index]

            self.clear_window()
            title = tk.Label(self.root, text=f"Edit Role for {user.username}", bg="#1e1e2f", fg="white", font=("Helvetica", 18, "bold"))
            title.pack(pady=20)

            tk.Label(self.root, text="Role:", bg="#1e1e2f", fg="white", font=self.custom_font).pack()
            role_var = tk.StringVar(self.root)
            role_var.set(user.role)
            role_menu = tk.OptionMenu(self.root, role_var, "Admin", "Manager", "Booking Staff", "User")
            role_menu.config(bg="#4a90e2", fg="white", font=self.custom_font)
            role_menu.pack(pady=5)

            def save_role():
                new_role = role_var.get()
                success = self.manager.update_user_role(user.username, new_role)
                if success:
                    messagebox.showinfo("Success", "User role updated successfully.")
                    self.manage_users_screen()
                else:
                    messagebox.showerror("Error", "Failed to update user role.")

            save_btn = tk.Button(self.root, text="Save", command=save_role, **self.button_style)
            save_btn.pack(pady=10)

            back_btn = tk.Button(self.root, text="Back", command=self.manage_users_screen, **self.button_style)
            back_btn.pack(pady=10)
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")

    def delete_user(self):
        try:
            index = self.user_listbox.curselection()
            if not index:
                messagebox.showerror("Error", "Please select a user to delete.")
                return
            index = index[0]
            user = self.manager.users[index]

            if user.username == self.current_user.username:
                messagebox.showerror("Error", "You cannot delete the currently logged-in user.")
                return

            confirm = messagebox.askyesno("Confirm Delete", f"Are you sure you want to delete user '{user.username}'?")
            if confirm:
                success = self.manager.remove_user(user.username)
                if success:
                    messagebox.showinfo("Deleted", "User deleted successfully.")
                    self.manage_users_screen()
                else:
                    messagebox.showerror("Error", "Failed to delete user.")
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")

    def process_refund(self):
        booking_ref = self.cancel_ref_entry.get()
        if not booking_ref:
            messagebox.showerror("Error", "Please enter a booking reference.")
            return
        success = self.manager.refund_booking(booking_ref)
        if success:
            messagebox.showinfo("Success", f"Booking {booking_ref} refunded successfully.")
            self.main_menu()
        else:
            messagebox.showerror("Error", f"Booking {booking_ref} not found. Please check the reference and try again.")

if __name__ == "__main__":
    root = tk.Tk()
    app = HorizonCinemaApp(root)
    root.mainloop()
