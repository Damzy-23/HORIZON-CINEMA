import sqlite3
import os

class Database:
    def __init__(self, db_path=None):
        if db_path is None:
            base_dir = os.path.dirname(os.path.abspath(__file__))
            db_path = os.path.join(base_dir, '..', '..', 'cinema_data.db')
            db_path = os.path.abspath(db_path)
        self.db_path = db_path
        self.conn = sqlite3.connect(self.db_path)
        self.create_tables()

    def create_tables(self):
        cursor = self.conn.cursor()

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS cinemas (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                city TEXT NOT NULL
            )
        ''')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS screens (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                cinema_id INTEGER NOT NULL,
                screen_number INTEGER NOT NULL,
                seating_capacity INTEGER NOT NULL,
                FOREIGN KEY (cinema_id) REFERENCES cinemas(id)
            )
        ''')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS films (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                description TEXT,
                genre TEXT,
                rating TEXT,
                actors TEXT,
                price REAL DEFAULT 0.0
            )
        ''')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS showings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                screen_id INTEGER NOT NULL,
                film_id INTEGER NOT NULL,
                show_time TEXT NOT NULL,
                FOREIGN KEY (screen_id) REFERENCES screens(id),
                FOREIGN KEY (film_id) REFERENCES films(id)
            )
        ''')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                role TEXT NOT NULL
            )
        ''')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS bookings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                film_id INTEGER NOT NULL,
                screen_id INTEGER NOT NULL,
                show_time TEXT NOT NULL,
                num_tickets INTEGER NOT NULL,
                seat_numbers TEXT,
                price_per_ticket REAL,
                total_price REAL,
                booking_reference TEXT UNIQUE NOT NULL,
                timestamp TEXT NOT NULL,
                FOREIGN KEY (user_id) REFERENCES users(id),
                FOREIGN KEY (film_id) REFERENCES films(id),
                FOREIGN KEY (screen_id) REFERENCES screens(id)
            )
        ''')

        self.conn.commit()

    def close(self):
        self.conn.close()
