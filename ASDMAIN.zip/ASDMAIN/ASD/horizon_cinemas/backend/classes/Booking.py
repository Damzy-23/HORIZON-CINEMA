import random
import datetime

class Booking:
    def __init__(self, film, screen, show_time, num_tickets, seat_numbers, seat_categories, price_per_ticket=10):
        self.film = film
        self.screen = screen
        self.show_time = show_time
        self.num_tickets = num_tickets
        self.seat_numbers = seat_numbers
        self.seat_categories = seat_categories  # List of categories corresponding to seat_numbers
        self.price_per_ticket = price_per_ticket
        self.timestamp = datetime.datetime.now()
        self.booking_reference = self.generate_reference()

    @property
    def total_price(self):
        # Calculate total price based on seat categories and film prices
        total = 0
        for category in self.seat_categories:
            if category == "lower_hall":
                total += self.film.lower_hall_price
            elif category == "upper_gallery":
                total += self.film.upper_gallery_price
            elif category == "vip":
                total += self.film.vip_price
            else:
                total += self.price_per_ticket  # fallback
        return total

    def generate_reference(self):
        return f"REF{random.randint(1000, 9999)}"

    def __repr__(self):
        return (f"Booking(ref={self.booking_reference}, film={self.film.title}, "
                f"screen={self.screen.screen_number}, show_time={self.show_time}, "
                f"tickets={self.num_tickets}, total_price={self.total_price}, "
                f"timestamp={self.timestamp})")
