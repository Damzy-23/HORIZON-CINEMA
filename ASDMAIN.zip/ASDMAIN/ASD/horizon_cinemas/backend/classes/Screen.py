class Screen:
    def __init__(self, screen_number, seating_capacity):
        self.screen_number = screen_number
        self.seating_capacity = seating_capacity
        self.showings = []  # List of tuples (Film, show_time)

        # Calculate seat distribution
        self.lower_hall_seats = int(seating_capacity * 0.3)
        self.upper_gallery_seats = seating_capacity - self.lower_hall_seats
        self.vip_seats = min(10, self.upper_gallery_seats)  # Up to 10 VIP seats in upper gallery

    def add_showing(self, film, show_time):
        self.showings.append((film, show_time))

    def remove_showing(self, film_title, show_time):
        self.showings = [
            (film, time) for (film, time) in self.showings
            if not (film.title == film_title and time == show_time)
        ]

    def get_showings(self):
        return self.showings

    def get_seat_counts(self):
        return {
            "lower_hall": self.lower_hall_seats,
            "upper_gallery": self.upper_gallery_seats,
            "vip": self.vip_seats
        }

    def __repr__(self):
        return f"Screen(number={self.screen_number}, capacity={self.seating_capacity}, lower_hall={self.lower_hall_seats}, upper_gallery={self.upper_gallery_seats}, vip={self.vip_seats})"
