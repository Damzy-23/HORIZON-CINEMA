const rateLimit = require('express-rate-limit');
const RedisStore = require('rate-limit-redis');
const Redis = require('ioredis');
const config = require('../config/redis');

const redis = new Redis({
    host: config.host,
    port: config.port,
    password: config.password
});

const limiter = rateLimit({
    store: new RedisStore({
        client: redis,
        prefix: 'rate-limit:',
        expiry: 60 * 15 // 15 minutes in seconds
    }),
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // Limit each IP to 100 requests per windowMs
    message: {
        error: 'Too many requests, please try again later.'
    },
    standardHeaders: true,
    legacyHeaders: false
});

// Specific limiter for login attempts
const loginLimiter = rateLimit({
    store: new RedisStore({
        client: redis,
        prefix: 'login-limit:'
    }),
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 5, // Limit each IP to 5 login attempts per windowMs
    message: {
        error: 'Too many login attempts, please try again later.'
    }
});

module.exports = {
    limiter,
    loginLimiter
}; 