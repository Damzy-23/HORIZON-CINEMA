const Joi = require('joi');

// Validation schemas
const schemas = {
    booking: Joi.object({
        screeningId: Joi.string().required(),
        customerName: Joi.string().required().min(2).max(50),
        customerEmail: Joi.string().email().required(),
        seats: Joi.array().items(
            Joi.object({
                type: Joi.string().valid('lowerHall', 'upperGallery', 'vip').required(),
                seatNumber: Joi.number().required()
            })
        ).min(1).required(),
        totalCost: Joi.number().positive().required()
    }),

    screening: Joi.object({
        filmId: Joi.string().required(),
        cinemaId: Joi.string().required(),
        screenNumber: Joi.number().required().min(1).max(6),
        showtime: Joi.date().greater('now').required(),
        price: Joi.object({
            lowerHall: Joi.number().positive().required(),
            upperGallery: Joi.number().positive().required(),
            vipSeats: Joi.number().positive().required()
        }).required()
    }),

    cinema: Joi.object({
        name: Joi.string().required().min(2).max(100),
        city: Joi.string().required(),
        location: Joi.string().required(),
        screens: Joi.array().items(
            Joi.object({
                screenNumber: Joi.number().required(),
                capacity: Joi.object({
                    lowerHall: Joi.number().required().min(1),
                    upperGallery: Joi.number().required().min(1),
                    vipSeats: Joi.number().required().min(0)
                }).required()
            })
        ).min(1).max(6).required(),
        priceRanges: Joi.object({
            morningShow: Joi.number().positive().required(),
            afternoonShow: Joi.number().positive().required(),
            eveningShow: Joi.number().positive().required()
        }).required()
    }),

    film: Joi.object({
        title: Joi.string().required().min(1).max(200),
        description: Joi.string().required(),
        actors: Joi.array().items(Joi.string()),
        genre: Joi.string().required(),
        ageRating: Joi.string().required(),
        duration: Joi.number().required().min(1),
        rating: Joi.number().min(0).max(5),
        posterUrl: Joi.string().uri()
    })
};

// Validation middleware factory
const validate = (schemaName) => {
    return (req, res, next) => {
        const schema = schemas[schemaName];
        if (!schema) {
            throw new Error(`Schema ${schemaName} not found`);
        }

        const { error } = schema.validate(req.body, {
            abortEarly: false,
            allowUnknown: true
        });

        if (error) {
            const details = error.details.map(detail => detail.message);
            return res.status(400).json({
                error: 'Validation Error',
                details
            });
        }

        next();
    };
};

module.exports = validate; 