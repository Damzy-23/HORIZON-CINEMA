const requestLogger = (req, res, next) => {
    const start = Date.now();
    
    // Log request details
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
    
    // Log request body if present
    if (Object.keys(req.body).length) {
        console.log('Request Body:', JSON.stringify(req.body, null, 2));
    }

    // Capture response
    const oldSend = res.send;
    res.send = function(data) {
        const duration = Date.now() - start;
        console.log(`Response Time: ${duration}ms`);
        console.log(`Status: ${res.statusCode}`);
        
        // Don't log sensitive routes
        if (!req.url.includes('/auth')) {
            console.log('Response:', JSON.stringify(data, null, 2));
        }
        
        oldSend.apply(res, arguments);
    };

    next();
};

module.exports = requestLogger; 