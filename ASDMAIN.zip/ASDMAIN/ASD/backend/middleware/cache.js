const cacheService = require('../services/cacheService');

const cache = (duration = 3600) => {
    return async (req, res, next) => {
        // Skip caching for non-GET requests
        if (req.method !== 'GET') {
            return next();
        }

        const key = `cache:${req.originalUrl}`;

        try {
            const cachedData = await cacheService.get(key);
            
            if (cachedData) {
                return res.json(JSON.parse(cachedData));
            }

            // Store original send function
            const originalSend = res.send;

            // Override send function to cache response
            res.send = function(body) {
                cacheService.set(key, body, duration);
                originalSend.call(this, body);
            };

            next();
        } catch (error) {
            console.error('Cache middleware error:', error);
            next();
        }
    };
};

module.exports = cache; 