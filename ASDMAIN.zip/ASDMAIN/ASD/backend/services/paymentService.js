const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const loggingService = require('./loggingService');
const metricsService = require('./metricsService');

class PaymentService {
    async createPaymentIntent(booking) {
        const start = Date.now();
        
        try {
            const paymentIntent = await stripe.paymentIntents.create({
                amount: Math.round(booking.totalCost * 100), // Convert to cents
                currency: 'gbp',
                metadata: {
                    bookingReference: booking.bookingReference,
                    customerEmail: booking.customerEmail
                }
            });

            // Record payment processing time
            const duration = (Date.now() - start) / 1000;
            metricsService.recordPaymentProcessing(duration);

            return paymentIntent;
        } catch (error) {
            loggingService.error('Payment intent creation failed', {
                error: error.message,
                bookingReference: booking.bookingReference
            });
            throw error;
        }
    }

    async confirmPayment(paymentIntentId) {
        try {
            const paymentIntent = await stripe.paymentIntents.retrieve(
                paymentIntentId
            );

            if (paymentIntent.status === 'succeeded') {
                return {
                    success: true,
                    paymentId: paymentIntent.id
                };
            }

            return {
                success: false,
                status: paymentIntent.status
            };
        } catch (error) {
            loggingService.error('Payment confirmation failed', {
                error: error.message,
                paymentIntentId
            });
            throw error;
        }
    }

    async processRefund(booking, amount) {
        try {
            const refund = await stripe.refunds.create({
                payment_intent: booking.paymentIntentId,
                amount: Math.round(amount * 100), // Convert to cents
                metadata: {
                    bookingReference: booking.bookingReference,
                    reason: 'booking_cancellation'
                }
            });

            return {
                success: true,
                refundId: refund.id,
                amount: refund.amount / 100 // Convert back to pounds
            };
        } catch (error) {
            loggingService.error('Refund processing failed', {
                error: error.message,
                bookingReference: booking.bookingReference
            });
            throw error;
        }
    }
}

module.exports = new PaymentService(); 