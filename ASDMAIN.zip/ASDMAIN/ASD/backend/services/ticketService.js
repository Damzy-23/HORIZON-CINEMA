const PDFDocument = require('pdfkit');
const QRCode = require('qrcode');
const path = require('path');

class TicketService {
    async generateTicket(booking) {
        const doc = new PDFDocument({
            size: 'A4',
            margin: 50
        });

        // Generate QR code
        const qrCodeData = await QRCode.toDataURL(booking.bookingReference);

        // Add cinema logo
        doc.image(path.join(__dirname, '../assets/logo.png'), 50, 45, { width: 50 });

        // Add header
        doc.font('Helvetica-Bold')
           .fontSize(25)
           .text('Cinema Ticket', 120, 57);

        // Add booking details
        doc.moveDown()
           .font('Helvetica')
           .fontSize(12)
           .text(`Booking Reference: ${booking.bookingReference}`, 50, 140)
           .text(`Customer: ${booking.customerName}`, 50, 160)
           .text(`Film: ${booking.film.title}`, 50, 180)
           .text(`Date: ${new Date(booking.screening.showtime).toLocaleDateString()}`, 50, 200)
           .text(`Time: ${new Date(booking.screening.showtime).toLocaleTimeString()}`, 50, 220)
           .text(`Screen: ${booking.screening.screenNumber}`, 50, 240);

        // Add seats
        doc.moveDown()
           .font('Helvetica-Bold')
           .text('Seats:', 50, 270);

        let yPosition = 290;
        booking.seats.forEach(seat => {
            doc.font('Helvetica')
               .text(`${seat.type}: Seat ${seat.seatNumber}`, 70, yPosition);
            yPosition += 20;
        });

        // Add QR code
        doc.image(qrCodeData, 400, 140, { width: 150 });

        // Add total cost
        doc.moveDown()
           .font('Helvetica-Bold')
           .text(`Total Cost: £${booking.totalCost.toFixed(2)}`, 50, yPosition + 20);

        // Add footer
        doc.fontSize(10)
           .text(
               'Please present this ticket at the cinema. Valid ID may be required.',
               50,
               doc.page.height - 100,
               { width: 500, align: 'center' }
           );

        return doc;
    }

    async generateMultipleTickets(booking) {
        const doc = new PDFDocument({
            size: 'A4',
            margin: 50,
            autoFirstPage: false
        });

        // Generate individual ticket for each seat
        for (let i = 0; i < booking.seats.length; i++) {
            doc.addPage();
            const seat = booking.seats[i];

            // Generate QR code for each seat
            const qrCodeData = await QRCode.toDataURL(
                `${booking.bookingReference}-${seat.seatNumber}`
            );

            // Add cinema logo
            doc.image(path.join(__dirname, '../assets/logo.png'), 50, 45, { width: 50 });

            // Add header
            doc.font('Helvetica-Bold')
               .fontSize(25)
               .text('Cinema Ticket', 120, 57);

            // Add ticket details
            doc.moveDown()
               .font('Helvetica')
               .fontSize(12)
               .text(`Ticket ${i + 1} of ${booking.seats.length}`, 50, 120)
               .text(`Booking Reference: ${booking.bookingReference}`, 50, 140)
               .text(`Film: ${booking.film.title}`, 50, 160)
               .text(`Date: ${new Date(booking.screening.showtime).toLocaleDateString()}`, 50, 180)
               .text(`Time: ${new Date(booking.screening.showtime).toLocaleTimeString()}`, 50, 200)
               .text(`Screen: ${booking.screening.screenNumber}`, 50, 220)
               .moveDown()
               .font('Helvetica-Bold')
               .text('Seat Details:', 50, 250)
               .font('Helvetica')
               .text(`${seat.type}: Seat ${seat.seatNumber}`, 70, 270);

            // Add QR code
            doc.image(qrCodeData, 400, 140, { width: 150 });

            // Add footer
            doc.fontSize(10)
               .text(
                   'Please present this ticket at the cinema. Valid ID may be required.',
                   50,
                   doc.page.height - 100,
                   { width: 500, align: 'center' }
               );
        }

        return doc;
    }
}

module.exports = new TicketService(); 