const winston = require('winston');
const { format } = winston;
const path = require('path');

class LoggingService {
    constructor() {
        const logDir = path.join(__dirname, '../logs');

        this.logger = winston.createLogger({
            level: process.env.NODE_ENV === 'production' ? 'info' : 'debug',
            format: format.combine(
                format.timestamp(),
                format.errors({ stack: true }),
                format.json()
            ),
            defaultMeta: { service: 'cinema-booking' },
            transports: [
                // Write all logs to console
                new winston.transports.Console({
                    format: format.combine(
                        format.colorize(),
                        format.simple()
                    )
                }),
                // Write all errors to error.log
                new winston.transports.File({
                    filename: path.join(logDir, 'error.log'),
                    level: 'error'
                }),
                // Write all logs to combined.log
                new winston.transports.File({
                    filename: path.join(logDir, 'combined.log')
                })
            ]
        });

        // Handle uncaught exceptions
        this.logger.exceptions.handle(
            new winston.transports.File({
                filename: path.join(logDir, 'exceptions.log')
            })
        );

        // Handle unhandled promise rejections
        process.on('unhandledRejection', (ex) => {
            throw ex;
        });
    }

    info(message, meta = {}) {
        this.logger.info(message, meta);
    }

    error(message, meta = {}) {
        this.logger.error(message, meta);
    }

    warn(message, meta = {}) {
        this.logger.warn(message, meta);
    }

    debug(message, meta = {}) {
        this.logger.debug(message, meta);
    }
}

module.exports = new LoggingService(); 