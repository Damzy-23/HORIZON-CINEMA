const prometheus = require('prom-client');

class MetricsService {
    constructor() {
        // Enable collection of default metrics
        prometheus.collectDefaultMetrics();

        // Custom metrics
        this.httpRequestDuration = new prometheus.Histogram({
            name: 'http_request_duration_seconds',
            help: 'Duration of HTTP requests in seconds',
            labelNames: ['method', 'route', 'status_code'],
            buckets: [0.1, 0.5, 1, 2, 5]
        });

        this.bookingsTotal = new prometheus.Counter({
            name: 'bookings_total',
            help: 'Total number of bookings'
        });

        this.activeBookings = new prometheus.Gauge({
            name: 'active_bookings',
            help: 'Current number of active bookings'
        });

        this.seatUtilization = new prometheus.Gauge({
            name: 'seat_utilization_percentage',
            help: 'Percentage of seats occupied per screening',
            labelNames: ['screeningId']
        });

        this.paymentProcessingTime = new prometheus.Histogram({
            name: 'payment_processing_seconds',
            help: 'Time taken to process payments',
            buckets: [0.1, 0.5, 1, 2, 5, 10]
        });
    }

    recordHttpRequest(method, route, statusCode, duration) {
        this.httpRequestDuration
            .labels(method, route, statusCode)
            .observe(duration);
    }

    incrementBookings() {
        this.bookingsTotal.inc();
    }

    setActiveBookings(count) {
        this.activeBookings.set(count);
    }

    setSeatUtilization(screeningId, percentage) {
        this.seatUtilization.labels(screeningId).set(percentage);
    }

    recordPaymentProcessing(duration) {
        this.paymentProcessingTime.observe(duration);
    }

    async getMetrics() {
        return await prometheus.register.metrics();
    }
}

module.exports = new MetricsService(); 