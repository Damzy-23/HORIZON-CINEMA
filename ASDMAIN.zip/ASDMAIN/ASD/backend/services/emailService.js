const nodemailer = require('nodemailer');
const path = require('path');
const ejs = require('ejs');

class EmailService {
    constructor() {
        this.transporter = nodemailer.createTransport({
            host: process.env.SMTP_HOST,
            port: process.env.SMTP_PORT,
            secure: process.env.SMTP_SECURE === 'true',
            auth: {
                user: process.env.SMTP_USER,
                pass: process.env.SMTP_PASS
            }
        });

        this.templatePath = path.join(__dirname, '../templates/emails');
    }

    async sendBookingConfirmation(booking) {
        const template = await ejs.renderFile(
            path.join(this.templatePath, 'booking-confirmation.ejs'),
            {
                booking,
                cinema: booking.cinema,
                film: booking.film
            }
        );

        await this.transporter.sendMail({
            from: `"Cinema Booking" <${process.env.SMTP_FROM}>`,
            to: booking.customerEmail,
            subject: 'Booking Confirmation',
            html: template
        });
    }

    async sendCancellationConfirmation(booking, refundAmount) {
        const template = await ejs.renderFile(
            path.join(this.templatePath, 'booking-cancellation.ejs'),
            {
                booking,
                refundAmount
            }
        );

        await this.transporter.sendMail({
            from: `"Cinema Booking" <${process.env.SMTP_FROM}>`,
            to: booking.customerEmail,
            subject: 'Booking Cancellation Confirmation',
            html: template
        });
    }

    async sendReminder(booking) {
        const template = await ejs.renderFile(
            path.join(this.templatePath, 'booking-reminder.ejs'),
            {
                booking,
                cinema: booking.cinema,
                film: booking.film
            }
        );

        await this.transporter.sendMail({
            from: `"Cinema Booking" <${process.env.SMTP_FROM}>`,
            to: booking.customerEmail,
            subject: 'Your Movie is Tomorrow!',
            html: template
        });
    }
}

module.exports = new EmailService(); 