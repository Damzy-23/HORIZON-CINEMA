const Booking = require('../models/Booking');
const Cinema = require('../models/Cinema');
const Film = require('../models/Film');
const User = require('../models/User');

exports.getRevenueReport = async (req, res) => {
    try {
        const { cinemaId, startDate, endDate } = req.query;
        const query = {
            status: 'active',
            bookingDate: {
                $gte: new Date(startDate || new Date().setMonth(new Date().getMonth() - 6)),
                $lte: new Date(endDate || Date.now())
            }
        };

        if (cinemaId) {
            query.cinemaId = cinemaId;
        }

        const revenueData = await Booking.aggregate([
            { $match: query },
            {
                $group: {
                    _id: {
                        year: { $year: "$bookingDate" },
                        month: { $month: "$bookingDate" }
                    },
                    revenue: { $sum: "$totalCost" }
                }
            },
            { $sort: { "_id.year": 1, "_id.month": 1 } }
        ]);

        const formattedData = revenueData.map(item => ({
            month: `${item._id.year}-${String(item._id.month).padStart(2, '0')}`,
            revenue: item.revenue
        }));

        res.json(formattedData);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.getTopFilms = async (req, res) => {
    try {
        const { cinemaId, limit = 10 } = req.query;
        const query = { status: 'active' };

        if (cinemaId) {
            query.cinemaId = cinemaId;
        }

        const topFilms = await Booking.aggregate([
            { $match: query },
            { $unwind: "$seats" },
            {
                $group: {
                    _id: "$screeningId",
                    ticketsSold: { $sum: 1 },
                    revenue: { $sum: "$totalCost" }
                }
            },
            {
                $lookup: {
                    from: "screenings",
                    localField: "_id",
                    foreignField: "_id",
                    as: "screening"
                }
            },
            { $unwind: "$screening" },
            {
                $lookup: {
                    from: "films",
                    localField: "screening.filmId",
                    foreignField: "_id",
                    as: "film"
                }
            },
            { $unwind: "$film" },
            {
                $group: {
                    _id: "$film._id",
                    title: { $first: "$film.title" },
                    ticketsSold: { $sum: "$ticketsSold" },
                    revenue: { $sum: "$revenue" }
                }
            },
            { $sort: { ticketsSold: -1 } },
            { $limit: parseInt(limit) }
        ]);

        res.json(topFilms);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.getStaffPerformance = async (req, res) => {
    try {
        const { cinemaId, startDate, endDate } = req.query;
        const query = {
            status: 'active',
            bookingDate: {
                $gte: new Date(startDate || new Date().setMonth(new Date().getMonth() - 1)),
                $lte: new Date(endDate || Date.now())
            }
        };

        if (cinemaId) {
            query.cinemaId = cinemaId;
        }

        const staffPerformance = await Booking.aggregate([
            { $match: query },
            {
                $group: {
                    _id: "$bookedBy",
                    bookingsCount: { $sum: 1 },
                    totalRevenue: { $sum: "$totalCost" }
                }
            },
            {
                $lookup: {
                    from: "users",
                    localField: "_id",
                    foreignField: "_id",
                    as: "user"
                }
            },
            { $unwind: "$user" },
            {
                $project: {
                    username: "$user.username",
                    role: "$user.role",
                    bookingsCount: 1,
                    totalRevenue: 1
                }
            },
            { $sort: { bookingsCount: -1 } }
        ]);

        res.json(staffPerformance);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.getOccupancyRates = async (req, res) => {
    try {
        const { cinemaId, startDate, endDate } = req.query;
        const query = {
            showtime: {
                $gte: new Date(startDate || new Date().setDate(new Date().getDate() - 7)),
                $lte: new Date(endDate || Date.now())
            }
        };

        if (cinemaId) {
            query.cinemaId = cinemaId;
        }

        const occupancyRates = await Booking.aggregate([
            { $match: query },
            {
                $lookup: {
                    from: "screenings",
                    localField: "screeningId",
                    foreignField: "_id",
                    as: "screening"
                }
            },
            { $unwind: "$screening" },
            {
                $group: {
                    _id: {
                        screeningId: "$screeningId",
                        screenNumber: "$screening.screenNumber"
                    },
                    totalSeatsBooked: { $sum: { $size: "$seats" } },
                    capacity: { $first: "$screening.capacity" }
                }
            },
            {
                $project: {
                    screenNumber: "$_id.screenNumber",
                    occupancyRate: {
                        $multiply: [
                            {
                                $divide: [
                                    "$totalSeatsBooked",
                                    { $sum: ["$capacity.lowerHall", "$capacity.upperGallery", "$capacity.vipSeats"] }
                                ]
                            },
                            100
                        ]
                    }
                }
            },
            { $sort: { occupancyRate: -1 } }
        ]);

        res.json(occupancyRates);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
}; 