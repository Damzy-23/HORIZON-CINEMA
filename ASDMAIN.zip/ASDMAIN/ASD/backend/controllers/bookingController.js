const Booking = require('../models/Booking');
const Screening = require('../models/Screening');
const { generateBookingReference, checkSeatAvailability, updateScreeningSeats, returnSeatsToPool } = require('../utils/helpers');
const seatService = require('../services/seatService');

exports.createBooking = async (req, res) => {
    try {
        const { screeningId, customerName, customerEmail, seats, totalCost } = req.body;

        // Verify screening exists and seats are available
        const screening = await Screening.findById(screeningId);
        if (!screening) {
            return res.status(404).json({ error: 'Screening not found' });
        }

        // Check if selected seats are still available
        const seatAvailability = await checkSeatAvailability(screening, seats);
        if (!seatAvailability.available) {
            return res.status(400).json({ error: 'Selected seats are no longer available' });
        }

        // Create booking
        const booking = new Booking({
            bookingReference: generateBookingReference(),
            screeningId,
            customerName,
            customerEmail,
            seats,
            totalCost,
            bookedBy: req.user._id
        });

        await booking.save();

        // Update screening's available seats
        await updateScreeningSeats(screening, seats);

        // After successfully creating a booking
        await seatService.updateAvailableSeats(booking.screeningId);
        res.status(201).json(booking);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

exports.cancelBooking = async (req, res) => {
    try {
        const booking = await Booking.findOne({ 
            bookingReference: req.params.reference,
            status: 'active'
        });

        if (!booking) {
            return res.status(404).json({ error: 'Booking not found' });
        }

        // Check cancellation eligibility
        const screening = await Screening.findById(booking.screeningId);
        const showDate = new Date(screening.showtime);
        const today = new Date();

        if (showDate.toDateString() === today.toDateString()) {
            return res.status(400).json({ 
                error: 'Cannot cancel booking on the day of the show' 
            });
        }

        // Calculate refund amount (50% of total cost)
        const refundAmount = booking.totalCost * 0.5;

        // Update booking status
        booking.status = 'cancelled';
        await booking.save();

        // Return seats to available pool
        await returnSeatsToPool(screening, booking.seats);

        // After successfully cancelling a booking
        await seatService.updateAvailableSeats(booking.screeningId);
        res.json({ 
            message: 'Booking cancelled successfully',
            refundAmount
        });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

exports.getBookings = async (req, res) => {
    try {
        const query = {};
        
        // Filter by cinema if staff user
        if (req.user.role === 'staff') {
            query.cinemaId = req.user.cinemaId;
        }

        const bookings = await Booking.find(query)
            .populate('screeningId')
            .sort({ bookingDate: -1 });

        res.json(bookings);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
}; 