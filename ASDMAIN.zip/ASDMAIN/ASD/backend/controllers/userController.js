const User = require('../models/User');
const bcrypt = require('bcryptjs');

exports.getUserProfile = async (req, res) => {
    try {
        const user = await User.findById(req.user._id).select('-password');
        res.json(user);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.updateProfile = async (req, res) => {
    try {
        const updates = req.body;
        const allowedUpdates = ['username', 'email', 'preferences'];

        // Filter out non-allowed updates
        Object.keys(updates).forEach(key => {
            if (!allowedUpdates.includes(key)) delete updates[key];
        });

        const user = await User.findById(req.user._id);
        Object.assign(user, updates);
        await user.save();

        res.json({ 
            message: 'Profile updated successfully',
            user: user.toJSON()
        });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

exports.changePassword = async (req, res) => {
    try {
        const { currentPassword, newPassword } = req.body;
        const user = await User.findById(req.user._id);

        // Verify current password
        const isMatch = await bcrypt.compare(currentPassword, user.password);
        if (!isMatch) {
            return res.status(400).json({ error: 'Current password is incorrect' });
        }

        // Hash new password
        user.password = await bcrypt.hash(newPassword, 10);
        await user.save();

        res.json({ message: 'Password changed successfully' });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

exports.updatePreferences = async (req, res) => {
    try {
        const { preferences } = req.body;
        const user = await User.findById(req.user._id);

        user.preferences = {
            ...user.preferences,
            ...preferences
        };

        await user.save();
        res.json({ 
            message: 'Preferences updated successfully',
            preferences: user.preferences
        });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

exports.getActivityLog = async (req, res) => {
    try {
        const logs = await ActivityLog.find({ userId: req.user._id })
            .sort({ timestamp: -1 })
            .limit(50);
        res.json(logs);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Hash password before saving user
const hashedPassword = await bcrypt.hash(req.body.password, 10); 