const emailService = require('../services/emailService');
const Booking = require('../models/Booking');
const schedule = require('node-schedule');

exports.sendBookingConfirmation = async (booking) => {
    try {
        await emailService.sendBookingConfirmation(booking);
        
        // Schedule a reminder for 24 hours before the show
        const reminderTime = new Date(booking.screening.showtime);
        reminderTime.setHours(reminderTime.getHours() - 24);
        
        schedule.scheduleJob(reminderTime, async () => {
            const updatedBooking = await Booking.findById(booking._id)
                .populate('screening')
                .populate('cinema')
                .populate('film');
                
            if (updatedBooking && updatedBooking.status === 'active') {
                await emailService.sendReminder(updatedBooking);
            }
        });
    } catch (error) {
        console.error('Error sending booking confirmation:', error);
    }
};

exports.sendCancellationConfirmation = async (booking, refundAmount) => {
    try {
        await emailService.sendCancellationConfirmation(booking, refundAmount);
    } catch (error) {
        console.error('Error sending cancellation confirmation:', error);
    }
};

// Add this to your existing booking controller
exports.handleBookingConfirmation = async (req, res, next) => {
    const booking = req.booking; // Assuming booking is attached by previous middleware
    
    try {
        await exports.sendBookingConfirmation(booking);
        next();
    } catch (error) {
        next(error);
    }
}; 