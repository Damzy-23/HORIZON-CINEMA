const Cinema = require('../models/Cinema');
const Screening = require('../models/Screening');
const Booking = require('../models/Booking');

exports.createCinema = async (req, res) => {
    try {
        const cinema = new Cinema(req.body);
        await cinema.save();
        res.status(201).json(cinema);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

exports.getAllCinemas = async (req, res) => {
    try {
        const cinemas = await Cinema.find();
        res.json(cinemas);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.getCinemaById = async (req, res) => {
    try {
        const cinema = await Cinema.findById(req.params.id);
        if (!cinema) {
            return res.status(404).json({ error: 'Cinema not found' });
        }
        res.json(cinema);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.updateCinema = async (req, res) => {
    try {
        const cinema = await Cinema.findByIdAndUpdate(
            req.params.id,
            req.body,
            { new: true, runValidators: true }
        );
        if (!cinema) {
            return res.status(404).json({ error: 'Cinema not found' });
        }
        res.json(cinema);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

exports.deleteCinema = async (req, res) => {
    try {
        // Check for active screenings and bookings
        const activeScreenings = await Screening.findOne({ 
            cinemaId: req.params.id,
            showtime: { $gte: new Date() }
        });

        if (activeScreenings) {
            return res.status(400).json({ 
                error: 'Cannot delete cinema with active screenings' 
            });
        }

        const activeBookings = await Booking.findOne({
            cinemaId: req.params.id,
            status: 'active'
        });

        if (activeBookings) {
            return res.status(400).json({ 
                error: 'Cannot delete cinema with active bookings' 
            });
        }

        const cinema = await Cinema.findByIdAndDelete(req.params.id);
        if (!cinema) {
            return res.status(404).json({ error: 'Cinema not found' });
        }

        res.json({ message: 'Cinema deleted successfully' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.getCinemaScreenings = async (req, res) => {
    try {
        const screenings = await Screening.find({ 
            cinemaId: req.params.id,
            showtime: { $gte: new Date() }
        })
        .populate('filmId')
        .sort({ showtime: 1 });

        res.json(screenings);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.getCinemaStats = async (req, res) => {
    try {
        const cinema = await Cinema.findById(req.params.id);
        if (!cinema) {
            return res.status(404).json({ error: 'Cinema not found' });
        }

        const totalScreens = cinema.screens.length;
        const totalCapacity = cinema.screens.reduce((total, screen) => {
            return total + screen.capacity.lowerHall + 
                   screen.capacity.upperGallery + 
                   screen.capacity.vipSeats;
        }, 0);

        const activeScreenings = await Screening.countDocuments({
            cinemaId: req.params.id,
            showtime: { $gte: new Date() }
        });

        const monthlyRevenue = await Booking.aggregate([
            {
                $match: {
                    cinemaId: req.params.id,
                    status: 'active',
                    bookingDate: {
                        $gte: new Date(new Date().setMonth(new Date().getMonth() - 1))
                    }
                }
            },
            {
                $group: {
                    _id: null,
                    total: { $sum: "$totalCost" }
                }
            }
        ]);

        res.json({
            totalScreens,
            totalCapacity,
            activeScreenings,
            monthlyRevenue: monthlyRevenue[0]?.total || 0
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
}; 