const paymentService = require('../services/paymentService');
const Booking = require('../models/Booking');
const loggingService = require('../services/loggingService');

exports.createPaymentIntent = async (req, res) => {
    try {
        const { bookingId } = req.body;
        
        const booking = await Booking.findById(bookingId);
        if (!booking) {
            return res.status(404).json({ error: 'Booking not found' });
        }

        const paymentIntent = await paymentService.createPaymentIntent(booking);
        
        booking.paymentIntentId = paymentIntent.id;
        await booking.save();

        res.json({
            clientSecret: paymentIntent.client_secret
        });
    } catch (error) {
        loggingService.error('Payment intent creation failed', {
            error: error.message
        });
        res.status(500).json({ error: error.message });
    }
};

exports.confirmPayment = async (req, res) => {
    try {
        const { bookingId } = req.params;
        
        const booking = await Booking.findById(bookingId);
        if (!booking) {
            return res.status(404).json({ error: 'Booking not found' });
        }

        const result = await paymentService.confirmPayment(
            booking.paymentIntentId
        );

        if (result.success) {
            booking.paymentStatus = 'paid';
            booking.status = 'active';
            await booking.save();

            res.json({
                success: true,
                booking
            });
        } else {
            res.json({
                success: false,
                status: result.status
            });
        }
    } catch (error) {
        loggingService.error('Payment confirmation failed', {
            error: error.message
        });
        res.status(500).json({ error: error.message });
    }
};

exports.handleWebhook = async (req, res) => {
    const sig = req.headers['stripe-signature'];
    
    try {
        const event = stripe.webhooks.constructEvent(
            req.body,
            sig,
            process.env.STRIPE_WEBHOOK_SECRET
        );

        switch (event.type) {
            case 'payment_intent.succeeded':
                await handlePaymentSuccess(event.data.object);
                break;
            case 'payment_intent.payment_failed':
                await handlePaymentFailure(event.data.object);
                break;
            default:
                loggingService.info(`Unhandled event type ${event.type}`);
        }

        res.json({ received: true });
    } catch (error) {
        loggingService.error('Webhook handling failed', {
            error: error.message
        });
        res.status(400).json({ error: error.message });
    }
}; 