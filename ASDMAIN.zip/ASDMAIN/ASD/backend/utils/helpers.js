// Generate unique booking reference
exports.generateBookingReference = () => {
    const prefix = 'HC';
    const timestamp = Date.now().toString(36);
    const random = Math.random().toString(36).substr(2, 5);
    return `${prefix}${timestamp}${random}`.toUpperCase();
};

// Check if selected seats are available
exports.checkSeatAvailability = async (screening, selectedSeats) => {
    for (const section in selectedSeats) {
        for (const seatNumber of selectedSeats[section]) {
            if (!screening.availableSeats[section].includes(seatNumber)) {
                return {
                    available: false,
                    section,
                    seatNumber
                };
            }
        }
    }
    return { available: true };
};

// Update screening's available seats
exports.updateScreeningSeats = async (screening, selectedSeats) => {
    for (const section in selectedSeats) {
        screening.availableSeats[section] = screening.availableSeats[section]
            .filter(seat => !selectedSeats[section].includes(seat));
    }
    await screening.save();
};

// Return cancelled seats to available pool
exports.returnSeatsToPool = async (screening, seats) => {
    for (const section in seats) {
        screening.availableSeats[section] = [
            ...screening.availableSeats[section],
            ...seats[section]
        ].sort((a, b) => a - b);
    }
    await screening.save();
}; 