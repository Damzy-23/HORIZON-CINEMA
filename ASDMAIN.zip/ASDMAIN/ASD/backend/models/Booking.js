const mongoose = require('mongoose');

const bookingSchema = new mongoose.Schema({
    bookingReference: { type: String, unique: true },
    screeningId: { type: mongoose.Schema.Types.ObjectId, ref: 'Screening' },
    customerName: String,
    customerEmail: String,
    seats: [{
        type: { enum: ['lowerHall', 'upperGallery', 'vip'] },
        seatNumber: Number
    }],
    totalCost: Number,
    bookingDate: { type: Date, default: Date.now },
    status: { type: String, enum: ['active', 'cancelled'], default: 'active' },
    bookedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
});

module.exports = mongoose.model('Booking', bookingSchema); 