const mongoose = require('mongoose');

const cinemaSchema = new mongoose.Schema({
    name: { type: String, required: true },
    city: { type: String, required: true },
    location: { type: String, required: true },
    screens: [{
        screenNumber: Number,
        capacity: {
            lowerHall: Number,
            upperGallery: Number,
            vipSeats: Number
        }
    }],
    priceRanges: {
        morningShow: Number,
        afternoonShow: Number,
        eveningShow: Number
    }
});

module.exports = mongoose.model('Cinema', cinemaSchema); 