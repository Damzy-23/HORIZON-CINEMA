const mongoose = require('mongoose');

const filmSchema = new mongoose.Schema({
    title: { type: String, required: true },
    description: { type: String, required: true },
    actors: [String],
    genre: { type: String, required: true },
    ageRating: { type: String, required: true },
    duration: Number,
    rating: Number,
    posterUrl: String,
    averageRating: {
        type: Number,
        default: 0
    }
});

module.exports = mongoose.model('Film', filmSchema); 