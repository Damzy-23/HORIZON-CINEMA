const express = require('express');
const router = express.Router();
const metricsService = require('../services/metricsService');
const { auth, checkRole } = require('../middleware/auth');

// Health check endpoint
router.get('/health', (req, res) => {
    res.json({ status: 'ok' });
});

// Metrics endpoint (protected)
router.get('/metrics', 
    auth, 
    checkRole(['admin']), 
    async (req, res) => {
        try {
            const metrics = await metricsService.getMetrics();
            res.set('Content-Type', 'text/plain');
            res.send(metrics);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }
);

// System status endpoint (protected)
router.get('/status',
    auth,
    checkRole(['admin', 'manager']),
    async (req, res) => {
        try {
            const status = {
                uptime: process.uptime(),
                timestamp: Date.now(),
                memory: process.memoryUsage(),
                cpu: process.cpuUsage(),
                nodeVersion: process.version,
                env: process.env.NODE_ENV
            };
            res.json(status);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }
);

module.exports = router; 