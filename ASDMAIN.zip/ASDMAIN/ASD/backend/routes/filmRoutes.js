/**
 * @swagger
 * tags:
 *   name: Films
 *   description: Film management
 */

/**
 * @swagger
 * /films:
 *   get:
 *     summary: Get all films
 *     tags: [Films]
 *     responses:
 *       200:
 *         description: A list of films
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Film'
 */

/**
 * @swagger
 * /films:
 *   post:
 *     summary: Create a new film
 *     tags: [Films]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Film'
 *     responses:
 *       201:
 *         description: Film created
 *       400:
 *         description: Invalid input
 */

/**
 * @swagger
 * components:
 *   schemas:
 *     Film:
 *       type: object
 *       required:
 *         - title
 *         - genre
 *         - ageRating
 *         - description
 *       properties:
 *         title:
 *           type: string
 *         genre:
 *           type: string
 *         ageRating:
 *           type: string
 *         description:
 *           type: string
 */ 