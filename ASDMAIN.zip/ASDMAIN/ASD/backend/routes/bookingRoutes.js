const express = require('express');
const router = express.Router();
const bookingController = require('../controllers/bookingController');
const { auth, checkRole } = require('../middleware/auth');

// Create booking
router.post('/bookings', 
    auth, 
    checkRole(['staff', 'admin']), 
    bookingController.createBooking
);

// Cancel booking
router.post('/bookings/:reference/cancel', 
    auth, 
    checkRole(['staff', 'admin']), 
    bookingController.cancelBooking
);

// Get bookings (with role-based access)
router.get('/bookings', 
    auth, 
    checkRole(['staff', 'admin', 'manager']), 
    bookingController.getBookings
);

module.exports = router; 