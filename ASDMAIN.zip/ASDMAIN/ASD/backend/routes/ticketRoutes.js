const express = require('express');
const router = express.Router();
const ticketController = require('../controllers/ticketController');
const { auth } = require('../middleware/auth');

// Download single combined ticket
router.get(
    '/bookings/:bookingReference/ticket',
    auth,
    ticketController.downloadTicket
);

// Download individual tickets
router.get(
    '/bookings/:bookingReference/tickets/individual',
    auth,
    ticketController.downloadIndividualTickets
);

module.exports = router; 