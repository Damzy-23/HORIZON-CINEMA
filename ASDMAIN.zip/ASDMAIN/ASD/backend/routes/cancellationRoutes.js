const express = require('express');
const router = express.Router();
const cancellationController = require('../controllers/cancellationController');
const { auth, checkRole } = require('../middleware/auth');

// Cancel booking
router.post('/bookings/:bookingReference/cancel', 
    auth, 
    checkRole(['staff', 'admin']), 
    cancellationController.cancelBooking
);

// Get cancellation history
router.get('/cancellations', 
    auth, 
    checkRole(['staff', 'admin', 'manager']), 
    cancellationController.getCancellationHistory
);

module.exports = router; 