const express = require('express');
const router = express.Router();
const paymentController = require('../controllers/paymentController');
const { auth } = require('../middleware/auth');

// Create payment intent
router.post(
    '/payment-intent',
    auth,
    paymentController.createPaymentIntent
);

// Confirm payment
router.post(
    '/confirm/:bookingId',
    auth,
    paymentController.confirmPayment
);

// Stripe webhook
router.post(
    '/webhook',
    express.raw({ type: 'application/json' }),
    paymentController.handleWebhook
);

module.exports = router; 