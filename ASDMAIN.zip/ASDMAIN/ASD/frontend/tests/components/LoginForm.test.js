import { mount } from '@vue/test-utils'
import LoginForm from '@/components/LoginForm.vue'
import { createRouter, createWebHistory } from 'vue-router'

describe('LoginForm.vue', () => {
    let router;

    beforeEach(() => {
        router = createRouter({
            history: createWebHistory(),
            routes: [
                { path: '/admin', name: 'admin' },
                { path: '/manager', name: 'manager' },
                { path: '/booking', name: 'booking' }
            ]
        });
    });

    it('submits the form with correct credentials', async () => {
        const wrapper = mount(LoginForm, {
            global: {
                plugins: [router]
            }
        });

        // Mock successful login response
        global.fetch.mockImplementationOnce(() =>
            Promise.resolve({
                ok: true,
                json: () => Promise.resolve({
                    token: 'test-token',
                    user: {
                        role: 'staff',
                        username: 'testuser'
                    }
                })
            })
        );

        // Fill in form
        await wrapper.find('input[type="text"]').setValue('testuser');
        await wrapper.find('input[type="password"]').setValue('password123');

        // Submit form
        await wrapper.find('form').trigger('submit');

        // Verify localStorage was updated
        expect(localStorage.setItem).toHaveBeenCalledWith('token', 'test-token');
        expect(localStorage.setItem).toHaveBeenCalledWith(
            'user',
            JSON.stringify({
                role: 'staff',
                username: 'testuser'
            })
        );
    });

    it('displays error message on failed login', async () => {
        const wrapper = mount(LoginForm, {
            global: {
                plugins: [router]
            }
        });

        // Mock failed login response
        global.fetch.mockImplementationOnce(() =>
            Promise.resolve({
                ok: false,
                json: () => Promise.resolve({
                    error: 'Invalid credentials'
                })
            })
        );

        // Fill in form
        await wrapper.find('input[type="text"]').setValue('testuser');
        await wrapper.find('input[type="password"]').setValue('wrongpassword');

        // Submit form
        await wrapper.find('form').trigger('submit');

        // Verify error is displayed
        expect(wrapper.text()).toContain('Invalid credentials');
    });

    it('redirects to correct route based on user role', async () => {
        const roles = {
            admin: '/admin',
            manager: '/manager',
            staff: '/booking'
        };

        for (const [role, expectedPath] of Object.entries(roles)) {
            const wrapper = mount(LoginForm, {
                global: {
                    plugins: [router]
                }
            });

            // Mock successful login with different roles
            global.fetch.mockImplementationOnce(() =>
                Promise.resolve({
                    ok: true,
                    json: () => Promise.resolve({
                        token: 'test-token',
                        user: { role }
                    })
                })
            );

            // Submit form
            await wrapper.find('form').trigger('submit');

            // Verify redirect
            expect(router.currentRoute.value.path).toBe(expectedPath);
        }
    });
}); 