const API_URL = '/api';

export const cinemaService = {
    async getAllCinemas() {
        const response = await fetch(`${API_URL}/cinemas`, {
            headers: this.getHeaders()
        });
        return this.handleResponse(response);
    },

    async getCinemaById(id) {
        const response = await fetch(`${API_URL}/cinemas/${id}`, {
            headers: this.getHeaders()
        });
        return this.handleResponse(response);
    },

    async createCinema(cinemaData) {
        const response = await fetch(`${API_URL}/cinemas`, {
            method: 'POST',
            headers: this.getHeaders(),
            body: JSON.stringify(cinemaData)
        });
        return this.handleResponse(response);
    },

    async updateCinema(id, cinemaData) {
        const response = await fetch(`${API_URL}/cinemas/${id}`, {
            method: 'PUT',
            headers: this.getHeaders(),
            body: JSON.stringify(cinemaData)
        });
        return this.handleResponse(response);
    },

    async deleteCinema(id) {
        const response = await fetch(`${API_URL}/cinemas/${id}`, {
            method: 'DELETE',
            headers: this.getHeaders()
        });
        return this.handleResponse(response);
    },

    async getCinemaScreenings(id) {
        const response = await fetch(`${API_URL}/cinemas/${id}/screenings`, {
            headers: this.getHeaders()
        });
        return this.handleResponse(response);
    },

    async getCinemaStats(id) {
        const response = await fetch(`${API_URL}/cinemas/${id}/stats`, {
            headers: this.getHeaders()
        });
        return this.handleResponse(response);
    },

    getHeaders() {
        const headers = {
            'Content-Type': 'application/json'
        };
        
        const token = localStorage.getItem('token');
        if (token) {
            headers['Authorization'] = `Bearer ${token}`;
        }
        
        return headers;
    },

    async handleResponse(response) {
        const data = await response.json();
        
        if (!response.ok) {
            if (response.status === 401) {
                // Auto logout if 401 response returned from api
                localStorage.removeItem('token');
                localStorage.removeItem('user');
                location.reload();
            }
            
            throw new Error(data.error || 'Something went wrong');
        }
        
        return data;
    }
}; 