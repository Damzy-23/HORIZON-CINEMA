<template>
    <div class="feedback-form">
        <h3>Submit Feedback</h3>
        <form @submit.prevent="handleSubmit">
            <div class="mb-3">
                <label class="form-label">Rating</label>
                <select class="form-select" v-model="feedback.rating" required>
                    <option v-for="n in 5" :key="n" :value="n">{{ n }}</option>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Comment</label>
                <textarea class="form-control" v-model="feedback.comment" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Submit Feedback</button>
        </form>
    </div>
</template>

<script>
export default {
    props: {
        filmId: {
            type: String,
            required: true
        }
    },
    data() {
        return {
            feedback: {
                rating: 1,
                comment: ''
            }
        }
    },
    methods: {
        async handleSubmit() {
            try {
                await this.$axios.post('/api/feedback', { filmId: this.filmId, ...this.feedback });
                this.$emit('feedback-submitted');
                this.feedback.comment = ''; // Reset comment
            } catch (error) {
                console.error('Error submitting feedback:', error);
            }
        }
    }
}
</script>

<style scoped>
.feedback-form {
    margin-top: 20px;
}
</style> 