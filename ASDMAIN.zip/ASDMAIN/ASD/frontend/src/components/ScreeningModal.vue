<template>
    <div class="modal fade" ref="modal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        {{ screening ? 'Edit Screening' : 'Add New Screening' }}
                    </h5>
                    <button type="button" 
                            class="btn-close" 
                            data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form @submit.prevent="handleSubmit">
                        <div class="mb-3">
                            <label class="form-label">Cinema</label>
                            <select class="form-select"
                                    v-model="formData.cinemaId"
                                    required>
                                <option value="">Select Cinema</option>
                                <option v-for="cinema in cinemas" 
                                        :key="cinema._id" 
                                        :value="cinema._id">
                                    {{ cinema.name }}
                                </option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Film</label>
                            <select class="form-select"
                                    v-model="formData.filmId"
                                    required>
                                <option value="">Select Film</option>
                                <option v-for="film in films" 
                                        :key="film._id" 
                                        :value="film._id">
                                    {{ film.title }}
                                </option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Screen Number</label>
                            <select class="form-select"
                                    v-model="formData.screenNumber"
                                    required>
                                <option value="">Select Screen</option>
                                <option v-for="screen in availableScreens" 
                                        :key="screen"
                                        :value="screen">
                                    Screen {{ screen }}
                                </option>
                            </select>
                        </div>

                        <div class="row mb-3">
                            <div class="col">
                                <label class="form-label">Date</label>
                                <input type="date" 
                                       class="form-control"
                                       v-model="formData.date"
                                       :min="today"
                                       required>
                            </div>
                            <div class="col">
                                <label class="form-label">Time</label>
                                <input type="time" 
                                       class="form-control"
                                       v-model="formData.time"
                                       required>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col">
                                <label class="form-label">Lower Hall Price</label>
                                <input type="number" 
                                       class="form-control"
                                       v-model="formData.price.lowerHall"
                                       min="0"
                                       step="0.01"
                                       required>
                            </div>
                            <div class="col">
                                <label class="form-label">Upper Gallery Price</label>
                                <input type="number" 
                                       class="form-control"
                                       v-model="formData.price.upperGallery"
                                       min="0"
                                       step="0.01"
                                       required>
                            </div>
                            <div class="col">
                                <label class="form-label">VIP Price</label>
                                <input type="number" 
                                       class="form-control"
                                       v-model="formData.price.vipSeats"
                                       min="0"
                                       step="0.01"
                                       required>
                            </div>
                        </div>

                        <div class="modal-footer">
                            <button type="button" 
                                    class="btn btn-secondary"
                                    data-bs-dismiss="modal">
                                Cancel
                            </button>
                            <button type="submit" 
                                    class="btn btn-primary">
                                Save Screening
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import { Modal } from 'bootstrap'

export default {
    props: {
        screening: {
            type: Object,
            default: null
        },
        cinemas: {
            type: Array,
            required: true
        },
        films: {
            type: Array,
            required: true
        }
    },
    data() {
        return {
            modal: null,
            formData: {
                cinemaId: '',
                filmId: '',
                screenNumber: '',
                date: '',
                time: '',
                price: {
                    lowerHall: '',
                    upperGallery: '',
                    vipSeats: ''
                }
            }
        }
    },
    computed: {
        today() {
            return new Date().toISOString().split('T')[0]
        },
        availableScreens() {
            const selectedCinema = this.cinemas.find(c => c._id === this.formData.cinemaId)
            return selectedCinema ? Array.from({ length: selectedCinema.screens.length }, (_, i) => i + 1) : []
        }
    },
    methods: {
        show() {
            this.resetForm()
            this.modal.show()
        },
        hide() {
            this.modal.hide()
        },
        resetForm() {
            if (this.screening) {
                const showtime = new Date(this.screening.showtime)
                this.formData = {
                    ...this.screening,
                    date: showtime.toISOString().split('T')[0],
                    time: showtime.toTimeString().slice(0, 5)
                }
            } else {
                this.formData = {
                    cinemaId: '',
                    filmId: '',
                    screenNumber: '',
                    date: '',
                    time: '',
                    price: {
                        lowerHall: '',
                        upperGallery: '',
                        vipSeats: ''
                    }
                }
            }
        },
        handleSubmit() {
            const showtime = new Date(`${this.formData.date}T${this.formData.time}`)
            
            const screeningData = {
                ...this.formData,
                showtime
            }
            
            delete screeningData.date
            delete screeningData.time
            
            this.$emit('save', screeningData)
            this.hide()
        }
    },
    mounted() {
        this.modal = new Modal(this.$refs.modal)
    }
}
</script> 