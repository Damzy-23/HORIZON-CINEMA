<template>
    <div class="modal fade" ref="modal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        {{ film ? 'Edit Film' : 'Add New Film' }}
                    </h5>
                    <button type="button" 
                            class="btn-close" 
                            data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form @submit.prevent="handleSubmit">
                        <div class="mb-3">
                            <label class="form-label">Title</label>
                            <input type="text" 
                                   class="form-control"
                                   v-model="formData.title"
                                   required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Description</label>
                            <textarea class="form-control"
                                      v-model="formData.description"
                                      rows="3"></textarea>
                        </div>

                        <div class="row mb-3">
                            <div class="col">
                                <label class="form-label">Genre</label>
                                <select class="form-select"
                                        v-model="formData.genre"
                                        required>
                                    <option value="">Select Genre</option>
                                    <option v-for="genre in genres" 
                                            :key="genre" 
                                            :value="genre">
                                        {{ genre }}
                                    </option>
                                </select>
                            </div>
                            <div class="col">
                                <label class="form-label">Age Rating</label>
                                <select class="form-select"
                                        v-model="formData.ageRating"
                                        required>
                                    <option value="">Select Rating</option>
                                    <option v-for="rating in ageRatings" 
                                            :key="rating" 
                                            :value="rating">
                                        {{ rating }}
                                    </option>
                                </select>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col">
                                <label class="form-label">Duration (mins)</label>
                                <input type="number" 
                                       class="form-control"
                                       v-model="formData.duration"
                                       min="1"
                                       required>
                            </div>
                            <div class="col">
                                <label class="form-label">Rating</label>
                                <input type="number" 
                                       class="form-control"
                                       v-model="formData.rating"
                                       min="0"
                                       max="5"
                                       step="0.1">
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Actors</label>
                            <div v-for="(actor, index) in formData.actors" 
                                 :key="index"
                                 class="input-group mb-2">
                                <input type="text" 
                                       class="form-control"
                                       v-model="formData.actors[index]">
                                <button type="button" 
                                        class="btn btn-danger"
                                        @click="removeActor(index)">
                                    Remove
                                </button>
                            </div>
                            <button type="button" 
                                    class="btn btn-secondary"
                                    @click="addActor">
                                Add Actor
                            </button>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Poster URL</label>
                            <input type="url" 
                                   class="form-control"
                                   v-model="formData.posterUrl">
                        </div>

                        <div class="modal-footer">
                            <button type="button" 
                                    class="btn btn-secondary"
                                    data-bs-dismiss="modal">
                                Cancel
                            </button>
                            <button type="submit" 
                                    class="btn btn-primary">
                                Save Film
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import { Modal } from 'bootstrap'

export default {
    props: {
        film: {
            type: Object,
            default: null
        }
    },
    data() {
        return {
            modal: null,
            formData: {
                title: '',
                description: '',
                genre: '',
                ageRating: '',
                duration: '',
                rating: '',
                actors: [],
                posterUrl: ''
            },
            genres: [
                'Action',
                'Comedy',
                'Drama',
                'Horror',
                'Sci-Fi',
                'Thriller',
                'Romance',
                'Documentary'
            ],
            ageRatings: ['U', 'PG', '12A', '15', '18']
        }
    },
    methods: {
        show() {
            this.resetForm()
            this.modal.show()
        },
        hide() {
            this.modal.hide()
        },
        resetForm() {
            if (this.film) {
                this.formData = { ...this.film }
                this.formData.actors = [...(this.film.actors || [])]
            } else {
                this.formData = {
                    title: '',
                    description: '',
                    genre: '',
                    ageRating: '',
                    duration: '',
                    rating: '',
                    actors: [],
                    posterUrl: ''
                }
            }
        },
        addActor() {
            this.formData.actors.push('')
        },
        removeActor(index) {
            this.formData.actors.splice(index, 1)
        },
        handleSubmit() {
            // Remove empty actors
            this.formData.actors = this.formData.actors.filter(actor => actor.trim())
            
            this.$emit('save', { ...this.formData })
            this.hide()
        }
    },
    mounted() {
        this.modal = new Modal(this.$refs.modal)
    }
}
</script> 