<template>
    <div class="manage-bookings">
        <h3>Manage Bookings</h3>
        <ul class="list-group">
            <li v-for="booking in bookings" :key="booking._id" class="list-group-item">
                {{ booking.customerName }} - {{ booking.film.title }} - {{ new Date(booking.screening.showtime).toLocaleString() }} 
                <button class="btn btn-danger btn-sm float-end" @click="deleteBooking(booking._id)">Delete</button>
            </li>
        </ul>
    </div>
</template>

<script>
export default {
    data() {
        return {
            bookings: []
        }
    },
    methods: {
        async fetchBookings() {
            try {
                const response = await this.$axios.get('/api/bookings');
                this.bookings = response.data;
            } catch (error) {
                console.error('Error fetching bookings:', error);
            }
        },
        async deleteBooking(bookingId) {
            try {
                await this.$axios.delete(`/api/bookings/${bookingId}`);
                this.fetchBookings();
            } catch (error) {
                console.error('Error deleting booking:', error);
            }
        }
    },
    mounted() {
        this.fetchBookings();
    }
}
</script>

<style scoped>
.manage-bookings {
    margin-top: 20px;
}

.list-group-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
}
</style> 