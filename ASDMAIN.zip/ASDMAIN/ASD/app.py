from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def home():
    films = [
        {"title": "Film 1", "genre": "Genre 1", "duration": 120, "showtimes": "10:00, 13:00, 16:00"},
        {"title": "Film 2", "genre": "Genre 2", "duration": 90, "showtimes": "11:00, 14:00, 17:00"},
        # Add more films as needed
    ]
    return render_template('index.html', films=films)

if __name__ == '__main__':
    app.run(debug=True) 