import sys
import os
import tkinter as tk
from tkinter import messagebox, simpledialog, font
# Fix import path for backend classes
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../../backend/classes')))

from CinemaManager import CinemaManager
from Film import Film
from Screen import Screen
from Cinema import Cinema
from Booking import Booking

class HorizonCinemaApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Horizon Cinema Booking System")
        self.root.geometry("600x500")
        self.root.configure(bg="#1e1e2f")
        self.manager = CinemaManager()
        self.current_user = None

        self.custom_font = font.Font(family="Helvetica", size=12, weight="bold")
        self.button_style = {"bg": "#4a90e2", "fg": "white", "font": self.custom_font, "activebackground": "#357ABD", "activeforeground": "white", "bd": 0, "relief": "flat", "padx": 10, "pady": 5}

        self.login_screen()

    def login_screen(self):
        self.clear_window()

        title = tk.Label(self.root, text="Horizon Cinema Login", bg="#1e1e2f", fg="white", font=("Helvetica", 20, "bold"))
        title.pack(pady=20)

        frame = tk.Frame(self.root, bg="#1e1e2f")
        frame.pack(pady=10)

        tk.Label(frame, text="Username:", bg="#1e1e2f", fg="white", font=self.custom_font).grid(row=0, column=0, sticky="e", pady=5)
        self.username_entry = tk.Entry(frame, font=self.custom_font)
        self.username_entry.grid(row=0, column=1, pady=5, padx=10)

        tk.Label(frame, text="Password:", bg="#1e1e2f", fg="white", font=self.custom_font).grid(row=1, column=0, sticky="e", pady=5)
        self.password_entry = tk.Entry(frame, show="*", font=self.custom_font)
        self.password_entry.grid(row=1, column=1, pady=5, padx=10)

        btn_frame = tk.Frame(self.root, bg="#1e1e2f")
        btn_frame.pack(pady=20)

        login_btn = tk.Button(btn_frame, text="Login", command=self.login, **self.button_style)
        login_btn.grid(row=0, column=0, padx=10)

        signup_btn = tk.Button(btn_frame, text="Sign Up", command=self.signup_screen, **self.button_style)
        signup_btn.grid(row=0, column=1, padx=10)

    def signup_screen(self):
        self.clear_window()

        title = tk.Label(self.root, text="Create New Account", bg="#1e1e2f", fg="white", font=("Helvetica", 20, "bold"))
        title.pack(pady=20)

        frame = tk.Frame(self.root, bg="#1e1e2f")
        frame.pack(pady=10)

        tk.Label(frame, text="Username:", bg="#1e1e2f", fg="white", font=self.custom_font).grid(row=0, column=0, sticky="e", pady=5)
        self.new_username_entry = tk.Entry(frame, font=self.custom_font)
        self.new_username_entry.grid(row=0, column=1, pady=5, padx=10)

        tk.Label(frame, text="Password:", bg="#1e1e2f", fg="white", font=self.custom_font).grid(row=1, column=0, sticky="e", pady=5)
        self.new_password_entry = tk.Entry(frame, show="*", font=self.custom_font)
        self.new_password_entry.grid(row=1, column=1, pady=5, padx=10)

        btn_frame = tk.Frame(self.root, bg="#1e1e2f")
        btn_frame.pack(pady=20)

        register_btn = tk.Button(btn_frame, text="Register", command=self.register_user, **self.button_style)
        register_btn.grid(row=0, column=0, padx=10)

        back_btn = tk.Button(btn_frame, text="Back to Login", command=self.login_screen, **self.button_style)
        back_btn.grid(row=0, column=1, padx=10)

    def register_user(self):
        username = self.new_username_entry.get()
        password = self.new_password_entry.get()
        if not username or not password:
            messagebox.showerror("Error", "Username and password cannot be empty.")
            return
        success = self.manager.add_user(username, password)
        if success:
            messagebox.showinfo("Success", "User registered successfully. Please login.")
            self.login_screen()
        else:
            messagebox.showerror("Error", "Username already exists. Please choose another.")

    def login(self):
        username = self.username_entry.get()
        password = self.password_entry.get()
        user = self.manager.authenticate_user(username, password)
        if user:
            self.current_user = user
            messagebox.showinfo("Login Success", f"Welcome {user.username}!")
            self.main_menu()
        else:
            messagebox.showerror("Login Failed", "Invalid username or password")

    def main_menu(self):
        self.clear_window()

        welcome_label = tk.Label(self.root, text=f"Welcome {self.current_user.username} ({self.current_user.role})", bg="#1e1e2f", fg="white", font=("Helvetica", 16, "bold"))
        welcome_label.pack(pady=20)

        btn_frame = tk.Frame(self.root, bg="#1e1e2f")
        btn_frame.pack(pady=10)

        view_cinemas_btn = tk.Button(btn_frame, text="View Cinemas", command=self.view_cinemas, **self.button_style)
        view_cinemas_btn.grid(row=0, column=0, padx=10, pady=5)

        # Only show Add Cinema button for Admin and Manager roles
        if self.current_user.role in ["Admin", "Manager"]:
            add_cinema_btn = tk.Button(btn_frame, text="Add Cinema", command=self.add_cinema, **self.button_style)
            add_cinema_btn.grid(row=0, column=1, padx=10, pady=5)

            book_tickets_btn = tk.Button(btn_frame, text="Book Tickets", command=self.book_tickets, **self.button_style)
            book_tickets_btn.grid(row=0, column=2, padx=10, pady=5)

            logout_btn = tk.Button(btn_frame, text="Logout", command=self.logout, **self.button_style)
            logout_btn.grid(row=0, column=3, padx=10, pady=5)
        else:
            # For regular users, no Add Cinema button, only View Cinemas and Book Tickets
            book_tickets_btn = tk.Button(btn_frame, text="Book Tickets", command=self.book_tickets, **self.button_style)
            book_tickets_btn.grid(row=0, column=1, padx=10, pady=5)

            logout_btn = tk.Button(btn_frame, text="Logout", command=self.logout, **self.button_style)
            logout_btn.grid(row=0, column=2, padx=10, pady=5)

    def view_cinemas(self):
        self.clear_window()
        title = tk.Label(self.root, text="Cinemas", bg="#1e1e2f", fg="white", font=("Helvetica", 18, "bold"))
        title.pack(pady=20)

        for cinema in self.manager.cinemas:
            cinema_label = tk.Label(self.root, text=f"{cinema.name} - {cinema.city}", bg="#1e1e2f", fg="white", font=self.custom_font)
            cinema_label.pack(pady=5)

        back_btn = tk.Button(self.root, text="Back", command=self.main_menu, **self.button_style)
        back_btn.pack(pady=20)

    def add_cinema(self):
        cinema_name = simpledialog.askstring("Add Cinema", "Enter cinema name:")
        city = simpledialog.askstring("Add Cinema", "Enter city:")
        if cinema_name and city:
            self.manager.add_cinema(cinema_name, city)
            messagebox.showinfo("Success", "Cinema added successfully")
        self.main_menu()

    def book_tickets(self):
        self.clear_window()
        title = tk.Label(self.root, text="Select Cinema", bg="#1e1e2f", fg="white", font=("Helvetica", 18, "bold"))
        title.pack(pady=20)

        self.cinema_var = tk.StringVar(self.root)
        cinema_names = [cinema.name for cinema in self.manager.cinemas]
        if not cinema_names:
            messagebox.showinfo("No Cinemas", "No cinemas available to book.")
            self.main_menu()
            return
        self.cinema_var.set(cinema_names[0])
        cinema_menu = tk.OptionMenu(self.root, self.cinema_var, *cinema_names)
        cinema_menu.config(bg="#4a90e2", fg="white", font=self.custom_font)
        cinema_menu.pack(pady=10)

        next_btn = tk.Button(self.root, text="Next", command=self.select_film, **self.button_style)
        next_btn.pack(pady=10)

        back_btn = tk.Button(self.root, text="Back", command=self.main_menu, **self.button_style)
        back_btn.pack(pady=10)

    def select_film(self):
        selected_cinema_name = self.cinema_var.get()
        self.selected_cinema = next((c for c in self.manager.cinemas if c.name == selected_cinema_name), None)
        if not self.selected_cinema:
            messagebox.showerror("Error", "Selected cinema not found.")
            self.book_tickets()
            return

        self.clear_window()
        title = tk.Label(self.root, text="Select Film and Show Time", bg="#1e1e2f", fg="white", font=("Helvetica", 18, "bold"))
        title.pack(pady=20)

        self.film_showings = []
        for screen in self.selected_cinema.screens:
            for film, show_time in screen.showings:
                self.film_showings.append((film, show_time, screen))

        if not self.film_showings:
            messagebox.showinfo("No Showings", "No films available for booking in this cinema.")
            self.book_tickets()
            return

        # Sort film showings by show_time ascending
        self.film_showings.sort(key=lambda x: x[1])

        # Use a Listbox for vertical arrangement with bigger font
        self.film_listbox = tk.Listbox(self.root, font=("Helvetica", 14), bg="#2e2e3f", fg="white", selectbackground="#4a90e2", activestyle="none", width=40, height=10)
        for film, show_time, _ in self.film_showings:
            self.film_listbox.insert(tk.END, f"{show_time} - {film.title}")
        self.film_listbox.pack(pady=10)

        next_btn = tk.Button(self.root, text="Next", command=self.select_seats_from_listbox, **self.button_style)
        next_btn.pack(pady=10)

        back_btn = tk.Button(self.root, text="Back", command=self.book_tickets, **self.button_style)
        back_btn.pack(pady=10)

    def select_seats_from_listbox(self):
        try:
            index = self.film_listbox.curselection()
            if not index:
                messagebox.showerror("Error", "Please select a film showing.")
                return
            index = index[0]
            self.selected_film, self.selected_show_time, self.selected_screen = self.film_showings[index]

            self.clear_window()
            title = tk.Label(self.root, text=f"Selected: {self.selected_film.title} at {self.selected_show_time}", bg="#1e1e2f", fg="white", font=("Helvetica", 16, "bold"))
            title.pack(pady=20)

            tk.Label(self.root, text="Number of Tickets:", bg="#1e1e2f", fg="white", font=self.custom_font).pack()
            self.tickets_entry = tk.Entry(self.root, font=self.custom_font)
            self.tickets_entry.pack(pady=5)

            tk.Label(self.root, text="Seat Numbers (comma separated):", bg="#1e1e2f", fg="white", font=self.custom_font).pack()
            self.seats_entry = tk.Entry(self.root, font=self.custom_font)
            self.seats_entry.pack(pady=5)

            confirm_btn = tk.Button(self.root, text="Confirm Booking", command=self.confirm_booking, **self.button_style)
            confirm_btn.pack(pady=10)

            back_btn = tk.Button(self.root, text="Back", command=self.select_film, **self.button_style)
            back_btn.pack(pady=10)
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")
        back_btn.pack(pady=10)

    def confirm_booking(self):
        try:
            num_tickets = int(self.tickets_entry.get())
            seat_numbers = [seat.strip() for seat in self.seats_entry.get().split(',')]
            if len(seat_numbers) != num_tickets:
                messagebox.showerror("Error", "Number of seats does not match number of tickets.")
                return
            booking = Booking(self.selected_film, self.selected_screen, self.selected_show_time, num_tickets, seat_numbers)
            self.manager.add_booking(booking)
            messagebox.showinfo("Success", f"Booking confirmed! Reference: {booking.booking_reference}")
            self.main_menu()
        except ValueError:
            messagebox.showerror("Error", "Invalid number of tickets.")

    def logout(self):
        self.current_user = None
        self.login_screen()

    def clear_window(self):
        for widget in self.root.winfo_children():
            widget.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = HorizonCinemaApp(root)
    root.mainloop()
